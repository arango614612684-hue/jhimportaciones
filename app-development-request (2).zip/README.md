# JH Importaciones

Tienda hecha con React, Vite y Tailwind. El codigo fuente esta en `src/` y las imagenes de marca en `public/images/`.

## Inicio rapido

1. Instala Node.js 22 (o una version 20 reciente compatible con Vite 7).
2. En la carpeta del proyecto: `npm install`.
3. Para ver la web: `npm run dev`.
4. Para generar los archivos que van al hosting: `npm run build`.
5. Sube el **contenido de `dist/`** al directorio publico del hosting.

La guia detallada para GitHub, descargar el ZIP y conectar Netlify o un hosting propio esta en [GUIA-PARA-PUBLICAR-EN-NUBE.md](GUIA-PARA-PUBLICAR-EN-NUBE.md).

**Importante:** GitHub sirve para guardar el codigo y generar el ZIP, no como hosting gratuito de esta tienda comercial (GitHub Pages no admite este uso). El editor y PIN actuales usan almacenamiento del navegador: no sincronizan productos ni ajustes entre clientes y no son autenticacion segura. Los pagos con tarjeta solo se pueden realizar en una pasarela externa real, no en esta pagina.
