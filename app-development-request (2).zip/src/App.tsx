import { useEffect, useMemo, useRef, useState } from "react";
import {
  Search,
  Heart,
  MessageCircle,
  ShoppingBag,
  MapPin,
  Star,
  ShieldCheck,
  Truck,
  X,
  Minus,
  Plus,
  Trash2,
  SlidersHorizontal,
  Store,
  BadgeCheck,
  Clock,
  Eye,
  Send,
  ChevronRight,
  Package,
  CreditCard,
  Handshake,
  Home,
  LayoutGrid,
  Building2,
  ArrowLeftRight,
  Info,
  Lock,
  Pencil,
  ImagePlus,
  Save,
  RotateCcw,
  PlusCircle,
  KeyRound,
  Settings2,
  RefreshCw,
  ExternalLink,
  Radio,
  FileText,
  Download,
  Share2,
  Copy,
  Wallet,
} from "lucide-react";
import { downloadPdf, sharePdfToWhatsApp } from "./utils/pdf";

const LOGO_URL = "./images/jh-logo.jpg";
const LOGO_ICON_URL = "./images/jh-icon.jpg";
const WISE_URL = "https://wise.com/es/currency-converter/pen-to-bob-rate";
const ER_API_URL = "https://open.er-api.com/v6/latest/PEN";
const WISE_FALLBACK_RATE = 3.5;
const WHATSAPP_NUMBER = "51918519723";
const TIKTOK_URL = "https://www.tiktok.com/@importaciones.bolivia?_r=1&_t=ZS-9A6Ptpzn4eV";
const FACEBOOK_URL = "https://www.facebook.com/share/1ByJQy1uK3/";
const WHATSAPP_GENERAL =
  "https://wa.me/51918519723?text=Hola%20*JH*%20IMPORTACIONES.%0Aveengo%20te%20TIKTOK.%0A-%20Mi%20nombre%20es:%20..........%0A-%20Soy%20de%20la%20ciudad%20de:%20.......%0A-%20Y%20mi%20consulta%20es%20:......";

function TikTokIcon({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z" />
    </svg>
  );
}
function FacebookIcon({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
    </svg>
  );
}
function WhatsAppIcon({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413z" />
    </svg>
  );
}

type Condition = "Nuevo" | "Como nuevo" | "Buen estado";
type Country = "PE" | "BO";

type LogoOption = { name: string; extraPen: number };

type Product = {
  id: number;
  title: string;
  pricePen: number;
  priceBob: number;
  category: string;
  condition: Condition;
  location: string;
  country: Country;
  shipping: boolean;
  description: string;
  material: string;
  size: string;
  color: string;
  image: string;
  featured?: boolean;
  publishedAt: string;
  views: number;
  stock: number;
  sold?: boolean;
  reserved?: boolean;
  requiresLocation?: boolean;
  logoEnabled?: boolean;
  logoMinQty?: number;
  logoOptions?: LogoOption[];
  payOptions?: string[];
};

type CartLine = { id: number; qty: number; logoIndex?: number | null; shipCountry?: string; shipCity?: string; shipDom?: string; shipAddress?: string; payType?: string };

const PAY_METHODS = ["Tarjeta", "Yape", "Plin", "Transferencia", "Efectivo", "QR Bolivia"] as const;

function getPayOptions(p: Product): string[] {
  if (p.payOptions && p.payOptions.length > 0) return p.payOptions;
  return ["Tarjeta"];
}

function normalizePayOptions(list: unknown): string[] {
  if (!Array.isArray(list)) return ["Tarjeta"];
  const clean = (list as unknown[]).map((x) => String(x ?? "").trim()).filter((x) => x.length > 0);
  const valid = clean.filter((x) => (PAY_METHODS as readonly string[]).includes(x));
  const custom = clean.filter((x) => !(PAY_METHODS as readonly string[]).includes(x)).slice(0, 4);
  const merged = [...valid, ...custom];
  return merged.length > 0 ? merged.slice(0, 8) : ["Tarjeta"];
}

type BuyerLocation = { name: string; country: string; city: string; address: string };

type ShipOption = { id: string; name: string; pricePen: number };
type ShipState = { countries: ShipOption[]; cities: ShipOption[]; doms: ShipOption[] };

const SHIP_KEY = "jh-ship-v1";
const PAY_SETTINGS_KEY = "jh-pay-settings-v1";

type PaySettings = { cardEnabled: boolean; cardLink: string };

function loadPaySettings(): PaySettings {
  try {
    const raw = localStorage.getItem(PAY_SETTINGS_KEY);
    if (!raw) return { cardEnabled: false, cardLink: "" };
    const p = JSON.parse(raw) as Partial<PaySettings>;
    return {
      cardEnabled: p.cardEnabled === true,
      cardLink: typeof p.cardLink === "string" ? p.cardLink.trim() : "",
    };
  } catch {
    return { cardEnabled: false, cardLink: "" };
  }
}

function isValidCardLink(value: string) {
  try {
    const url = new URL(value.trim());
    return url.protocol === "https:" && Boolean(url.hostname) && !url.username && !url.password;
  } catch {
    return false;
  }
}

function visiblePayOptions(p: Product, cardEnabled: boolean): string[] {
  const all = getPayOptions(p);
  const filtered = cardEnabled ? all : all.filter((m) => m !== "Tarjeta");
  return filtered.length > 0 ? filtered : ["Coordinar por WhatsApp"];
}

const DEFAULT_SHIP: ShipState = {
  countries: [
    { id: "pe", name: "Perú", pricePen: 12 },
    { id: "bo", name: "Bolivia", pricePen: 22 },
    { id: "ot", name: "Otro país", pricePen: 30 },
  ],
  cities: [
    { id: "cus", name: "Cusco", pricePen: 0 },
    { id: "lim", name: "Lima", pricePen: 8 },
    { id: "aqp", name: "Arequipa", pricePen: 8 },
    { id: "lpz", name: "La Paz", pricePen: 10 },
    { id: "cbba", name: "Cochabamba", pricePen: 10 },
    { id: "otra", name: "Otra ciudad", pricePen: 12 },
  ],
  doms: [
    { id: "recojo", name: "Recojo en tienda", pricePen: 0 },
    { id: "dom-std", name: "A domicilio estándar", pricePen: 9 },
    { id: "dom-exp", name: "A domicilio express", pricePen: 18 },
  ],
};

function loadShip(): ShipState {
  try {
    const raw = localStorage.getItem(SHIP_KEY);
    if (!raw) return DEFAULT_SHIP;
    const p = JSON.parse(raw) as Partial<ShipState>;
    const clean = (arr: unknown, fb: ShipOption[]) => {
      if (!Array.isArray(arr) || arr.length === 0) return fb;
      return (arr as ShipOption[]).filter((x) => x && x.name).map((x, i) => ({
        id: String(x.id || `id-${i}`),
        name: String(x.name),
        pricePen: Math.max(0, Math.round(Number(x.pricePen) || 0)),
      }));
    };
    return {
      countries: clean(p.countries, DEFAULT_SHIP.countries),
      cities: clean(p.cities, DEFAULT_SHIP.cities),
      doms: clean(p.doms, DEFAULT_SHIP.doms),
    };
  } catch {
    return DEFAULT_SHIP;
  }
}
type ChatMsg = { from: "me" | "seller"; text: string; time: string };

const SELLER = {
  name: "JH Importaciones",
  owner: "Productos novedosos a precio de fábrica",
  avatar: "./images/jh-icon.jpg",
  rating: 4.9,
  reviews: 312,
  sales: 480,
  followers: 1204,
  response: "Responde en ~1 h",
  location: "Cusco, Perú",
  since: "Vende desde 2021",
  verified: true,
};

const CATEGORIES = ["Todos", "Abrigos", "Tejidos", "Accesorios", "Hogar", "Electrónica", "Juguetes", "Autos", "Móvil"] as const;
const ADMIN_CATEGORIES = ["Abrigos", "Tejidos", "Accesorios", "Hogar", "Electrónica", "Juguetes", "Autos", "Móvil"];
const PRODUCTS_KEY = "jh-products-v2";
const RATE_KEY = "jh-rate-v4-wise";
const RATE_META_KEY = "jh-rate-meta-v5";
const ADMIN_KEY = "jh-admin-ok";
const ADMIN_PIN_KEY = "jh-admin-pin-v1";

function loadStoredPin(): string {
  try {
    const raw = localStorage.getItem(ADMIN_PIN_KEY);
    if (raw && /^\d{4,8}$/.test(raw)) return raw;
    return "1234";
  } catch {
    return "1234";
  }
}

const DEFAULT_PRODUCTS: Product[] = [
  {
    id: 1,
    title: "Manta Urubamba de alpaca — tejido a telar",
    pricePen: 289,
    priceBob: 543,
    category: "Hogar",
    condition: "Nuevo",
    location: "Cusco",
    country: "PE",
    shipping: true,
    description:
      "Manta gruesa de alpaca tejida a telar por artesanas del Valle Sagrado. Abriga muchísimo y no pica. Ideal para sofá o cama queen.",
    material: "100% alpaca",
    size: "180 x 130 cm",
    color: "Tierra / mostaza",
    image:
      "https://images.pexels.com/photos/32655893/pexels-photo-32655893.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=800",
    featured: true,
    publishedAt: "hace 2 h",
    views: 842,
    stock: 3,
  },
  {
    id: 2,
    title: "Chal Suyana ligero con borde hecho a mano",
    pricePen: 149,
    priceBob: 280,
    category: "Accesorios",
    condition: "Como nuevo",
    location: "Arequipa",
    country: "PE",
    shipping: true,
    description:
      "Chal liviano que compré para viaje y usé dos veces. Sin manchas ni hilos jalados. Cae perfecto y combina con todo.",
    material: "Mezcla alpaca",
    size: "200 x 70 cm",
    color: "Arena",
    image:
      "https://images.pexels.com/photos/19087201/pexels-photo-19087201.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=800",
    publishedAt: "hace 5 h",
    views: 321,
    stock: 1,
  },
  {
    id: 3,
    title: "Abrigo Ayni oversize baby alpaca",
    pricePen: 479,
    priceBob: 901,
    category: "Abrigos",
    condition: "Nuevo",
    location: "Cusco",
    country: "PE",
    shipping: true,
    description:
      "Mi pieza estrella. Abrigo amplio de baby alpaca, forro suave, bolsillos profundos. Talla M/L. Lo vendo porque me quedé con otro color.",
    material: "Baby alpaca",
    size: "M / L oversize",
    color: "Beige natural",
    image:
      "https://images.pexels.com/photos/4295983/pexels-photo-4295983.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=800",
    featured: true,
    publishedAt: "ayer",
    views: 1204,
    stock: 2,
  },
  {
    id: 4,
    title: "Camino de mesa Qhapaq con diseño de llama",
    pricePen: 219,
    priceBob: 412,
    category: "Hogar",
    condition: "Nuevo",
    location: "Puno",
    country: "PE",
    shipping: true,
    description:
      "Camino de mesa artesanal con iconografía andina. Tejido firme, colores firmes que no destiñen. Queda hermoso en madera.",
    material: "Lana andina",
    size: "220 x 45 cm",
    color: "Multicolor andino",
    image:
      "https://images.pexels.com/photos/33980181/pexels-photo-33980181.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=800",
    publishedAt: "ayer",
    views: 410,
    stock: 4,
  },
  {
    id: 5,
    title: "Poncho Chinchero tejido grueso unisex",
    pricePen: 329,
    priceBob: 619,
    category: "Tejidos",
    condition: "Nuevo",
    location: "Cusco",
    country: "PE",
    shipping: true,
    description:
      "Poncho abrigador para frío real. Cuello alto, tejido doble. Lo traigo directo de Chinchero, etiquetado y con garantía de mi tienda.",
    material: "Alpaca gruesa",
    size: "Unitalla",
    color: "Marrón jaspe",
    image:
      "https://images.unsplash.com/photo-1445205170230-053b83016050?q=80&w=800&auto=format&fit=crop",
    featured: true,
    publishedAt: "hace 3 d",
    views: 655,
    stock: 2,
  },
  {
    id: 6,
    title: "Jersey Altiplano punto trenzado — poco uso",
    pricePen: 189,
    priceBob: 355,
    category: "Tejidos",
    condition: "Como nuevo",
    location: "La Paz",
    country: "BO",
    shipping: true,
    description:
      "Jersey de punto trenzado, calientito y sin bolitas. Lo usé un invierno en La Paz. Talla M. Entrego en Sopocachi o envío.",
    material: "Lana merino + acrílico",
    size: "M",
    color: "Crudo",
    image:
      "https://images.unsplash.com/photo-1523381210434-271e8be1f52b?q=80&w=800&auto=format&fit=crop",
    publishedAt: "hace 3 d",
    views: 288,
    stock: 1,
  },
  {
    id: 7,
    title: "Gorro Apu tejido a mano con forro polar",
    pricePen: 69,
    priceBob: 130,
    category: "Accesorios",
    condition: "Nuevo",
    location: "Cusco",
    country: "PE",
    shipping: true,
    description:
      "Gorro con forro polar por dentro, no pica nada. Tengo varios colores, pregúntame por interno antes de comprar.",
    material: "Alpaca + polar",
    size: "Unitalla",
    color: "Terracota",
    image:
      "https://images.pexels.com/photos/5331562/pexels-photo-5331562.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=800",
    publishedAt: "hace 4 d",
    views: 190,
    stock: 8,
  },
  {
    id: 8,
    title: "Bufanda Killa con flecos — color chocolate",
    pricePen: 99,
    priceBob: 186,
    category: "Accesorios",
    condition: "Buen estado",
    location: "Arequipa",
    country: "PE",
    shipping: false,
    description:
      "Bufanda de mi uso personal, con detalle de flecos. Tiene mucho hilo todavía, solo la vendo por renovación de mi tienda.",
    material: "Fibra premium",
    size: "190 x 35 cm",
    color: "Chocolate",
    image:
      "https://images.pexels.com/photos/31034511/pexels-photo-31034511.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=800",
    publishedAt: "hace 5 d",
    views: 142,
    stock: 1,
  },
  {
    id: 9,
    title: "Casaca Litoral tipo field jacket — casi nueva",
    pricePen: 399,
    priceBob: 750,
    category: "Abrigos",
    condition: "Como nuevo",
    location: "Lima",
    country: "PE",
    shipping: true,
    description:
      "Casaca urbana con forro interior abrigador. Cierres perfectos, sin desgaste. Talla M. Ideal para Lima y viajes a sierra.",
    material: "Algodón + forro",
    size: "M",
    color: "Verde oliva",
    image:
      "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?q=80&w=800&auto=format&fit=crop",
    publishedAt: "hace 1 sem",
    views: 530,
    stock: 1,
    reserved: true,
  },
  {
    id: 10,
    title: "Mochila Q'ipi de cuero y textil andino",
    pricePen: 259,
    priceBob: 487,
    category: "Accesorios",
    condition: "Nuevo",
    location: "Cusco",
    country: "PE",
    shipping: true,
    description:
      "Mochila pequeña con aplicaciones textiles. Cuero repujado, cierre metálico. Espaciosa para diario y muy resistente.",
    material: "Cuero + textil",
    size: "28 x 24 cm",
    color: "Marrón / andino",
    image:
      "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?q=80&w=800&auto=format&fit=crop",
    publishedAt: "hace 1 sem",
    views: 376,
    stock: 2,
  },
  {
    id: 11,
    title: "Manta Wayra pequeña — ideal para sillón",
    pricePen: 139,
    priceBob: 261,
    category: "Hogar",
    condition: "Buen estado",
    location: "Cochabamba",
    country: "BO",
    shipping: true,
    description:
      "Mantita que tenía en mi sillón, en muy buen estado. Sin huecos. La dejo barata porque estoy liquidando stock de mi tienda.",
    material: "Lana",
    size: "130 x 90 cm",
    color: "Marrón natural",
    image:
      "https://images.pexels.com/photos/31034508/pexels-photo-31034508.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=800",
    publishedAt: "hace 1 sem",
    views: 98,
    stock: 1,
  },
  {
    id: 12,
    title: "Cárdigan Papa tejido artesanal talla L",
    pricePen: 249,
    priceBob: 468,
    category: "Tejidos",
    condition: "Como nuevo",
    location: "La Paz",
    country: "BO",
    shipping: false,
    description:
      "Cárdigan con botones de madera, tejido firme. Solo entrega en persona en La Paz centro. Puedes probártelo sin compromiso.",
    material: "Alpaca",
    size: "L",
    color: "Gris jaspe",
    image:
      "https://images.unsplash.com/photo-1434389677669-e08b4cac3105?q=80&w=800&auto=format&fit=crop",
    publishedAt: "hace 2 sem",
    views: 210,
    stock: 1,
    sold: true,
  },
  {
    id: 13,
    title: "Audífonos Bluetooth Pro con cancelación de ruido",
    pricePen: 189,
    priceBob: 355,
    category: "Electrónica",
    condition: "Nuevo",
    location: "Lima",
    country: "PE",
    shipping: true,
    description:
      "Audífonos inalámbricos con estuche de carga, micrófono HD y hasta 36h de batería. Sellados, con garantía JH.",
    material: "Electrónica",
    size: "Unitalla",
    color: "Negro",
    image:
      "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?q=80&w=800&auto=format&fit=crop",
    featured: true,
    publishedAt: "hace 1 h",
    views: 512,
    stock: 10,
  },
  {
    id: 14,
    title: "Smartwatch Deportivo con llamadas y ritmo cardíaco",
    pricePen: 249,
    priceBob: 468,
    category: "Electrónica",
    condition: "Nuevo",
    location: "Cusco",
    country: "PE",
    shipping: true,
    description:
      "Reloj inteligente con pantalla AMOLED, monitoreo de salud, 100 modos deporte y resistente al agua. Compatible Android y iPhone.",
    material: "Electrónica",
    size: "44 mm",
    color: "Negro",
    image:
      "https://images.unsplash.com/photo-1523275335684-37898b6baf30?q=80&w=800&auto=format&fit=crop",
    publishedAt: "hace 3 h",
    views: 388,
    stock: 8,
  },
  {
    id: 15,
    title: "Set Bloques Didácticos 250 piezas para niños",
    pricePen: 119,
    priceBob: 224,
    category: "Juguetes",
    condition: "Nuevo",
    location: "Arequipa",
    country: "PE",
    shipping: true,
    description:
      "Bloques de construcción coloridos, compatibles con las marcas grandes. Estimula creatividad y motricidad. Incluye caja organizadora.",
    material: "Plástico ABS seguro",
    size: "250 piezas",
    color: "Multicolor",
    image:
      "https://images.unsplash.com/photo-1558060370-d644479cb6f7?q=80&w=800&auto=format&fit=crop",
    publishedAt: "hace 6 h",
    views: 245,
    stock: 12,
  },
  {
    id: 16,
    title: "Carro a Control Remoto 4x4 recargable",
    pricePen: 149,
    priceBob: 280,
    category: "Juguetes",
    condition: "Nuevo",
    location: "La Paz",
    country: "BO",
    shipping: true,
    description:
      "Camioneta todoterreno a radio control 2.4GHz, batería recargable, luces LED y suspensión real. Ideal para tierra y pista.",
    material: "Juguete RC",
    size: "1:16",
    color: "Rojo",
    image:
      "https://images.unsplash.com/photo-1594787318286-3d835c1d207f?q=80&w=800&auto=format&fit=crop",
    publishedAt: "ayer",
    views: 198,
    stock: 6,
  },
  {
    id: 17,
    title: "Aspiradora Portátil para Auto 120W",
    pricePen: 139,
    priceBob: 261,
    category: "Autos",
    condition: "Nuevo",
    location: "Lima",
    country: "PE",
    shipping: true,
    description:
      "Aspiradora 12V para encendedor del auto, con 3 boquillas y filtro lavable. Potente succión para tapiz y maletera.",
    material: "Accesorio auto",
    size: "Compacta",
    color: "Negro / Rojo",
    image:
      "https://images.unsplash.com/photo-1493238792000-8113da705763?q=80&w=800&auto=format&fit=crop",
    publishedAt: "hace 2 d",
    views: 167,
    stock: 9,
  },
  {
    id: 18,
    title: "Soporte Celular + Cargador para Auto",
    pricePen: 69,
    priceBob: 130,
    category: "Autos",
    condition: "Nuevo",
    location: "Cochabamba",
    country: "BO",
    shipping: true,
    description:
      "Soporte magnético de rejilla + cargador rápido dual USB para carro. Rotación 360°, agarre firme en trocha.",
    material: "Accesorio auto",
    size: "Universal",
    color: "Negro",
    image:
      "https://images.unsplash.com/photo-1503376780353-7e6692767b70?q=80&w=800&auto=format&fit=crop",
    publishedAt: "hace 3 d",
    views: 132,
    stock: 15,
  },
  {
    id: 19,
    title: "Celular Libre 128GB + 6GB RAM doble chip",
    pricePen: 649,
    priceBob: 1220,
    category: "Móvil",
    condition: "Nuevo",
    location: "Lima",
    country: "PE",
    shipping: true,
    description:
      "Equipo nuevo sellado, liberado para Claro, Movistar, Entel y Bitel. Cámara 50MP, batería 5000mAh y mica + funda de regalo.",
    material: "Smartphone",
    size: '6.6"',
    color: "Azul",
    image:
      "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?q=80&w=800&auto=format&fit=crop",
    featured: true,
    publishedAt: "hace 4 h",
    views: 623,
    stock: 5,
  },
  {
    id: 20,
    title: "Funda + Vidrio Templado + Aro de Luz combo",
    pricePen: 59,
    priceBob: 111,
    category: "Móvil",
    condition: "Nuevo",
    location: "Cusco",
    country: "PE",
    shipping: true,
    description:
      "Kit completo para tu móvil: case anticaídas, vidrio 9H y aro de luz para TikTok. Pregunta por tu modelo.",
    material: "Accesorio móvil",
    size: "Universal",
    color: "Varios",
    image:
      "https://images.unsplash.com/photo-1510557880182-3d4d3cba35a5?q=80&w=800&auto=format&fit=crop",
    publishedAt: "hace 5 h",
    views: 154,
    stock: 20,
  },
];

function loadProducts(): Product[] {
  try {
    const raw = localStorage.getItem(PRODUCTS_KEY);
    if (!raw) return DEFAULT_PRODUCTS;
    const parsed = JSON.parse(raw) as Product[];
    if (!Array.isArray(parsed) || parsed.length === 0) return DEFAULT_PRODUCTS;
    return parsed;
  } catch {
    return DEFAULT_PRODUCTS;
  }
}

function loadRate(): number {
  try {
    const raw = localStorage.getItem(RATE_KEY);
    const v = raw ? Number(raw) : WISE_FALLBACK_RATE;
    if (!Number.isFinite(v) || v <= 0) return WISE_FALLBACK_RATE;
    if (v < 2.2) return WISE_FALLBACK_RATE;
    return v;
  } catch {
    return WISE_FALLBACK_RATE;
  }
}

type RateMeta = {
  wise: number | null;
  source: "wise-live" | "market-live" | "manual";
  updatedAt: number | null;
  wiseUpdatedAt: number | null;
  auto: boolean;
};

function loadRateMeta(): RateMeta {
  const fallback: RateMeta = {
    wise: loadRate(),
    source: "manual",
    updatedAt: null,
    wiseUpdatedAt: null,
    auto: true,
  };
  try {
    const raw = localStorage.getItem(RATE_META_KEY);
    if (!raw) return fallback;
    const p = JSON.parse(raw) as Partial<RateMeta>;
    return {
      wise: typeof p.wise === "number" ? p.wise : fallback.wise,
      source: p.source === "wise-live" || p.source === "market-live" ? p.source : "manual",
      updatedAt: typeof p.updatedAt === "number" ? p.updatedAt : null,
      wiseUpdatedAt: typeof p.wiseUpdatedAt === "number" ? p.wiseUpdatedAt : null,
      auto: p.auto === false ? false : true,
    };
  } catch {
    return fallback;
  }
}

function timeAgo(ts: number | null): string {
  if (!ts) return "aún no sincronizado";
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 60) return `hace ${s} seg`;
  const m = Math.floor(s / 60);
  if (m < 60) return `hace ${m} min`;
  const h = Math.floor(m / 60);
  if (h < 24) return `hace ${h} h`;
  return new Date(ts).toLocaleString("es-PE", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
}

function parseEsNumber(raw: string): number | null {
  const s = raw.trim();
  if (!s) return null;
  const hasDot = s.includes(".");
  const hasComma = s.includes(",");
  let normalized = s;
  if (hasDot && hasComma) {
    // El último separador es el decimal
    if (s.lastIndexOf(",") > s.lastIndexOf(".")) {
      normalized = s.replace(/\./g, "").replace(",", ".");
    } else {
      normalized = s.replace(/,/g, "");
    }
  } else if (hasComma && !hasDot) {
    normalized = s.replace(",", ".");
  }
  const v = Number(normalized.replace(/[^0-9.]/g, ""));
  if (!Number.isFinite(v) || v <= 0) return null;
  return Math.round(v * 1000) / 1000;
}

function parseWiseRate(text: string): number | null {
  const norm = text.replace(/\u00a0/g, " ").replace(/\s+/g, " ");
  const patterns = [
    /1\s*PEN\s*=\s*([\d.,]+)\s*BOB/i,
    /1\s*PEN\s*([\d.,]+)\s*BOB/i,
    /PEN\s*=\s*([\d.,]+)\s*BOB/i,
    /S\/\.\s*1\s*PEN\s*=\s*([\d.,]+)\s*BOB/i,
  ];
  for (const rx of patterns) {
    const m = norm.match(rx);
    if (m) {
      const v = parseEsNumber(m[1]);
      if (v && v > 1 && v < 10) return Math.round(v * 100) / 100;
    }
  }
  return null;
}

async function fetchWiseLive(): Promise<{ wise: number; detail: string }> {
  // 1) JSON libre con CORS (mercado medio, igual metodología que Wise)
  try {
    const res = await fetch(ER_API_URL, { cache: "no-store" });
    if (res.ok) {
      const data = (await res.json()) as { result?: string; rates?: Record<string, number> };
      const v = data?.rates?.BOB;
      if (typeof v === "number" && v > 1 && v < 10) {
        return { wise: Math.round(v * 100) / 100, detail: "er-api" };
      }
    }
  } catch {}
  // 2) Página Wise vía proxy (número exacto publicado por Wise)
  const proxies = [
    `https://api.allorigins.win/raw?url=${encodeURIComponent(WISE_URL)}`,
    `https://api.codetabs.com/v1/proxy?quest=${encodeURIComponent(WISE_URL)}`,
  ];
  let lastErr: unknown = null;
  for (const url of proxies) {
    try {
      const res = await fetch(url, { cache: "no-store" });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const text = await res.text();
      const v = parseWiseRate(text);
      if (v) return { wise: v, detail: "wise-html" };
      lastErr = new Error("Wise sin número legible");
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr instanceof Error ? lastErr : new Error("No se pudo leer Wise");
}

type ProductForm = {
  title: string;
  pricePen: string;
  category: string;
  condition: Condition;
  location: string;
  country: Country;
  shipping: boolean;
  description: string;
  image: string;
  stock: string;
  featured: boolean;
  sold: boolean;
  reserved: boolean;
  requiresLocation: boolean;
  logoEnabled: boolean;
  logoMinQty: string;
  logo1Name: string;
  logo1Price: string;
  logo2Name: string;
  logo2Price: string;
  logo3Name: string;
  logo3Price: string;
  payOptions: string[];
};

const EMPTY_FORM: ProductForm = {
  title: "",
  pricePen: "",
  category: "Hogar",
  condition: "Nuevo",
  location: "Cusco",
  country: "PE",
  shipping: true,
  description: "",
  image: "",
  stock: "1",
  featured: false,
  sold: false,
  reserved: false,
  requiresLocation: false,
  logoEnabled: false,
  logoMinQty: "100",
  logo1Name: "Logo bordado premium",
  logo1Price: "5",
  logo2Name: "Logo estampado full color",
  logo2Price: "3",
  logo3Name: "Logo sublimado / láser",
  logo3Price: "4",
  payOptions: ["Tarjeta", "Yape"],
};

function formatPen(n: number) {
  return `S/ ${new Intl.NumberFormat("es-PE", { maximumFractionDigits: 0 }).format(n)}`;
}
function formatBob(n: number) {
  return `Bs ${new Intl.NumberFormat("es-BO", { maximumFractionDigits: 0 }).format(n)}`;
}
function nowTime() {
  return new Date().toLocaleTimeString("es-PE", { hour: "2-digit", minute: "2-digit" });
}

export default function App() {
  const [page, setPage] = useState<"tienda" | "empresa" | "admin">("tienda");
  const [rateMeta, setRateMeta] = useState<RateMeta>(() => loadRateMeta());
  const [rate, setRate] = useState<number>(() => {
    const m = loadRateMeta();
    if (m.wise) return m.wise;
    return loadRate();
  });
  const [rateDraft, setRateDraft] = useState<string>(() => String(loadRate()));
  const [rateLoading, setRateLoading] = useState(false);
  const [rateError, setRateError] = useState<string | null>(null);
  const [products, setProducts] = useState<Product[]>(() => loadProducts());
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<string>("Todos");
  const [conditions, setConditions] = useState<Condition[]>([]);
  const [maxPrice, setMaxPrice] = useState(700);
  const [country, setCountry] = useState<"ALL" | Country>("ALL");
  const [sort, setSort] = useState<"relevancia" | "menor" | "mayor" | "vistos">("relevancia");
  const [showFavs, setShowFavs] = useState(false);
  const [hideSold, setHideSold] = useState(true);

  const bobOf = (pen: number) => Math.round(pen * rate);
  const logoExtraOf = (p: Product, logoIndex?: number | null) => {
    if (logoIndex == null || !p.logoEnabled || !p.logoOptions) return 0;
    return p.logoOptions[logoIndex]?.extraPen ?? 0;
  };
  const logoNameOf = (p: Product, logoIndex?: number | null) => {
    if (logoIndex == null || !p.logoEnabled || !p.logoOptions) return null;
    return p.logoOptions[logoIndex]?.name ?? null;
  };

  const [favorites, setFavorites] = useState<number[]>([3]);
  const [cart, setCart] = useState<CartLine[]>([]);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [detailQty, setDetailQty] = useState(1);
  const [detailLogo, setDetailLogo] = useState<number | null>(null);
  const [detailPay, setDetailPay] = useState<string>("Coordinar por WhatsApp");
  const [paySettings, setPaySettings] = useState<PaySettings>(() => loadPaySettings());
  const cardLink = paySettings.cardLink.trim();
  const cardEnabled = paySettings.cardEnabled && isValidCardLink(cardLink);
  const [buyer, setBuyer] = useState<BuyerLocation>({ name: "", country: "Perú", city: "", address: "" });
  const [ship, setShip] = useState<ShipState>(() => loadShip());
  const [adminTab, setAdminTab] = useState<"productos" | "envios" | "logos" | "pagos">("productos");
  const [detailCountry, setDetailCountry] = useState("Perú");
  const [detailCity, setDetailCity] = useState("Cusco");
  const [detailDom, setDetailDom] = useState("Recojo en tienda");
  const [detailAddress, setDetailAddress] = useState("");
  const [cartOpen, setCartOpen] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const [chatProductId, setChatProductId] = useState<number | null>(3);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [mobileTab, setMobileTab] = useState<"inicio" | "buscar" | "favs" | "cesta" | "chats">("inicio");
  const [toast, setToast] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMsg[]>([
    { from: "seller", text: "¡Hola! Soy de JH Importaciones. Pregúntame por stock, tallas o envíos a Perú y Bolivia.", time: "10:24" },
  ]);
  const [draft, setDraft] = useState("");
  const searchRef = useRef<HTMLInputElement>(null);

  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [payMethod, setPayMethod] = useState<"card" | "whatsapp">("whatsapp");

  // ---- Admin (editar productos desde otra pestaña) ----
  const [adminUnlocked, setAdminUnlocked] = useState<boolean>(() => {
    try {
      return localStorage.getItem(ADMIN_KEY) === "1";
    } catch {
      return false;
    }
  });
  const [adminPin, setAdminPin] = useState("");
  const [storedPin, setStoredPin] = useState<string>(() => loadStoredPin());
  const [pinCurrent, setPinCurrent] = useState("");
  const [pinNew, setPinNew] = useState("");
  const [pinConfirm, setPinConfirm] = useState("");
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState<ProductForm>(EMPTY_FORM);
  const [formImagePreview, setFormImagePreview] = useState("");
  const [adminSearch, setAdminSearch] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  function saveNewPin() {
    if (pinCurrent.trim() !== storedPin) {
      showToast("Tu contraseña actual no coincide");
      return;
    }
    if (!/^\d{4,8}$/.test(pinNew.trim())) {
      showToast("Nueva clave: solo números, 4 a 8 dígitos");
      return;
    }
    if (pinNew.trim() !== pinConfirm.trim()) {
      showToast("La confirmación no coincide");
      return;
    }
    const next = pinNew.trim();
    setStoredPin(next);
    try {
      localStorage.setItem(ADMIN_PIN_KEY, next);
    } catch {}
    setPinCurrent("");
    setPinNew("");
    setPinConfirm("");
    showToast("Contraseña de administrador actualizada");
  }

  useEffect(() => {
    try {
      localStorage.setItem(PRODUCTS_KEY, JSON.stringify(products));
    } catch {
      /* sin almacenamiento */
    }
  }, [products]);

  useEffect(() => {
    try {
      localStorage.setItem(RATE_KEY, String(rate));
    } catch {
      /* sin almacenamiento */
    }
  }, [rate]);

  useEffect(() => {
    try {
      localStorage.setItem(RATE_META_KEY, JSON.stringify(rateMeta));
    } catch {
      /* sin almacenamiento */
    }
  }, [rateMeta]);

  useEffect(() => {
    try {
      localStorage.setItem(SHIP_KEY, JSON.stringify(ship));
    } catch {
      /* sin almacenamiento */
    }
  }, [ship]);

  useEffect(() => {
    try {
      localStorage.setItem(PAY_SETTINGS_KEY, JSON.stringify(paySettings));
    } catch {
      /* sin almacenamiento */
    }
  }, [paySettings]);

  useEffect(() => {
    if (!paySettings.cardEnabled) {
      setPayMethod("whatsapp");
      if (detailPay === "Tarjeta") {
        const p = products.find((x) => x.id === selectedId) ?? null;
        const opts = p ? visiblePayOptions(p, false) : [];
        setDetailPay(opts[0] ?? "Coordinar por WhatsApp");
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [paySettings.cardEnabled]);

  const shipPrice = (list: ShipOption[], name: string) =>
    list.find((x) => x.name === name)?.pricePen ?? 0;
  const shipCountryPrice = (name: string) => shipPrice(ship.countries, name);
  const shipCityPrice = (name: string) => shipPrice(ship.cities, name);
  const shipDomPrice = (name: string) => shipPrice(ship.doms, name);
  const shipTotalPen = (c: string, ci: string, d: string) =>
    shipCountryPrice(c) + shipCityPrice(ci) + shipDomPrice(d);

  async function syncLive(auto = false) {
    if (rateLoading) return;
    setRateLoading(true);
    setRateError(null);
    try {
      const w = await fetchWiseLive();
      const roundedWise = Math.round(w.wise * 100) / 100;
      const fromWise = w.detail === "wise-html";
      setRate(roundedWise);
      setRateDraft(String(roundedWise));
      setRateMeta((m) => ({
        ...m,
        wise: roundedWise,
        source: fromWise ? "wise-live" : "market-live",
        updatedAt: Date.now(),
        wiseUpdatedAt: fromWise ? Date.now() : m.wiseUpdatedAt,
      }));
      if (!auto) showToast(`${fromWise ? "Wise" : "Mercado referencial"}: 1 S/ = Bs ${roundedWise.toFixed(2)}`);
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Error de conexión";
      setRateError(msg);
      if (!auto) showToast("No se pudo consultar la tasa. Revisa tu internet o usa el valor manual.");
    } finally {
      setRateLoading(false);
    }
  }

  // Reintenta la consulta al abrir, cada 10 min y al volver a la pestaña.
  useEffect(() => {
    // Forzar auto siempre activo para que nunca quede desactualizado
    setRateMeta((m) => (m.auto ? m : { ...m, auto: true }));
    syncLive(true);
    const id = window.setInterval(() => syncLive(true), 10 * 60 * 1000);
    const onVisible = () => {
      if (document.visibilityState === "visible") syncLive(true);
    };
    document.addEventListener("visibilitychange", onVisible);
    window.addEventListener("focus", onVisible);
    return () => {
      window.clearInterval(id);
      document.removeEventListener("visibilitychange", onVisible);
      window.removeEventListener("focus", onVisible);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const selected = products.find((p) => p.id === selectedId) ?? null;
  const chatProduct = products.find((p) => p.id === chatProductId) ?? products[0];

  function showToast(text: string) {
    setToast(text);
    window.setTimeout(() => setToast(null), 2200);
  }

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    let list = products.filter((p) => {
      if (category !== "Todos" && p.category !== category) return false;
      if (conditions.length > 0 && !conditions.includes(p.condition)) return false;
      if (p.pricePen > maxPrice) return false;
      if (country !== "ALL" && p.country !== country) return false;
      if (hideSold && p.sold) return false;
      if (showFavs && !favorites.includes(p.id)) return false;
      if (q && !`${p.title} ${p.description} ${p.category} ${p.location}`.toLowerCase().includes(q)) return false;
      return true;
    });
    if (sort === "menor") list = [...list].sort((a, b) => a.pricePen - b.pricePen);
    if (sort === "mayor") list = [...list].sort((a, b) => b.pricePen - a.pricePen);
    if (sort === "vistos") list = [...list].sort((a, b) => b.views - a.views);
    if (sort === "relevancia")
      list = [...list].sort((a, b) => Number(b.featured ?? false) - Number(a.featured ?? false));
    return list;
  }, [query, category, conditions, maxPrice, country, sort, showFavs, hideSold, favorites]);

  const cartDetailed = cart
    .map((l) => {
      const product = products.find((p) => p.id === l.id)!;
      if (!product) return null;
      const logoIndex = l.logoIndex ?? null;
      const extra = logoExtraOf(product, logoIndex);
      const unitPen = product.pricePen + extra;
      const sc = l.shipCountry ?? ship.countries[0]?.name ?? "Perú";
      const sci = l.shipCity ?? ship.cities[0]?.name ?? "Cusco";
      const sd = l.shipDom ?? ship.doms[0]?.name ?? "Recojo en tienda";
      const shipPen = shipTotalPen(sc, sci, sd);
      const payType = l.payType && (l.payType !== "Tarjeta" || cardEnabled)
        ? l.payType.trim()
        : visiblePayOptions(product, cardEnabled)[0];
      return {
        ...l,
        logoIndex,
        product,
        payType,
        extra,
        unitPen,
        unitBob: Math.round(unitPen * rate),
        logoName: logoNameOf(product, logoIndex),
        shipCountry: sc,
        shipCity: sci,
        shipDom: sd,
        shipAddress: l.shipAddress ?? "",
        shipPen,
        shipBob: Math.round(shipPen * rate),
        linePen: unitPen * l.qty + shipPen,
        lineBob: Math.round((unitPen * l.qty + shipPen) * rate),
      };
    })
    .filter((x): x is NonNullable<typeof x> => !!x?.product);
  const subPen = cartDetailed.reduce((s, l) => s + l.unitPen * l.qty, 0);
  const shipPenTotal = cartDetailed.reduce((s, l) => s + l.shipPen, 0);
  const totalPen = subPen + shipPenTotal;
  const totalBob = Math.round(totalPen * rate);
  const cartCount = cartDetailed.reduce((s, l) => s + l.qty, 0);
  const buyerOk = buyer.name.trim().length >= 2;
  const locationOk =
    buyer.name.trim().length >= 2 &&
    cartDetailed.every((l) => !l.product.requiresLocation || (l.shipAddress ?? "").trim().length >= 4);
  const buyerLine = `Cliente: ${buyer.name || "........"} · Destino: ${cartDetailed[0]?.shipCountry ?? buyer.country ?? ""} / ${cartDetailed[0]?.shipCity ?? buyer.city ?? ""} / ${cartDetailed[0]?.shipAddress || buyer.address || "......."}`;

  useEffect(() => {
    setDetailQty(1);
    setDetailLogo(null);
    const p = products.find((x) => x.id === selectedId) ?? null;
    const opts = p ? visiblePayOptions(p, paySettings.cardEnabled) : [];
    setDetailPay(opts[0] ?? "Coordinar por WhatsApp");
    if (!paySettings.cardEnabled) {
      setPayMethod("whatsapp");
    }
    setDetailCountry(ship.countries[0]?.name ?? "Perú");
    setDetailCity(ship.cities[0]?.name ?? "Cusco");
    setDetailDom(ship.doms[0]?.name ?? "Recojo en tienda");
    setDetailAddress("");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedId]);

  function applyRate(value: string, source: RateMeta["source"] = "manual") {
    const parsed = Number(value.replace(",", "."));
    if (!Number.isFinite(parsed) || parsed <= 0) {
      showToast("Ingresa un tipo de cambio válido");
      return;
    }
    const rounded = Math.round(parsed * 100) / 100;
    setRate(rounded);
    setRateDraft(String(rounded));
    setRateMeta((m) => ({
      ...m,
      source,
      updatedAt: Date.now(),
    }));
    showToast(`Tipo de cambio actualizado: 1 S/ = Bs ${rounded.toFixed(2)}`);
  }

  function toggleFav(id: number) {
    setFavorites((f) => {
      const has = f.includes(id);
      showToast(has ? "Quitado de favoritos" : "Guardado en favoritos");
      return has ? f.filter((x) => x !== id) : [...f, id];
    });
  }
  function toggleCondition(c: Condition) {
    setConditions((prev) => (prev.includes(c) ? prev.filter((x) => x !== c) : [...prev, c]));
  }
  function addToCart(
    id: number,
    qty = 1,
    logoIndex?: number | null,
    shipSel?: { country?: string; city?: string; dom?: string; address?: string },
    payType?: string
  ) {
    const p = products.find((x) => x.id === id);
    if (!p || p.sold) return;
    const li = logoIndex ?? null;
    const pay = payType && (payType !== "Tarjeta" || cardEnabled)
      ? payType.trim()
      : visiblePayOptions(p, cardEnabled)[0];
    if (p.logoEnabled && li != null) {
      const min = p.logoMinQty && p.logoMinQty > 0 ? p.logoMinQty : 100;
      if (qty < min) {
        showToast(`Pedido con logo: mínimo ${min} unidades`);
        qty = min;
      }
    }
    if (qty < 1) qty = 1;
    const sc = shipSel?.country ?? detailCountry ?? ship.countries[0]?.name ?? "Perú";
    const sci = shipSel?.city ?? detailCity ?? ship.cities[0]?.name ?? "Cusco";
    const sd = shipSel?.dom ?? detailDom ?? ship.doms[0]?.name ?? "Recojo en tienda";
    const sa = shipSel?.address ?? detailAddress ?? "";
    const maxStock = Math.max(p.stock, p.logoEnabled && li != null ? (p.logoMinQty ?? 100) : p.stock);
    setCart((prev) => {
      const found = prev.find(
        (l) =>
          l.id === id &&
          (l.logoIndex ?? null) === li &&
          (l.shipCountry ?? "") === sc &&
          (l.shipCity ?? "") === sci &&
          (l.shipDom ?? "") === sd &&
          (l.payType ?? "") === pay
      );
      if (found)
        return prev.map((l) =>
          l.id === id && (l.logoIndex ?? null) === li && (l.shipCountry ?? "") === sc && (l.shipCity ?? "") === sci && (l.shipDom ?? "") === sd && (l.payType ?? "") === pay
            ? { ...l, qty: Math.min(l.qty + qty, maxStock), shipAddress: sa || l.shipAddress }
            : l
        );
      return [...prev, { id, qty: Math.min(qty, maxStock), logoIndex: li, shipCountry: sc, shipCity: sci, shipDom: sd, shipAddress: sa, payType: pay }];
    });
    showToast(`Añadido · pago con ${pay}`);
  }
  function setQty(id: number, qty: number, logoIndex?: number | null, shipCountry?: string, shipCity?: string, shipDom?: string, payType?: string) {
    if (qty <= 0) {
      setCart((prev) =>
        prev.filter((l) => {
          if (l.id !== id) return true;
          if ((l.logoIndex ?? null) !== (logoIndex ?? null)) return true;
          if (shipCountry && (l.shipCountry ?? "") !== shipCountry) return true;
          if (shipCity && (l.shipCity ?? "") !== shipCity) return true;
          if (shipDom && (l.shipDom ?? "") !== shipDom) return true;
          if (payType && (l.payType ?? "") !== payType) return true;
          return false;
        })
      );
    } else
      setCart((prev) =>
        prev.map((l) => {
          if (l.id !== id) return l;
          if ((l.logoIndex ?? null) !== (logoIndex ?? null)) return l;
          if (shipCountry && (l.shipCountry ?? "") !== shipCountry) return l;
          if (shipCity && (l.shipCity ?? "") !== shipCity) return l;
          if (shipDom && (l.shipDom ?? "") !== shipDom) return l;
          if (payType && (l.payType ?? "") !== payType) return l;
          return { ...l, qty };
        })
      );
  }
  function removeLine(id: number, logoIndex?: number | null, shipCountry?: string, shipCity?: string, shipDom?: string, payType?: string) {
    const li = logoIndex ?? null;
    setCart((prev) =>
      prev.filter((l) => {
        if (l.id !== id) return true;
        if ((l.logoIndex ?? null) !== li) return true;
        if (shipCountry && (l.shipCountry ?? "") !== shipCountry) return true;
        if (shipCity && (l.shipCity ?? "") !== shipCity) return true;
        if (shipDom && (l.shipDom ?? "") !== shipDom) return true;
        if (payType && (l.payType ?? "") !== payType) return true;
        if (shipCountry === undefined && shipCity === undefined && shipDom === undefined && payType === undefined) return false;
        return true;
      })
    );
  }
  function openChat(productId?: number) {
    if (productId) {
      setChatProductId(productId);
      const p = products.find((x) => x.id === productId);
      if (p) {
        setMessages((m) => [
          ...m,
          { from: "seller", text: `Te hablo por “${p.title}” (${formatPen(p.pricePen)} / ${formatBob(bobOf(p.pricePen))}). ¿Te ayudo con talla o envío?`, time: nowTime() },
        ]);
      }
    }
    setChatOpen(true);
    setMobileTab("chats");
  }
  function sendMessage(text: string) {
    const clean = text.trim();
    if (!clean) return;
    setMessages((m) => [...m, { from: "me", text: clean, time: nowTime() }]);
    setDraft("");
    window.setTimeout(() => {
      const low = clean.toLowerCase();
      let reply = "¡Gracias por escribir! Te confirmo stock y te mando fotos reales por aquí mismo.";
      if (low.includes("disponible") || low.includes("sigue") || low.includes("stock"))
        reply = "Sí, sigue disponible. Es de mi tienda personal, lo tengo yo mismo y puedo enviarlo hoy.";
      else if (low.includes("envio") || low.includes("envío") || low.includes("bolivia") || low.includes("peru") || low.includes("perú"))
        reply = "Hago envíos a todo Perú (Shalom / Olva) y a Bolivia (Trans Copacabana). El costo se calcula por ciudad, dime a dónde sería.";
      else if (low.includes("oferta") || low.includes("precio") || low.includes("descuento") || low.includes("rebaja"))
        reply = "Puedo mejorarte un poco el precio si llevas 2 prendas o si recoges en Cusco. ¿Cuál te gusta más?";
      else if (low.includes("talla") || low.includes("medida"))
        reply = "Te paso las medidas exactas en un momento y si quieres hacemos videollamada para que lo veas al detalle.";
      else if (low.includes("pago") || low.includes("yape") || low.includes("qr"))
        reply = "Acepto Yape, Plin, transferencia BCP y QR simple para Bolivia. También pago contra entrega en Cusco centro.";
      setMessages((m) => [...m, { from: "seller", text: reply, time: nowTime() }]);
    }, 900);
  }

  function shortTitle(t: string, n = 34) {
    const c = (t || "").replace(/\s+/g, " ").trim();
    return c.length <= n ? c : c.slice(0, n - 1) + "…";
  }
  function waUrl(msg: string) {
    return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`;
  }
  function waProductLink(p: Product, logoIndex?: number | null, qty = 1, payType?: string) {
    const li = logoIndex ?? null;
    const extra = logoExtraOf(p, li);
    const upen = p.pricePen + extra;
    const ubob = Math.round(upen * rate);
    const pay = payType && (payType !== "Tarjeta" || cardEnabled)
      ? payType.trim()
      : visiblePayOptions(p, cardEnabled)[0];
    const logoTxt = li != null && p.logoOptions?.[li] ? ` | Logo: ${shortTitle(p.logoOptions[li].name, 28)} (+S/${extra})` : "";
    const locTxt = p.requiresLocation ? " | Ubic: " + (buyer.country || "") + "/" + (buyer.city || "") + "/" + (buyer.address || "") : "";
    return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(
      `Hola *JH* IMPORTACIONES.\nVengo de TIKTOK.\n- Quiero este producto: ${p.title}\n- Cantidad: ${qty}${logoTxt}\n- Precio unit.: ${formatPen(upen)} / ${formatBob(ubob)} (TC ${rate.toFixed(2)}) | Pago: ${pay}\n- Mi nombre es: ${buyer.name || ".........."}${locTxt}\n- Y mi consulta es: Quiero comprarlo, ¿sigue disponible?`
    )}`;
  }

  const waLink = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(
    `Hola *JH* IMPORTACIONES.\nVengo de TIKTOK.\n- Mi nombre es: ${buyer.name || ".........."}\n- ${buyerLine}\n- Quiero comprar: ${cartDetailed
      .map(
        (l) =>
          `${l.qty}x ${l.product.title}${l.logoName ? ` [${l.logoName}]` : ""} prod ${formatPen(l.unitPen * l.qty)} + env ${l.shipCountry}/${l.shipCity}/${l.shipDom} +${formatPen(l.shipPen)} = ${formatPen(l.linePen)} [Pago: ${l.payType}]`
      )
      .join(", ")}\n- Total: ${formatPen(totalPen)} / ${formatBob(totalBob)} (TC ${rate.toFixed(2)})\n- Y mi consulta es: ¿Cómo coordinamos pago y envío?`
  )}`;

  const quoteCode = useMemo(() => {
    const d = new Date();
    const pad = (n: number) => String(n).padStart(2, "0");
    return `COT-${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${String(cartCount).padStart(2, "0")}${String(Math.abs(totalPen) % 1000).padStart(3, "0")}`;
  }, [cartCount, totalPen]);

  const waShortMsg = useMemo(() => {
    const maxItems = 5;
    const items = cartDetailed.slice(0, maxItems).map((l, i) => `${i + 1}) ${l.qty}x ${shortTitle(l.product.title, 30)} S/${l.linePen} [${l.payType}]`);
    if (cartDetailed.length > maxItems) items.push(`...y ${cartDetailed.length - maxItems} item(s) mas (ver PDF)`);
    const paySummary = [...new Set(cartDetailed.map((l) => l.payType))].join(" + ") || "Coordinar por WhatsApp";
    return [
      "Hola JH IMPORTACIONES, vengo de TikTok.",
      `Soy: ${(buyer.name || "").trim() || ".........."} `,
      `Pedido ${quoteCode}:`,
      ...items,
      `Subtotal: S/${subPen} + Envios: S/${shipPenTotal}`,
      `TOTAL: S/${totalPen} / Bs ${totalBob} (TC ${rate.toFixed(2)})`,
      `Pago: ${paySummary}`,
      `${buyerLine}`,
      "Tengo el PDF del presupuesto, lo adjunto. Me confirma stock?",
    ].join("\n");
  }, [cartDetailed, buyer.name, buyerLine, quoteCode, subPen, shipPenTotal, totalPen, totalBob, rate]);

  const waLinkFixed = waUrl(waShortMsg);
  void waLink;

  function copyWaMsg() {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(waShortMsg).then(
        () => showToast("Texto copiado, pegalo en WhatsApp"),
        () => showToast("No se pudo copiar")
      );
    } else {
      showToast("Copia manual el resumen");
    }
  }

  function pdfInput(kind: "PRESUPUESTO" | "PEDIDO") {
    return {
      kind,
      code: quoteCode,
      date: new Date().toLocaleString("es-PE", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" }),
      rate,
      client: {
        name: buyer.name || "-",
        country: cartDetailed[0]?.shipCountry ?? buyer.country ?? "",
        city: cartDetailed[0]?.shipCity ?? buyer.city ?? "",
        address: cartDetailed[0]?.shipAddress || buyer.address || "",
      },
      lines: cartDetailed.map((l) => ({
        qty: l.qty,
        title: l.product.title,
        logoName: l.logoName ?? null,
        extraPen: l.extra,
        unitPen: l.unitPen,
        unitBob: l.unitBob,
        shipCountry: l.shipCountry,
        shipCity: l.shipCity,
        shipDom: l.shipDom,
        shipAddress: l.shipAddress ?? "",
        shipPen: l.shipPen,
        shipBob: l.shipBob,
        linePen: l.linePen,
        lineBob: l.lineBob,
        payType: l.payType,
      })),
      subPen,
      shipPen: shipPenTotal,
      totalPen,
      totalBob,
      payMethod: [...new Set(cartDetailed.map((l) => l.payType))].join(" + ") + (payMethod === "card" ? " · enlace externo, pendiente" : " · coord. WhatsApp"),
      whatsapp: WHATSAPP_NUMBER,
    };
  }

  function handleDownloadPdf(kind: "PRESUPUESTO" | "PEDIDO") {
    if (cartDetailed.length === 0) {
      showToast("Tu cesta esta vacia");
      return;
    }
    downloadPdf(pdfInput(kind));
    showToast(kind === "PRESUPUESTO" ? "Presupuesto PDF descargado" : "Pedido PDF descargado");
  }

  async function handleSharePdf(kind: "PRESUPUESTO" | "PEDIDO") {
    if (cartDetailed.length === 0) {
      showToast("Tu cesta esta vacia");
      return;
    }
    const input = pdfInput(kind);
    const short = kind === "PRESUPUESTO" ? `${waShortMsg}\nAdjunto PDF ${input.code}.` : `Hola JH, adjunto ${input.code} por S/${totalPen} / Bs ${totalBob}. Soy ${buyer.name || "cliente"}. Lo confirmamos?`;
    try {
      await sharePdfToWhatsApp(input, WHATSAPP_NUMBER, short);
      showToast("PDF listo: revisa WhatsApp");
    } catch {
      showToast("No se pudo compartir el PDF");
    }
  }

  function openCheckout(method: "card" | "whatsapp") {
    if (cartDetailed.length === 0) {
      showToast("Tu cesta está vacía");
      return;
    }
    if (method === "card" && !cardEnabled) {
      showToast("Pago con tarjeta desactivado");
      setPayMethod("whatsapp");
    } else {
      setPayMethod(method);
    }
    setCheckoutOpen(true);
    setCartOpen(false);
  }

  const related = selected ? products.filter((p) => p.category === selected.category && p.id !== selected.id).slice(0, 4) : [];

  // ---------- Lógica Admin: quitar / subir / editar ----------
  const adminFiltered = products.filter((p) => {
    const q = adminSearch.trim().toLowerCase();
    if (!q) return true;
    return `${p.title} ${p.category} ${p.location}`.toLowerCase().includes(q);
  });

  function startNewProduct() {
    setEditingId(null);
    setForm(EMPTY_FORM);
    setFormImagePreview("");
  }

  function startEditProduct(p: Product) {
    setEditingId(p.id);
    const opts = p.logoOptions ?? [];
    setForm({
      title: p.title,
      pricePen: String(p.pricePen),
      category: p.category,
      condition: p.condition,
      location: p.location,
      country: p.country,
      shipping: p.shipping,
      description: p.description,
      image: p.image.startsWith("data:") ? "" : p.image,
      stock: String(p.stock),
      featured: !!p.featured,
      sold: !!p.sold,
      reserved: !!p.reserved,
      requiresLocation: !!p.requiresLocation,
      logoEnabled: !!p.logoEnabled,
      logoMinQty: String(p.logoMinQty ?? 100),
      logo1Name: opts[0]?.name ?? "Logo bordado premium",
      logo1Price: String(opts[0]?.extraPen ?? 5),
      logo2Name: opts[1]?.name ?? "Logo estampado full color",
      logo2Price: String(opts[1]?.extraPen ?? 3),
      logo3Name: opts[2]?.name ?? "Logo sublimado / láser",
      logo3Price: String(opts[2]?.extraPen ?? 4),
      payOptions: normalizePayOptions(p.payOptions),
    });
    setFormImagePreview(p.image);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function handleAdminImageFile(file: File | undefined) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const url = String(reader.result ?? "");
      setFormImagePreview(url);
      setForm((f) => ({ ...f, image: "" }));
    };
    reader.readAsDataURL(file);
  }

  function buildLogoOptionsFromForm(): { opts: LogoOption[]; minQty: number } {
    const minQty = Math.max(1, Math.round(Number(form.logoMinQty)) || 100);
    const raw: LogoOption[] = [
      { name: form.logo1Name.trim() || "Opción logo 1", extraPen: Math.max(0, Math.round(Number(form.logo1Price)) || 0) },
      { name: form.logo2Name.trim() || "Opción logo 2", extraPen: Math.max(0, Math.round(Number(form.logo2Price)) || 0) },
      { name: form.logo3Name.trim() || "Opción logo 3", extraPen: Math.max(0, Math.round(Number(form.logo3Price)) || 0) },
    ];
    return { opts: form.logoEnabled ? raw : [], minQty };
  }

  function saveProduct() {
    const price = Math.round(Number(form.pricePen));
    const stock = Math.max(1, Math.round(Number(form.stock)) || 1);
    if (!form.title.trim()) {
      showToast("Ponle un nombre al producto");
      return;
    }
    if (!Number.isFinite(price) || price <= 0) {
      showToast("Precio en soles inválido");
      return;
    }
    const img = formImagePreview || form.image.trim() || LOGO_ICON_URL;
    const { opts, minQty } = buildLogoOptionsFromForm();
    const finalStock = form.logoEnabled ? Math.max(stock, minQty) : stock;
    if (editingId) {
      setProducts((prev) =>
        prev.map((p) =>
          p.id === editingId
            ? {
                ...p,
                title: form.title.trim(),
                pricePen: price,
                priceBob: Math.round(price * rate),
                category: form.category,
                condition: form.condition,
                location: form.location.trim() || "Cusco",
                country: form.country,
                shipping: form.shipping,
                description: form.description.trim() || "Producto JH Importaciones.",
                image: img,
                stock: finalStock,
                featured: form.featured,
                sold: form.sold,
                reserved: form.reserved,
                requiresLocation: form.requiresLocation,
                logoEnabled: form.logoEnabled,
                logoMinQty: minQty,
                logoOptions: opts,
                payOptions: normalizePayOptions(form.payOptions),
              }
            : p
        )
      );
      showToast("Producto actualizado");
    } else {
      const nextId = Math.max(0, ...products.map((p) => p.id)) + 1;
      const nuevo: Product = {
        id: nextId,
        title: form.title.trim(),
        pricePen: price,
        priceBob: Math.round(price * rate),
        category: form.category,
        condition: form.condition,
        location: form.location.trim() || "Cusco",
        country: form.country,
        shipping: form.shipping,
        description: form.description.trim() || "Producto JH Importaciones.",
        material: "Importado JH",
        size: "Unitalla",
        color: "Ver foto",
        image: img,
        featured: form.featured,
        publishedAt: "ahora mismo",
        views: 0,
        stock: finalStock,
        sold: form.sold,
        reserved: form.reserved,
        requiresLocation: form.requiresLocation,
        logoEnabled: form.logoEnabled,
        logoMinQty: minQty,
        logoOptions: opts,
        payOptions: normalizePayOptions(form.payOptions),
      };
      setProducts((prev) => [nuevo, ...prev]);
      showToast("Producto publicado en tu tienda");
    }
    setEditingId(null);
    setForm(EMPTY_FORM);
    setFormImagePreview("");
  }

  function deleteProduct(id: number) {
    const p = products.find((x) => x.id === id);
    if (!p) return;
    if (!window.confirm(`¿Quitar "${p.title}" de tu tienda?`)) return;
    setProducts((prev) => prev.filter((x) => x.id !== id));
    setCart((prev) => prev.filter((l) => l.id !== id));
    setFavorites((prev) => prev.filter((x) => x !== id));
    if (editingId === id) {
      setEditingId(null);
      setForm(EMPTY_FORM);
      setFormImagePreview("");
    }
    showToast("Producto eliminado");
  }

  function toggleSold(id: number) {
    setProducts((prev) => prev.map((p) => (p.id === id ? { ...p, sold: !p.sold } : p)));
  }

  function resetCatalog() {
    if (!window.confirm("¿Volver al catálogo original? Se borrarán tus cambios.")) return;
    setProducts(DEFAULT_PRODUCTS);
    showToast("Catálogo restaurado");
  }

  return (
    <div className="min-h-screen bg-[#f2f4f5] pb-20 md:pb-0">
      {/* Cinta superior + redes + TC en vivo Wise */}
      <div className="bg-black px-4 py-2 text-white">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-3">
          <div className="flex min-w-0 items-center gap-2 text-[11px] font-semibold tracking-[0.08em] uppercase">
            <span className="hidden shrink-0 items-center gap-1 rounded-full bg-[#13c1ac] px-2 py-0.5 text-[10px] text-[#0b2b27] sm:inline-flex">
              <Store className="h-3 w-3" /> JH Importaciones
            </span>
            <button
              onClick={() => {
                setPage("empresa");
                window.scrollTo({ top: 0, behavior: "smooth" });
              }}
              className="flex min-w-0 items-center gap-1.5 rounded-full bg-white/10 py-1 pl-2 pr-2.5 transition hover:bg-white/20"
              title="Ver cotizacion referencial PEN a BOB y fecha de actualizacion"
            >
              <span className="relative flex h-2 w-2 shrink-0">
                <span className={`absolute inline-flex h-full w-full animate-ping rounded-full opacity-60 ${rateMeta.source !== "manual" ? "bg-emerald-400" : "bg-amber-400"}`} />
                <span className={`relative inline-flex h-2 w-2 rounded-full ${rateMeta.source !== "manual" ? "bg-emerald-400" : "bg-amber-400"}`} />
              </span>
              <Radio className="h-3 w-3 shrink-0 text-emerald-300" />
              <span className="truncate">
                <span className="hidden md:inline">{rateMeta.source === "wise-live" ? "WISE" : rateMeta.source === "market-live" ? "MERCADO" : "REFERENCIAL"} · </span>1 S/ = Bs {rate.toFixed(2)}
                <span className="ml-1 hidden text-white/50 lg:inline">· {timeAgo(rateMeta.updatedAt)}</span>
              </span>
              <RefreshCw className={`h-3 w-3 shrink-0 ${rateLoading ? "animate-spin" : ""}`} />
            </button>
          </div>
          <div className="flex shrink-0 items-center gap-1.5">
            <span className="mr-1 hidden text-[10px] font-bold tracking-[0.14em] text-white/60 uppercase md:inline">Sígueme</span>
            <a
              href={TIKTOK_URL}
              target="_blank"
              rel="noreferrer"
              aria-label="TikTok de JH Importaciones"
              title="TikTok"
              className="grid h-8 w-8 place-items-center rounded-full bg-white/10 transition hover:scale-105 hover:bg-[#fe2c55]"
            >
              <TikTokIcon className="h-4 w-4" />
            </a>
            <a
              href={FACEBOOK_URL}
              target="_blank"
              rel="noreferrer"
              aria-label="Facebook de JH Importaciones"
              title="Facebook"
              className="grid h-8 w-8 place-items-center rounded-full bg-white/10 transition hover:scale-105 hover:bg-[#1877f2]"
            >
              <FacebookIcon className="h-4 w-4" />
            </a>
            <a
              href={WHATSAPP_GENERAL}
              target="_blank"
              rel="noreferrer"
              aria-label="WhatsApp de JH Importaciones"
              title="WhatsApp"
              className="grid h-8 w-8 place-items-center rounded-full bg-[#25d366] text-white transition hover:scale-105 hover:bg-[#1eb856]"
            >
              <WhatsAppIcon className="h-4 w-4" />
            </a>
          </div>
        </div>
      </div>

      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-black/5 bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-3 md:gap-6">
          <button
            onClick={() => {
              setPage("tienda");
              setCategory("Todos");
              setQuery("");
              setShowFavs(false);
              setMobileTab("inicio");
              window.scrollTo({ top: 0, behavior: "smooth" });
            }}
            className="flex shrink-0 items-center gap-2.5"
            aria-label="Ir al inicio"
          >
            <img
              src={LOGO_ICON_URL}
              alt="JH Importaciones"
              className="h-11 w-11 shrink-0 rounded-2xl bg-black object-contain p-0.5 ring-1 ring-black/10"
            />
            <span className="text-left leading-none">
              <span className="block text-[15px] font-extrabold tracking-tight sm:text-[17px]">JH IMPORTACIONES</span>
              <span className="mt-1 hidden items-center gap-1 text-[10px] font-bold tracking-wide text-[#0c9d8c] sm:flex">
                <BadgeCheck className="h-3.5 w-3.5" /> TIENDA VERIFICADA · SOLO YO VENDO
              </span>
              <span className="mt-0.5 block text-[9px] font-bold tracking-[0.14em] text-gray-500 sm:hidden">PRECIO DE FABRICA</span>
            </span>
          </button>

          {/* Pestañas principales */}
          <nav className="ml-1 hidden items-center gap-1 rounded-full bg-[#f2f4f5] p-1 sm:flex" aria-label="Pestañas">
            <button
              onClick={() => setPage("tienda")}
              className={`flex items-center gap-1.5 rounded-full px-4 py-2 text-[13px] font-bold transition ${page === "tienda" ? "bg-[#1d2126] text-white shadow" : "text-gray-600 hover:text-black"}`}
            >
              <Store className="h-4 w-4" /> Tienda
            </button>
            <button
              onClick={() => setPage("empresa")}
              className={`flex items-center gap-1.5 rounded-full px-4 py-2 text-[13px] font-bold transition ${page === "empresa" ? "bg-[#1d2126] text-white shadow" : "text-gray-600 hover:text-black"}`}
            >
              <Building2 className="h-4 w-4" /> Empresa y T.C.
            </button>
            <button
              onClick={() => {
                setPage("admin");
                window.scrollTo({ top: 0, behavior: "smooth" });
              }}
              className={`flex items-center gap-1.5 rounded-full px-4 py-2 text-[13px] font-bold transition ${page === "admin" ? "bg-[#1d2126] text-white shadow" : "text-gray-600 hover:text-black"}`}
            >
              <Settings2 className="h-4 w-4" /> Editar productos
              <span className="rounded-full bg-[#13c1ac] px-1.5 text-[10px] text-[#0b2b27]">{products.length}</span>
            </button>
          </nav>

          <div className="hidden flex-1 md:block">
            <label className="flex items-center gap-2 rounded-full border border-black/10 bg-[#f2f4f5] px-4 py-2.5 transition focus-within:border-[#13c1ac] focus-within:bg-white">
              <Search className="h-5 w-5 shrink-0 text-gray-500" />
              <input
                ref={searchRef}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Buscar en mi tienda: manta, abrigo, poncho…"
                className="w-full bg-transparent text-sm outline-none placeholder:text-gray-500"
              />
              {query && (
                <button onClick={() => setQuery("")} className="rounded-full p-1 hover:bg-black/5" aria-label="Limpiar búsqueda">
                  <X className="h-4 w-4" />
                </button>
              )}
              <span className="hidden shrink-0 items-center gap-1 rounded-full bg-white px-2.5 py-1 text-[11px] font-bold text-gray-700 shadow-sm lg:flex">
                S/ PEN • Bs BOB
              </span>
            </label>
          </div>

          <div className="ml-auto flex items-center gap-1.5 md:gap-2">
            <button
              onClick={() => {
                setShowFavs(!showFavs);
                setMobileTab("favs");
              }}
              className={`relative grid h-10 w-10 place-items-center rounded-full transition ${showFavs ? "bg-[#ffe9ea] text-[#e0445e]" : "hover:bg-black/5"}`}
              aria-label="Favoritos"
            >
              <Heart className={`h-5 w-5 ${showFavs ? "fill-current" : ""}`} />
              {favorites.length > 0 && (
                <span className="absolute -right-0.5 -top-0.5 grid h-5 min-w-5 place-items-center rounded-full bg-[#e0445e] px-1 text-[10px] font-bold text-white">
                  {favorites.length}
                </span>
              )}
            </button>
            <button
              onClick={() => openChat()}
              className="relative grid h-10 w-10 place-items-center rounded-full hover:bg-black/5"
              aria-label="Chats"
            >
              <MessageCircle className="h-5 w-5" />
              <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-[#13c1ac] ring-2 ring-white" />
            </button>
            <button
              onClick={() => {
                setCartOpen(true);
                setMobileTab("cesta");
              }}
              className="relative grid h-10 w-10 place-items-center rounded-full hover:bg-black/5"
              aria-label="Cesta"
            >
              <ShoppingBag className="h-5 w-5" />
              {cartCount > 0 && (
                <span className="absolute -right-0.5 -top-0.5 grid h-5 min-w-5 place-items-center rounded-full bg-[#1d2126] px-1 text-[10px] font-bold text-white">
                  {cartCount}
                </span>
              )}
            </button>
            <img src={SELLER.avatar} alt="Mi foto de vendedora" className="ml-1 hidden h-10 w-10 rounded-full object-cover ring-2 ring-[#13c1ac]/30 sm:block" />
          </div>
        </div>

        {/* Buscador móvil */}
        <div className="px-4 pb-3 md:hidden">
          <label className="flex items-center gap-2 rounded-full border border-black/10 bg-[#f2f4f5] px-4 py-2.5">
            <Search className="h-4 w-4 text-gray-500" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar en mi tienda…"
              className="w-full bg-transparent text-sm outline-none"
            />
          </label>
          <div className="mt-2 grid grid-cols-3 gap-2 sm:hidden">
            <button
              onClick={() => setPage("tienda")}
              className={`flex items-center justify-center gap-1.5 rounded-full py-2.5 text-[13px] font-bold ${page === "tienda" ? "bg-[#1d2126] text-white" : "bg-[#f2f4f5] text-gray-700"}`}
            >
              <Store className="h-4 w-4" /> Tienda
            </button>
            <button
              onClick={() => setPage("empresa")}
              className={`flex items-center justify-center gap-1.5 rounded-full py-2.5 text-[13px] font-bold ${page === "empresa" ? "bg-[#1d2126] text-white" : "bg-[#f2f4f5] text-gray-700"}`}
            >
              <Building2 className="h-4 w-4" /> T.C.
            </button>
            <button
              onClick={() => setPage("admin")}
              className={`flex items-center justify-center gap-1.5 rounded-full py-2.5 text-[13px] font-bold ${page === "admin" ? "bg-[#1d2126] text-white" : "bg-[#f2f4f5] text-gray-700"}`}
            >
              <Settings2 className="h-4 w-4" /> Editar
            </button>
          </div>
        </div>

        {/* Categorías */}
        <div className="border-t border-black/5 bg-white">
          <div className="no-scrollbar mx-auto flex max-w-7xl items-center gap-2 overflow-x-auto px-4 py-2.5">
            {CATEGORIES.map((c) => {
              const count = c === "Todos" ? products.length : products.filter((p) => p.category === c).length;
              const active = category === c;
              return (
                <button
                  key={c}
                  onClick={() => setCategory(c)}
                  className={`flex shrink-0 items-center gap-1.5 rounded-full px-4 py-2 text-[13px] font-semibold transition ${
                    active ? "bg-[#1d2126] text-white" : "bg-[#f2f4f5] text-gray-700 hover:bg-[#e6eaec]"
                  }`}
                >
                  {c}
                  <span className={`rounded-full px-1.5 text-[11px] ${active ? "bg-white/20" : "bg-black/5"}`}>{count}</span>
                </button>
              );
            })}
            <span className="ml-auto hidden shrink-0 items-center gap-1.5 text-xs font-medium text-gray-500 md:flex">
              <MapPin className="h-3.5 w-3.5" /> Cusco · Arequipa · Lima · La Paz · Cbba
            </span>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4">
        {page === "admin" ? (
          <div className="animate-rise pb-10">
            <section className="mt-4 overflow-hidden rounded-3xl bg-black p-6 text-white sm:p-8">
              <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div className="flex items-center gap-4">
                  <img src={LOGO_ICON_URL} alt="JH Importaciones" className="h-16 w-16 rounded-2xl bg-black object-contain p-1 ring-1 ring-white/20" />
                  <div>
                    <p className="flex items-center gap-2 text-[11px] font-bold tracking-[0.2em] text-[#7ce3d3] uppercase">
                      <Settings2 className="h-4 w-4" /> Panel privado · solo dueño
                    </p>
                    <h1 className="mt-1 text-2xl font-extrabold sm:text-3xl">Editar productos</h1>
                    <p className="mt-1 text-[13px] text-white/70">
                      {products.length} productos en tu tienda · Cambios se guardan solos y aparecen en la Tienda al instante.
                    </p>
                  </div>
                </div>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => setPage("tienda")}
                    className="rounded-full bg-white px-5 py-2.5 text-[13px] font-bold text-black transition hover:bg-[#13c1ac]"
                  >
                    Ver tienda
                  </button>
                  <button
                    onClick={resetCatalog}
                    className="flex items-center gap-1.5 rounded-full border border-white/25 px-5 py-2.5 text-[13px] font-bold text-white transition hover:bg-white hover:text-black"
                  >
                    <RotateCcw className="h-4 w-4" /> Restaurar
                  </button>
                </div>
              </div>
            </section>

            {!adminUnlocked ? (
              <section className="mx-auto mt-6 max-w-md rounded-3xl bg-white p-6 text-center shadow-sm sm:p-8">
                <p className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-black text-white">
                  <KeyRound className="h-6 w-6" />
                </p>
                <h2 className="mt-4 text-xl font-extrabold">Zona privada</h2>
                <p className="mt-1 text-sm text-gray-500">
                  Ingresa tu clave de dueño para subir o quitar productos y controlar el tipo de cambio.
                </p>
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (adminPin.trim() === storedPin) {
                      setAdminUnlocked(true);
                      try {
                        localStorage.setItem(ADMIN_KEY, "1");
                      } catch {}
                      showToast("Bienvenido, jefe");
                      startNewProduct();
                    } else {
                      showToast("PIN incorrecto");
                    }
                  }}
                  className="mt-4 flex gap-2"
                >
                  <input
                    value={adminPin}
                    onChange={(e) => setAdminPin(e.target.value)}
                    placeholder="PIN"
                    inputMode="numeric"
                    type="password"
                    className="w-full rounded-2xl border border-black/10 bg-[#f7f8f9] px-4 py-3 text-center text-lg font-extrabold tracking-[0.3em] outline-none focus:border-[#13c1ac]"
                  />
                  <button className="shrink-0 rounded-2xl bg-[#1d2126] px-6 text-sm font-bold text-white hover:bg-[#13c1ac] hover:text-[#0b2b27]">
                    Entrar
                  </button>
                </form>
                <p className="mt-3 text-[11px] text-gray-400">Tus clientes no ven esta pestaña como editable, solo tú con el PIN.</p>
              </section>
            ) : (
              <>
                <div className="mt-6 flex gap-2 overflow-x-auto rounded-3xl bg-white p-2 shadow-sm">
                  {[
                    { k: "productos" as const, l: "📦 Productos" },
                    { k: "envios" as const, l: "🚚 Precios envío" },
                    { k: "logos" as const, l: "🏷️ Logos por producto" },
                    { k: "pagos" as const, l: "💳 Pagos / Tarjeta" },
                  ].map((t) => (
                    <button
                      key={t.k}
                      onClick={() => setAdminTab(t.k)}
                      className={`flex-1 whitespace-nowrap rounded-2xl px-4 py-2.5 text-sm font-extrabold transition ${
                        adminTab === t.k ? "bg-black text-white" : "bg-[#f2f4f5] hover:bg-black/10"
                      }`}
                    >
                      {t.l}
                    </button>
                  ))}
                </div>
                {adminTab === "productos" && (
                <div className="mt-4 grid gap-4 lg:grid-cols-[420px_1fr]">
                {/* Formulario subir / editar */}
                <section className="h-fit rounded-3xl bg-white p-5 shadow-sm sm:p-6 lg:sticky lg:top-36">
                  <div className="flex items-center justify-between">
                    <h2 className="flex items-center gap-2 font-extrabold">
                      {editingId ? <Pencil className="h-5 w-5 text-[#0c9d8c]" /> : <PlusCircle className="h-5 w-5 text-[#0c9d8c]" />}
                      {editingId ? "Editar producto" : "Subir producto nuevo"}
                    </h2>
                    {editingId && (
                      <button onClick={startNewProduct} className="text-xs font-bold text-gray-500 hover:underline">
                        Cancelar
                      </button>
                    )}
                  </div>

                  <button
                    onClick={() => fileRef.current?.click()}
                    className="mt-4 flex w-full items-center gap-3 rounded-2xl border-2 border-dashed border-black/15 bg-[#f7f8f9] p-3 text-left transition hover:border-[#13c1ac]"
                  >
                    {formImagePreview ? (
                      <img src={formImagePreview} alt="Vista previa" className="h-16 w-16 shrink-0 rounded-xl object-cover" />
                    ) : (
                      <span className="grid h-16 w-16 shrink-0 place-items-center rounded-xl bg-black/5">
                        <ImagePlus className="h-6 w-6 text-gray-400" />
                      </span>
                    )}
                    <span>
                      <span className="block text-sm font-bold">Foto del producto</span>
                      <span className="block text-xs text-gray-500">Toca para subir desde tu celular / PC o pega un link abajo</span>
                    </span>
                  </button>
                  <input
                    ref={fileRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => handleAdminImageFile(e.target.files?.[0])}
                  />

                  <div className="mt-4 space-y-3">
                    <label className="block">
                      <span className="text-xs font-bold uppercase text-gray-500">Nombre *</span>
                      <input
                        value={form.title}
                        onChange={(e) => setForm({ ...form, title: e.target.value })}
                        placeholder="Ej. Audífonos Bluetooth Pro JH"
                        className="mt-1 w-full rounded-2xl border border-black/10 bg-[#f7f8f9] px-4 py-2.5 text-sm outline-none focus:border-[#13c1ac]"
                      />
                    </label>
                    <div className="grid grid-cols-2 gap-3">
                      <label className="block">
                        <span className="text-xs font-bold uppercase text-gray-500">Precio S/ *</span>
                        <input
                          value={form.pricePen}
                          onChange={(e) => setForm({ ...form, pricePen: e.target.value })}
                          placeholder="99"
                          inputMode="decimal"
                          className="mt-1 w-full rounded-2xl border border-black/10 bg-[#f7f8f9] px-4 py-2.5 text-sm font-bold outline-none focus:border-[#13c1ac]"
                        />
                        <span className="mt-1 block text-[11px] font-bold text-[#0c9d8c]">
                          = {form.pricePen && Number(form.pricePen) > 0 ? formatBob(bobOf(Math.round(Number(form.pricePen)))) : "Bs 0"} auto
                        </span>
                      </label>
                      <label className="block">
                        <span className="text-xs font-bold uppercase text-gray-500">Stock</span>
                        <input
                          value={form.stock}
                          onChange={(e) => setForm({ ...form, stock: e.target.value })}
                          placeholder="1"
                          inputMode="numeric"
                          className="mt-1 w-full rounded-2xl border border-black/10 bg-[#f7f8f9] px-4 py-2.5 text-sm outline-none focus:border-[#13c1ac]"
                        />
                      </label>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <label className="block">
                        <span className="text-xs font-bold uppercase text-gray-500">Categoría</span>
                        <select
                          value={form.category}
                          onChange={(e) => setForm({ ...form, category: e.target.value })}
                          className="mt-1 w-full rounded-2xl border border-black/10 bg-[#f7f8f9] px-3 py-2.5 text-sm outline-none"
                        >
                          {ADMIN_CATEGORIES.map((c) => (
                            <option key={c} value={c}>{c}</option>
                          ))}
                        </select>
                      </label>
                      <label className="block">
                        <span className="text-xs font-bold uppercase text-gray-500">Estado</span>
                        <select
                          value={form.condition}
                          onChange={(e) => setForm({ ...form, condition: e.target.value as Condition })}
                          className="mt-1 w-full rounded-2xl border border-black/10 bg-[#f7f8f9] px-3 py-2.5 text-sm outline-none"
                        >
                          <option>Nuevo</option>
                          <option>Como nuevo</option>
                          <option>Buen estado</option>
                        </select>
                      </label>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <label className="block">
                        <span className="text-xs font-bold uppercase text-gray-500">Ciudad</span>
                        <input
                          value={form.location}
                          onChange={(e) => setForm({ ...form, location: e.target.value })}
                          placeholder="Cusco"
                          className="mt-1 w-full rounded-2xl border border-black/10 bg-[#f7f8f9] px-4 py-2.5 text-sm outline-none focus:border-[#13c1ac]"
                        />
                      </label>
                      <label className="block">
                        <span className="text-xs font-bold uppercase text-gray-500">País</span>
                        <select
                          value={form.country}
                          onChange={(e) => setForm({ ...form, country: e.target.value as Country })}
                          className="mt-1 w-full rounded-2xl border border-black/10 bg-[#f7f8f9] px-3 py-2.5 text-sm outline-none"
                        >
                          <option value="PE">🇵🇪 Perú</option>
                          <option value="BO">🇧🇴 Bolivia</option>
                        </select>
                      </label>
                    </div>
                    <label className="block">
                      <span className="text-xs font-bold uppercase text-gray-500">Link de foto (opcional si ya subiste)</span>
                      <input
                        value={form.image}
                        onChange={(e) => {
                          setForm({ ...form, image: e.target.value });
                          if (e.target.value.trim()) setFormImagePreview(e.target.value.trim());
                        }}
                        placeholder="https://..."
                        className="mt-1 w-full rounded-2xl border border-black/10 bg-[#f7f8f9] px-4 py-2.5 text-sm outline-none focus:border-[#13c1ac]"
                      />
                    </label>
                    <label className="block">
                      <span className="text-xs font-bold uppercase text-gray-500">Descripción</span>
                      <textarea
                        value={form.description}
                        onChange={(e) => setForm({ ...form, description: e.target.value })}
                        placeholder="Cuenta detalles, medidas, colores, envío..."
                        rows={3}
                        className="mt-1 w-full rounded-2xl border border-black/10 bg-[#f7f8f9] px-4 py-2.5 text-sm outline-none focus:border-[#13c1ac]"
                      />
                    </label>
                    <div className="flex flex-wrap gap-2 text-[13px] font-semibold">
                      <label className="flex cursor-pointer items-center gap-1.5 rounded-full bg-[#f2f4f5] px-3 py-1.5">
                        <input type="checkbox" checked={form.shipping} onChange={(e) => setForm({ ...form, shipping: e.target.checked })} className="accent-[#13c1ac]" /> Envío
                      </label>
                      <label className="flex cursor-pointer items-center gap-1.5 rounded-full bg-[#f2f4f5] px-3 py-1.5">
                        <input type="checkbox" checked={form.featured} onChange={(e) => setForm({ ...form, featured: e.target.checked })} className="accent-[#13c1ac]" /> Destacado
                      </label>
                      <label className="flex cursor-pointer items-center gap-1.5 rounded-full bg-[#f2f4f5] px-3 py-1.5">
                        <input type="checkbox" checked={form.reserved} onChange={(e) => setForm({ ...form, reserved: e.target.checked })} className="accent-[#ffbf3f]" /> Reservado
                      </label>
                      <label className="flex cursor-pointer items-center gap-1.5 rounded-full bg-[#f2f4f5] px-3 py-1.5">
                        <input type="checkbox" checked={form.sold} onChange={(e) => setForm({ ...form, sold: e.target.checked })} className="accent-black" /> Vendido
                      </label>
                      <label className={`flex cursor-pointer items-center gap-1.5 rounded-full px-3 py-1.5 ${form.requiresLocation ? "bg-black text-white" : "bg-[#f2f4f5]"}`}>
                        <input type="checkbox" checked={form.requiresLocation} onChange={(e) => setForm({ ...form, requiresLocation: e.target.checked })} className="accent-[#13c1ac]" /> 📍 Pedir ubicación (país/ciudad/dirección)
                      </label>
                    </div>
                    <div className="rounded-3xl border border-black/10 bg-[#f7f8f9] p-4">
                      <p className="text-sm font-extrabold">💳 Tipo de pago aceptado *</p>
                      <p className="mt-0.5 text-xs text-gray-500">El cliente lo vera en el producto y elegira uno antes de comprar. Marca al menos uno. {cardEnabled ? "Tarjeta habilitada en este navegador." : "Tarjeta oculta: requiere activar un enlace HTTPS valido en Pagos."}</p>
                      <div className="mt-2.5 flex flex-wrap gap-1.5">
                        {PAY_METHODS.map((m) => {
                          const on = form.payOptions.includes(m);
                          return (
                            <button
                              key={m}
                              type="button"
                              onClick={() =>
                                setForm((f) => {
                                  const has = f.payOptions.includes(m);
                                  const next = has ? f.payOptions.filter((x) => x !== m) : [...f.payOptions, m];
                                  return { ...f, payOptions: next.length > 0 ? next : [m] };
                                })
                              }
                              className={`flex items-center gap-1.5 rounded-full px-3.5 py-2 text-[13px] font-bold transition ${on ? "bg-black text-white shadow" : "bg-white text-gray-600 ring-1 ring-black/10 hover:ring-black"}`}
                            >
                              {m === "Tarjeta" ? <CreditCard className="h-3.5 w-3.5" /> : <Wallet className="h-3.5 w-3.5" />}
                              {m}
                            </button>
                          );
                        })}
                      </div>
                      <p className="mt-2 text-[11px] font-semibold text-gray-500">
                        Activos: <span className="font-extrabold text-black">{form.payOptions.join(" · ") || "—"}</span>
                      </p>
                    </div>
                    <div className={`rounded-3xl border p-4 ${form.logoEnabled ? "border-[#13c1ac] bg-[#e6faf6]" : "border-black/10 bg-[#f7f8f9]"}`}>
                      <label className="flex cursor-pointer items-center justify-between gap-2">
                        <span className="text-sm font-extrabold">🏷️ Logo personalizado · pedido mín. 100 und</span>
                        <button
                          type="button"
                          onClick={() => setForm({ ...form, logoEnabled: !form.logoEnabled })}
                          className={`relative h-6 w-11 shrink-0 rounded-full transition ${form.logoEnabled ? "bg-[#13c1ac]" : "bg-gray-300"}`}
                          aria-label="Activar logos"
                        >
                          <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${form.logoEnabled ? "left-[22px]" : "left-0.5"}`} />
                        </button>
                      </label>
                      <p className="mt-1 text-xs text-gray-600">Actívalo y el cliente podrá desplegar 3 tipos de logo con precio extra que se suma solo. Mínimo {form.logoMinQty || 100} und.</p>
                      {form.logoEnabled && (
                        <div className="mt-3 space-y-2">
                          <label className="block">
                            <span className="text-xs font-bold uppercase text-gray-500">Pedido mínimo (unidades)</span>
                            <input value={form.logoMinQty} onChange={(e) => setForm({ ...form, logoMinQty: e.target.value.replace(/[^0-9]/g, "") })} inputMode="numeric" placeholder="100" className="mt-1 w-full rounded-2xl border border-black/10 bg-white px-4 py-2.5 text-sm font-bold outline-none focus:border-[#13c1ac]" />
                          </label>
                          {(
                            [
                              ["logo1Name", "logo1Price", "Logo 1"],
                              ["logo2Name", "logo2Price", "Logo 2"],
                              ["logo3Name", "logo3Price", "Logo 3"],
                            ] as const
                          ).map(([nk, pk, lbl]) => (
                            <div key={nk} className="grid grid-cols-[1fr_110px] gap-2">
                              <input value={form[nk]} onChange={(e) => setForm({ ...form, [nk]: e.target.value })} placeholder={`${lbl} · Ej. Bordado premium`} className="rounded-2xl border border-black/10 bg-white px-3 py-2.5 text-sm outline-none focus:border-[#13c1ac]" />
                              <label className="flex items-center gap-1 rounded-2xl border border-black/10 bg-white px-3 py-2.5">
                                <span className="text-xs font-bold text-gray-500">+S/</span>
                                <input value={form[pk]} onChange={(e) => setForm({ ...form, [pk]: e.target.value.replace(/[^0-9.]/g, "") })} inputMode="decimal" placeholder="5" className="w-full bg-transparent text-sm font-bold outline-none" />
                              </label>
                            </div>
                          ))}
                          <p className="text-[11px] text-gray-500">Ej: base S/ {form.pricePen || "99"} + logo = total por unidad. Bs se calcula con Wise ({rate.toFixed(2)}).</p>
                        </div>
                      )}
                    </div>
                    <button
                      onClick={saveProduct}
                      className="flex w-full items-center justify-center gap-2 rounded-full bg-[#13c1ac] py-3.5 text-sm font-bold text-[#0b2b27] transition hover:bg-[#0c9d8c] hover:text-white"
                    >
                      <Save className="h-4 w-4" /> {editingId ? "Guardar cambios" : "Publicar en mi tienda"}
                    </button>
                    <p className="text-center text-[11px] text-gray-500">El precio en bolivianos se calcula solo con tu tipo de cambio actual (Bs {rate.toFixed(2)}).</p>
                  </div>
                </section>

                {/* Lista para quitar / editar */}
                <section className="rounded-3xl bg-white p-5 shadow-sm sm:p-6">
                  <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                    <h2 className="font-extrabold">Mis productos ({adminFiltered.length})</h2>
                    <label className="flex items-center gap-2 rounded-full bg-[#f2f4f5] px-4 py-2.5">
                      <Search className="h-4 w-4 text-gray-500" />
                      <input
                        value={adminSearch}
                        onChange={(e) => setAdminSearch(e.target.value)}
                        placeholder="Buscar para editar o quitar..."
                        className="w-full bg-transparent text-sm outline-none"
                      />
                    </label>
                  </div>
                  <div className="mt-4 space-y-3">
                    {adminFiltered.map((p) => (
                      <div key={p.id} className={`flex gap-3 rounded-2xl border p-3 ${editingId === p.id ? "border-[#13c1ac] bg-[#e6faf6]" : "border-black/10"}`}>
                        <img src={p.image} alt="" className="h-20 w-20 shrink-0 rounded-xl object-cover" />
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-bold">{p.title}</p>
                          <p className="text-xs text-gray-500">
                            {formatPen(p.pricePen)} · {formatBob(bobOf(p.pricePen))} · Stock {p.stock} {p.sold ? "· VENDIDO" : ""}
                          </p>
                          <p className="mt-1 flex flex-wrap gap-1">
                            {p.requiresLocation && <span className="rounded-full bg-black px-2 py-0.5 text-[10px] font-bold text-white">📍 Pide ubicación</span>}
                            {p.logoEnabled && <span className="rounded-full bg-[#ffbf3f] px-2 py-0.5 text-[10px] font-bold">🏷️ Logo mín. {p.logoMinQty ?? 100} · 3 opciones</span>}
                            <span className="rounded-full bg-[#e6faf6] px-2 py-0.5 text-[10px] font-bold text-[#0b4a43]">💳 {getPayOptions(p).join(" · ")}</span>
                          </p>
                          <div className="mt-2 flex flex-wrap gap-1.5">
                            <button
                              onClick={() => startEditProduct(p)}
                              className="flex items-center gap-1 rounded-full bg-black px-3 py-1.5 text-[11px] font-bold text-white hover:bg-[#13c1ac] hover:text-[#0b2b27]"
                            >
                              <Pencil className="h-3 w-3" /> Editar
                            </button>
                            <button
                              onClick={() => toggleSold(p.id)}
                              className={`rounded-full px-3 py-1.5 text-[11px] font-bold ${p.sold ? "bg-[#ffbf3f]" : "bg-[#f2f4f5] hover:bg-black hover:text-white"}`}
                            >
                              {p.sold ? "Marcar disponible" : "Marcar vendido"}
                            </button>
                            <button
                              onClick={() => deleteProduct(p.id)}
                              className="flex items-center gap-1 rounded-full bg-red-50 px-3 py-1.5 text-[11px] font-bold text-red-600 hover:bg-red-600 hover:text-white"
                            >
                              <Trash2 className="h-3 w-3" /> Quitar
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                    {adminFiltered.length === 0 && (
                      <p className="rounded-2xl bg-[#f7f8f9] p-6 text-center text-sm text-gray-500">No hay productos con esa búsqueda.</p>
                    )}
                  </div>
                  {/* Solo dueño: control tipo de cambio Wise */}
                  <div className="mt-4 rounded-3xl bg-black p-5 text-white sm:p-6">
                    <p className="flex items-center gap-2 text-[11px] font-bold tracking-[0.18em] text-[#7ce3d3] uppercase">
                      <ArrowLeftRight className="h-4 w-4" /> Tipo de cambio referencial · solo en este navegador
                    </p>
                    <div className="mt-2 flex flex-wrap items-center gap-2">
                      <h3 className="text-2xl font-extrabold">1 S/ = Bs {rate.toFixed(2)}</h3>
                      <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-bold ${rateMeta.source !== "manual" ? "bg-emerald-400 text-[#06281f]" : "bg-amber-300 text-[#4a2f00]"}`}>
                        {rateMeta.source === "wise-live" ? "Wise" : rateMeta.source === "market-live" ? "Mercado" : "Manual"} · {timeAgo(rateMeta.updatedAt)}
                      </span>
                    </div>
                    <div className="mt-3 rounded-2xl bg-[#13c1ac] p-4 text-[#06281f]">
                      <p className="text-[11px] font-extrabold tracking-wide uppercase opacity-80">{rateMeta.source === "wise-live" ? "Wise" : "Tasa de mercado referencial"}</p>
                      <p className="mt-0.5 text-2xl font-extrabold">Bs {rateMeta.wise?.toFixed(2) ?? "--"}</p>
                      <p className="text-[12px] opacity-70">Ultima consulta exitosa · {timeAgo(rateMeta.updatedAt)}</p>
                    </div>
                    <div className="mt-3 flex flex-wrap gap-2">
                      <button
                        onClick={() => syncLive(false)}
                        disabled={rateLoading}
                        className="flex items-center gap-1.5 rounded-full bg-[#13c1ac] px-4 py-2 text-[13px] font-extrabold text-[#06281f] hover:bg-white disabled:opacity-60"
                      >
                        <RefreshCw className={`h-4 w-4 ${rateLoading ? "animate-spin" : ""}`} />
                        {rateLoading ? "Consultando tasa..." : "Consultar tasa ahora"}
                      </button>
                      <a href={WISE_URL} target="_blank" rel="noreferrer" className="flex items-center gap-1.5 rounded-full border border-white/25 px-4 py-2 text-[13px] font-bold hover:bg-white hover:text-black">
                        Abrir Wise <ExternalLink className="h-3.5 w-3.5" />
                      </a>
                    </div>
                    {rateError && <p className="mt-2 text-xs text-red-300">Wise no respondió ({rateError}). Se mantiene último valor guardado.</p>}
                    <div className="mt-3 flex flex-col gap-2 sm:flex-row">
                      <label className="flex flex-1 items-center gap-2 rounded-2xl bg-white/10 px-4 py-2.5">
                        <span className="text-xs font-bold text-white/60">Bs por S/ manual</span>
                        <input
                          value={rateDraft}
                          onChange={(e) => setRateDraft(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") {
                              e.preventDefault();
                              applyRate(rateDraft, "manual");
                            }
                          }}
                          inputMode="decimal"
                          placeholder="3.50"
                          className="w-full bg-transparent font-extrabold outline-none placeholder:text-white/30"
                        />
                      </label>
                      <button
                        onClick={() => applyRate(rateDraft, "manual")}
                        className="rounded-2xl bg-white px-5 py-2.5 text-[13px] font-bold text-black hover:bg-[#13c1ac]"
                      >
                        Aplicar manual
                      </button>
                    </div>
                    <p className="mt-2 text-[11px] text-white/50">Consulta automatica al abrir y cada 10 min si hay conexion. Los cambios manuales son locales a este navegador.</p>
                  </div>

                  {/* Solo dueño: cambiar contraseña */}
                  <div className="mt-4 rounded-3xl border border-black/10 bg-[#f7f8f9] p-5 sm:p-6">
                    <p className="flex items-center gap-2 text-xs font-bold uppercase tracking-wide text-gray-500">
                      <KeyRound className="h-4 w-4" /> Cambiar contraseña de administrador
                    </p>
                    <div className="mt-3 grid gap-2 sm:grid-cols-3">
                      <label className="block">
                        <span className="text-[11px] font-bold text-gray-500">Actual</span>
                        <input
                          value={pinCurrent}
                          onChange={(e) => setPinCurrent(e.target.value)}
                          type="password"
                          inputMode="numeric"
                          placeholder="••••"
                          className="mt-1 w-full rounded-2xl border border-black/10 bg-white px-4 py-2.5 text-sm outline-none focus:border-[#13c1ac]"
                        />
                      </label>
                      <label className="block">
                        <span className="text-[11px] font-bold text-gray-500">Nueva (4-8 dígitos)</span>
                        <input
                          value={pinNew}
                          onChange={(e) => setPinNew(e.target.value)}
                          type="password"
                          inputMode="numeric"
                          placeholder="••••"
                          className="mt-1 w-full rounded-2xl border border-black/10 bg-white px-4 py-2.5 text-sm outline-none focus:border-[#13c1ac]"
                        />
                      </label>
                      <label className="block">
                        <span className="text-[11px] font-bold text-gray-500">Confirmar</span>
                        <input
                          value={pinConfirm}
                          onChange={(e) => setPinConfirm(e.target.value)}
                          type="password"
                          inputMode="numeric"
                          placeholder="••••"
                          className="mt-1 w-full rounded-2xl border border-black/10 bg-white px-4 py-2.5 text-sm outline-none focus:border-[#13c1ac]"
                        />
                      </label>
                    </div>
                    <button
                      onClick={saveNewPin}
                      className="mt-3 w-full rounded-full bg-[#1d2126] py-3 text-sm font-bold text-white hover:bg-[#13c1ac] hover:text-[#0b2b27]"
                    >
                      Guardar nueva contraseña
                    </button>
                  </div>

                  <button
                    onClick={() => {
                      setAdminUnlocked(false);
                      try {
                        localStorage.removeItem(ADMIN_KEY);
                      } catch {}
                      setAdminPin("");
                      showToast("Sesión de dueño cerrada");
                    }}
                    className="mt-4 w-full rounded-full border border-black/10 py-2.5 text-xs font-bold text-gray-500 hover:bg-black hover:text-white"
                  >
                    Cerrar sesión de administrador
                  </button>
                </section>
                </div>
                )}
                {adminTab === "envios" && (
                  <div className="mt-4 grid gap-4 lg:grid-cols-3">
                    {(
                      [
                        { k: "countries" as const, t: "🌎 Países", d: "Precio de envío por país, se suma al total." },
                        { k: "cities" as const, t: "🏙️ Ciudades", d: "Precio extra por ciudad, se suma al total." },
                        { k: "doms" as const, t: "🏠 A domicilio", d: "Tipo de entrega, se suma al total." },
                      ]
                    ).map((g) => (
                      <section key={g.k} className="rounded-3xl bg-white p-5 shadow-sm">
                        <h3 className="font-extrabold">{g.t}</h3>
                        <p className="mt-0.5 text-xs text-gray-500">{g.d}</p>
                        <div className="mt-3 space-y-2">
                          {ship[g.k].map((o) => (
                            <div key={o.id} className="flex items-center gap-2 rounded-2xl bg-[#f7f8f9] p-2">
                              <input
                                value={o.name}
                                onChange={(e) =>
                                  setShip((s) => ({
                                    ...s,
                                    [g.k]: s[g.k].map((x) => (x.id === o.id ? { ...x, name: e.target.value } : x)),
                                  }))
                                }
                                className="w-full bg-transparent text-sm font-bold outline-none"
                              />
                              <label className="flex shrink-0 items-center gap-1 rounded-xl bg-white px-2 py-1.5 text-sm font-bold">
                                S/
                                <input
                                  value={String(o.pricePen)}
                                  onChange={(e) =>
                                    setShip((s) => ({
                                      ...s,
                                      [g.k]: s[g.k].map((x) =>
                                        x.id === o.id ? { ...x, pricePen: Math.max(0, Math.round(Number(e.target.value.replace(/[^0-9.]/g, "")) || 0)) } : x
                                      ),
                                    }))
                                  }
                                  inputMode="decimal"
                                  className="w-14 bg-transparent text-sm font-bold outline-none"
                                />
                              </label>
                              <button
                                onClick={() => setShip((s) => ({ ...s, [g.k]: s[g.k].filter((x) => x.id !== o.id) }))}
                                className="grid h-8 w-8 shrink-0 place-items-center rounded-full text-gray-400 hover:bg-red-50 hover:text-red-600"
                                aria-label="Eliminar"
                              >
                                <Trash2 className="h-4 w-4" />
                              </button>
                            </div>
                          ))}
                        </div>
                        <div className="mt-2 text-xs text-gray-500">
                          {ship[g.k].map((o) => `${o.name}: S/ ${o.pricePen} (${formatBob(bobOf(o.pricePen))})`).join(" · ")}
                        </div>
                        <button
                          onClick={() =>
                            setShip((s) => ({
                              ...s,
                              [g.k]: [...s[g.k], { id: `${g.k}-${Date.now()}`, name: g.k === "countries" ? "Nuevo país" : g.k === "cities" ? "Nueva ciudad" : "Nueva entrega", pricePen: 0 }],
                            }))
                          }
                          className="mt-3 w-full rounded-full bg-black py-2.5 text-xs font-bold text-white hover:bg-[#13c1ac] hover:text-[#0b2b27]"
                        >
                          + Agregar
                        </button>
                        <button
                          onClick={() => {
                            setShip(DEFAULT_SHIP);
                            showToast("Precios de envío restaurados");
                          }}
                          className="mt-2 w-full text-center text-[11px] font-bold text-gray-400 hover:underline"
                        >
                          Restaurar por defecto
                        </button>
                      </section>
                    ))}
                  </div>
                )}
                {adminTab === "logos" && (
                  <div className="mt-4 rounded-3xl bg-white p-5 shadow-sm">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <h3 className="font-extrabold">🏷️ Logos por producto · precio y cantidad mínima</h3>
                      <label className="flex items-center gap-2 rounded-full bg-[#f2f4f5] px-4 py-2 text-sm">
                        <Search className="h-4 w-4 text-gray-500" />
                        <input value={adminSearch} onChange={(e) => setAdminSearch(e.target.value)} placeholder="Buscar producto..." className="bg-transparent outline-none" />
                      </label>
                    </div>
                    <p className="mt-1 text-xs text-gray-500">Activa logos, edita los 3 tipos con su precio extra (S/) y la cantidad mínima (100 und por defecto). Se suma solo en el producto.</p>
                    <div className="mt-4 grid gap-3 lg:grid-cols-2">
                      {adminFiltered.map((p) => (
                        <div key={p.id} className="rounded-2xl border border-black/10 p-4">
                          <div className="flex items-center gap-3">
                            <img src={p.image} alt="" className="h-14 w-14 rounded-xl object-cover" />
                            <div className="min-w-0 flex-1">
                              <p className="truncate text-sm font-extrabold">{p.title}</p>
                              <p className="text-xs text-gray-500">Base {formatPen(p.pricePen)} · {p.logoEnabled ? `mín. ${p.logoMinQty ?? 100}` : "sin logo"}</p>
                            </div>
                            <button
                              onClick={() => {
                                setProducts((prev) => prev.map((x) => (x.id === p.id ? { ...x, logoEnabled: !x.logoEnabled, logoMinQty: x.logoMinQty ?? 100, logoOptions: x.logoOptions?.length ? x.logoOptions : [{ name: "Logo bordado premium", extraPen: 5 }, { name: "Logo estampado full color", extraPen: 3 }, { name: "Logo sublimado / láser", extraPen: 4 }] } : x)));
                                showToast(p.logoEnabled ? "Logos desactivados" : "Logos activados (3 tipos)");
                              }}
                              className={`relative h-6 w-11 shrink-0 rounded-full ${p.logoEnabled ? "bg-[#13c1ac]" : "bg-gray-300"}`}
                              aria-label="Activar logos"
                            >
                              <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${p.logoEnabled ? "left-[22px]" : "left-0.5"}`} />
                            </button>
                          </div>
                          {p.logoEnabled && (
                            <div className="mt-3 space-y-2">
                              <label className="block text-xs font-bold text-gray-500">
                                Cantidad mínima (und)
                                <input
                                  value={String(p.logoMinQty ?? 100)}
                                  onChange={(e) => {
                                    const v = Math.max(1, Math.round(Number(e.target.value.replace(/[^0-9]/g, "")) || 100));
                                    setProducts((prev) => prev.map((x) => (x.id === p.id ? { ...x, logoMinQty: v, stock: Math.max(x.stock, v) } : x)));
                                  }}
                                  inputMode="numeric"
                                  className="mt-1 w-full rounded-xl border border-black/10 bg-[#f7f8f9] px-3 py-2 text-sm font-bold outline-none"
                                />
                              </label>
                              {(p.logoOptions ?? []).map((op, i) => (
                                <div key={i} className="grid grid-cols-[1fr_100px] gap-2">
                                  <input
                                    value={op.name}
                                    onChange={(e) => {
                                      const v = e.target.value;
                                      setProducts((prev) => prev.map((x) => (x.id === p.id ? { ...x, logoOptions: (x.logoOptions ?? []).map((o, j) => (j === i ? { ...o, name: v } : o)) } : x)));
                                    }}
                                    className="rounded-xl border border-black/10 bg-[#f7f8f9] px-3 py-2 text-sm outline-none"
                                  />
                                  <label className="flex items-center gap-1 rounded-xl border border-black/10 bg-[#f7f8f9] px-2 py-2 text-sm font-bold">
                                    +S/
                                    <input
                                      value={String(op.extraPen)}
                                      onChange={(e) => {
                                        const v = Math.max(0, Math.round(Number(e.target.value.replace(/[^0-9.]/g, "")) || 0));
                                        setProducts((prev) => prev.map((x) => (x.id === p.id ? { ...x, logoOptions: (x.logoOptions ?? []).map((o, j) => (j === i ? { ...o, extraPen: v } : o)) } : x)));
                                      }}
                                      inputMode="decimal"
                                      className="w-full bg-transparent outline-none"
                                    />
                                  </label>
                                </div>
                              ))}
                              <p className="text-[11px] text-gray-500">Ej: {formatPen(p.pricePen)} + logo = total c/u. Bs con Wise ({rate.toFixed(2)}).</p>
                              <button onClick={() => startEditProduct(p)} className="w-full rounded-full bg-black py-2 text-xs font-bold text-white hover:bg-[#13c1ac] hover:text-[#0b2b27]">
                                Abrir en Productos para más detalle
                              </button>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                {adminTab === "pagos" && (
                  <div className="mt-4 grid gap-4 lg:grid-cols-[1fr_1fr]">
                    <section className="rounded-3xl bg-white p-5 shadow-sm sm:p-6">
                      <h3 className="flex items-center gap-2 font-extrabold">
                        <CreditCard className="h-5 w-5 text-[#0c9d8c]" /> Pago con tarjeta · activar / desactivar
                      </h3>
                      <p className="mt-1 text-xs leading-5 text-gray-500">
                        Cuando está <strong>desactivado</strong> (recomendado por defecto), los clientes <strong>no ven</strong> la opción Tarjeta en el producto, ni el botón “Pagar con tarjeta” en cesta y checkout. Todo se vende por WhatsApp / Yape / Plin / transferencia.
                      </p>
                      <div className={`mt-4 flex items-center justify-between rounded-2xl p-4 ${cardEnabled ? "bg-[#e6faf6] ring-1 ring-[#13c1ac]" : "bg-[#f2f4f5]"}`}>
                        <div>
                          <p className="text-sm font-extrabold">{cardEnabled ? "Tarjeta ACTIVADA" : "Tarjeta DESACTIVADA"}</p>
                          <p className="text-xs text-gray-500">{cardEnabled ? "Visible en este navegador" : "Requiere un enlace HTTPS valido"}</p>
                        </div>
                        <button
                          onClick={() => {
                            if (!cardEnabled && !isValidCardLink(cardLink)) {
                              showToast("Introduce primero un enlace HTTPS valido");
                              return;
                            }
                            setPaySettings((s) => ({ ...s, cardEnabled: !s.cardEnabled }));
                            showToast(cardEnabled ? "Pago con tarjeta ocultado" : "Pago con tarjeta activado en este navegador");
                          }}
                          className={`relative h-8 w-14 shrink-0 rounded-full transition ${cardEnabled ? "bg-[#13c1ac]" : "bg-gray-300"}`}
                          aria-label="Activar o desactivar tarjeta"
                        >
                          <span className={`absolute top-1 h-6 w-6 rounded-full bg-white shadow transition-all ${cardEnabled ? "left-7" : "left-1"}`} />
                        </button>
                      </div>
                      <div className="mt-3 rounded-2xl bg-black p-4 text-white">
                        <p className="text-xs font-bold uppercase tracking-wide text-white/60">Vista cliente ahora</p>
                        <p className="mt-1 text-sm font-bold">{cardEnabled ? "Aqui: tarjeta habilitada mediante enlace externo" : "Tarjeta oculta; disponibles los otros metodos configurados"}</p>
                      </div>
                    </section>
                    <section className="rounded-3xl bg-white p-5 shadow-sm sm:p-6">
                      <h3 className="flex items-center gap-2 font-extrabold">
                        <ExternalLink className="h-5 w-5 text-[#0c9d8c]" /> Link de pago con tarjeta
                      </h3>
                      <p className="mt-1 text-xs leading-5 text-gray-500">
                        Pega aqui tu link de cobro HTTPS de una pasarela real. Solo se abrira esa pasarela; esta pagina no recibe numeros de tarjeta ni confirma pagos. Un enlace fijo puede tener un importe distinto al del carrito: verificalo en la pasarela.
                      </p>
                      <label className="mt-3 block">
                        <span className="text-xs font-bold uppercase text-gray-500">URL de pago (https://...)</span>
                        <input
                          value={paySettings.cardLink}
                          onChange={(e) => setPaySettings((s) => ({ ...s, cardLink: e.target.value }))}
                          placeholder="https://link.mercadopago.com.pe/tu-tienda"
                          inputMode="url"
                          className="mt-1 w-full rounded-2xl border border-black/10 bg-[#f7f8f9] px-4 py-3 text-sm outline-none focus:border-[#13c1ac]"
                        />
                      </label>
                      <div className="mt-3 flex flex-wrap gap-2">
                        <button
                          onClick={() => {
                            if (!isValidCardLink(cardLink)) {
                              showToast("Necesitas un enlace HTTPS valido");
                              return;
                            }
                            window.open(cardLink, "_blank", "noopener,noreferrer");
                          }}
                          className="flex items-center gap-1.5 rounded-full bg-black px-5 py-2.5 text-xs font-bold text-white hover:bg-[#13c1ac] hover:text-[#0b2b27]"
                        >
                          <ExternalLink className="h-4 w-4" /> Probar link
                        </button>
                        <button
                          onClick={() => {
                            setPaySettings((s) => ({ ...s, cardLink: "" }));
                            showToast("Link borrado");
                          }}
                          className="rounded-full bg-[#f2f4f5] px-5 py-2.5 text-xs font-bold text-gray-600 hover:bg-red-50 hover:text-red-600"
                        >
                          Borrar
                        </button>
                      </div>
                      {isValidCardLink(cardLink) ? (
                        <p className="mt-3 truncate rounded-2xl bg-[#e6faf6] p-3 text-xs font-bold text-[#0b4a43]">
                          Enlace HTTPS guardado en este navegador: {cardLink}
                        </p>
                      ) : (
                        <p className="mt-3 rounded-2xl bg-amber-50 p-3 text-xs font-bold text-amber-800">
                          Sin enlace HTTPS valido no se puede activar el pago con tarjeta. No hay formulario manual.
                        </p>
                      )}
                      <p className="mt-3 text-[11px] leading-4 text-gray-400">
                        Cambiar esto aqui solo afecta a este navegador. Para habilitar tarjeta para todos los clientes necesitas un backend o publicar configuracion compartida en tu hosting.
                      </p>
                    </section>
                  </div>
                )}
              </>
            )}
          </div>
        ) : page === "empresa" ? (
          <div className="animate-rise">
            {/* Pestaña Empresa + Tipo de cambio */}
            <section className="mt-4 grid gap-4 lg:grid-cols-[440px_1fr]">
              <div className="overflow-hidden rounded-3xl bg-black text-white shadow-sm">
                <img
                  src={LOGO_URL}
                  alt="JH Importaciones — Productos novedosos a precio de fábrica"
                  className="aspect-square w-full object-cover"
                />
                <div className="p-6">
                  <p className="flex items-center gap-2 text-[11px] font-bold tracking-[0.2em] text-[#7ce3d3] uppercase">
                    <Building2 className="h-4 w-4" /> Nuestra empresa
                  </p>
                  <h1 className="mt-2 text-3xl font-extrabold tracking-tight">JH IMPORTACIONES</h1>
                  <p className="mt-1 text-[13px] font-bold tracking-[0.12em] text-white/80 uppercase">
                    Productos novedosos a precio de fábrica
                  </p>
                  <p className="mt-3 text-sm leading-6 text-white/70">
                    Somos importadores directos. Traemos novedades útiles y originales para hogar, moda y accesorios, y las vendemos aquí mismo sin intermediarios.
                  </p>
                  <div className="mt-4 flex flex-wrap gap-2 text-xs">
                    {["Importación directa", "Precio de fábrica", "Garantía JH"].map((t) => (
                      <span key={t} className="rounded-full border border-white/20 px-3 py-1.5 font-semibold text-white/85">{t}</span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex flex-col gap-4">
                <div className="overflow-hidden rounded-3xl bg-white shadow-sm">
                  <div className="bg-black p-6 text-white sm:p-7">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-[11px] font-extrabold tracking-wide uppercase ${rateMeta.source !== "manual" ? "bg-emerald-400 text-[#06281f]" : "bg-amber-300 text-[#4a2f00]"}`}>
                        <span className="relative flex h-2 w-2">
                          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-black/30" />
                          <span className="relative inline-flex h-2 w-2 rounded-full bg-black/70" />
                        </span>
                        {rateMeta.source === "wise-live" ? "Fuente: Wise" : rateMeta.source === "market-live" ? "Fuente: mercado" : "Valor de referencia"}
                      </span>
                      <a href={WISE_URL} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 rounded-full border border-white/25 px-3 py-1 text-[11px] font-bold text-white/85 transition hover:bg-white hover:text-black">
                        wise.com <ExternalLink className="h-3 w-3" />
                      </a>
                      <span className="ml-auto text-[11px] text-white/60">Consultado {timeAgo(rateMeta.updatedAt)}</span>
                    </div>
                    <p className="mt-4 flex items-center gap-2 text-[11px] font-bold tracking-[0.18em] text-[#7ce3d3] uppercase">
                      <ArrowLeftRight className="h-4 w-4" /> Tipo de cambio que usa tu tienda
                    </p>
                    <h2 className="mt-1 text-4xl font-extrabold tracking-tight sm:text-5xl">1 S/ = Bs {rate.toFixed(2)}</h2>
                    <div className="mt-3 flex flex-wrap gap-2 text-[13px]">
                      <span className="rounded-full bg-[#13c1ac] px-4 py-2 font-bold text-[#06281f]">
                        Cotizacion: Bs {rateMeta.wise?.toFixed(2) ?? "--"}
                      </span>
                      <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-400/15 border border-emerald-300/30 px-4 py-2 font-bold text-emerald-200">
                        <RefreshCw className={`h-3.5 w-3.5 ${rateLoading ? "animate-spin" : ""}`} /> Consulta automatica activa
                      </span>
                    </div>
                    <p className="mt-3 max-w-xl text-[13px] leading-5 text-white/70">
                      Los precios en bolivianos son referenciales. La tienda intenta actualizar la cotizacion; consulta la fecha y confirma el importe antes de cobrar.
                    </p>
                  </div>

                  <div className="p-6 sm:p-7">
                    <div className="mt-0 overflow-hidden rounded-2xl border border-black/10">
                      <div className="flex items-center justify-between bg-[#f7f8f9] px-4 py-2.5">
                        <p className="text-xs font-bold text-gray-600">Cotizacion referencial PEN a BOB</p>
                        <a href={WISE_URL} target="_blank" rel="noreferrer" className="flex items-center gap-1 text-xs font-bold text-[#0c9d8c] hover:underline">
                          Abrir en Wise <ExternalLink className="h-3 w-3" />
                        </a>
                      </div>
                      <div className="grid gap-2 bg-white p-4 sm:grid-cols-2">
                        <div className="rounded-2xl bg-[#f2f4f5] p-4">
                          <p className="text-[11px] font-bold uppercase text-gray-500">Tasa consultada</p>
                          <p className="mt-1 text-xl font-extrabold">Bs {rateMeta.wise?.toFixed(2) ?? "--"}</p>
                          <p className="text-[11px] text-gray-500">{timeAgo(rateMeta.updatedAt)}</p>
                        </div>
                        <div className="rounded-2xl bg-[#f2f4f5] p-4">
                          <p className="text-[11px] font-bold uppercase text-gray-500">Tu tienda usa</p>
                          <p className="mt-1 text-xl font-extrabold text-[#0c9d8c]">Bs {rate.toFixed(2)}</p>
                          <p className="text-[11px] text-gray-500">{rateMeta.source === "wise-live" ? "Wise" : rateMeta.source === "market-live" ? "Referencia de mercado" : "Ultimo valor guardado"}</p>
                        </div>
                      </div>
                      <p className="bg-[#f7f8f9] px-4 py-2 text-[11px] text-gray-500">Solo lectura para clientes. El control está solo en Administración.</p>
                    </div>

                    <div className="mt-5 grid gap-2 sm:grid-cols-4">
                      {[
                        { pen: 10, label: "10 soles" },
                        { pen: 69, label: "Precio módico" },
                        { pen: 189, label: "Precio medio" },
                        { pen: 479, label: "Precio alto" },
                      ].map((ex) => (
                        <div key={ex.pen} className={`rounded-2xl p-4 ${ex.pen === 10 ? "bg-black text-white" : "bg-[#f2f4f5]"}`}>
                          <p className={`text-[11px] font-bold tracking-wide uppercase ${ex.pen === 10 ? "text-[#7ce3d3]" : "text-gray-500"}`}>{ex.label}</p>
                          <p className="mt-1 text-lg font-extrabold">{formatPen(ex.pen)}</p>
                          <p className={`text-sm font-bold ${ex.pen === 10 ? "text-[#7ce3d3]" : "text-[#0c9d8c]"}`}>= {formatBob(bobOf(ex.pen))}</p>
                        </div>
                      ))}
                    </div>

                    <p className="mt-4 flex items-start gap-2 rounded-2xl bg-[#e6faf6] p-3 text-xs leading-5 text-[#0b4a43]">
                      <Info className="mt-0.5 h-4 w-4 shrink-0" />
                      Ejemplo: S/ 10 = Bs {bobOf(10)} · S/ 100 = Bs {bobOf(100)} con TC {rate.toFixed(2)}. Fuente: {rateMeta.source === "wise-live" ? "Wise" : rateMeta.source === "market-live" ? "mercado referencial" : "valor guardado"} · {timeAgo(rateMeta.updatedAt)}.
                    </p>
                  </div>
                </div>

                <div className="grid gap-3 sm:grid-cols-3">
                  <div className="rounded-3xl bg-white p-5 shadow-sm">
                    <Store className="h-6 w-6 text-[#0c9d8c]" />
                    <p className="mt-2 font-bold">Solo vendo yo</p>
                    <p className="mt-1 text-[13px] leading-5 text-gray-500">JH Importaciones es tienda única, sin anuncios de terceros.</p>
                  </div>
                  <div className="rounded-3xl bg-white p-5 shadow-sm">
                    <MapPin className="h-6 w-6 text-[#0c9d8c]" />
                    <p className="mt-2 font-bold">Perú · Bolivia</p>
                    <p className="mt-1 text-[13px] leading-5 text-gray-500">Envíos con seguimiento a todo PE y BO.</p>
                  </div>
                  <div className="rounded-3xl bg-white p-5 shadow-sm">
                    <ShieldCheck className="h-6 w-6 text-[#0c9d8c]" />
                    <p className="mt-2 font-bold">Compra protegida</p>
                    <p className="mt-1 text-[13px] leading-5 text-gray-500">Foto real, guía y trato directo por chat.</p>
                  </div>
                </div>

                <button
                  onClick={() => {
                    setPage("tienda");
                    window.scrollTo({ top: 0, behavior: "smooth" });
                  }}
                  className="rounded-full bg-[#13c1ac] py-3.5 text-sm font-bold text-[#0b2b27] transition hover:bg-[#0c9d8c] hover:text-white"
                >
                  Volver a la tienda · ver precios en S/ y Bs
                </button>
              </div>
            </section>

            <section className="mt-6 overflow-hidden rounded-3xl bg-black text-white">
              <div className="grid items-center gap-6 p-6 sm:p-8 md:grid-cols-[220px_1fr_auto]">
                <img src={LOGO_URL} alt="Logo JH Importaciones" className="h-40 w-40 rounded-3xl object-cover ring-1 ring-white/20 md:h-48 md:w-48" />
                <div>
                  <p className="text-[11px] font-bold tracking-[0.2em] text-[#7ce3d3] uppercase">JH Importaciones</p>
                  <p className="mt-1 font-serif text-2xl sm:text-3xl">Productos novedosos a precio de fábrica.</p>
                  <p className="mt-2 text-sm text-white/70">Guarda esta pestaña para consultar el nombre oficial y el tipo de cambio vigente: 1 S/ = Bs {rate.toFixed(2)}.</p>
                </div>
                <button
                  onClick={() => openChat()}
                  className="rounded-full bg-white px-6 py-3 text-sm font-bold text-black transition hover:bg-[#13c1ac]"
                >
                  Hablar con JH
                </button>
              </div>
            </section>
          </div>
        ) : (
          <>
        {/* Hero marketplace */}
        <section className="animate-rise mt-4 grid gap-3 md:grid-cols-[1.6fr_.9fr]">
          <div className="relative overflow-hidden rounded-3xl bg-black p-6 text-white sm:p-8">
            <img
              src={LOGO_URL}
              alt="JH Importaciones — Productos novedosos a precio de fábrica"
              className="absolute inset-0 h-full w-full object-cover opacity-90"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-black via-black/70 to-black/10" />
            <div className="relative max-w-md">
              <p className="inline-flex items-center gap-1.5 rounded-full bg-[#13c1ac] px-3 py-1 text-[11px] font-bold tracking-wide text-[#0b2b27] uppercase">
                <ShieldCheck className="h-3.5 w-3.5" /> JH Importaciones · Sin publicar anuncios
              </p>
              <h1 className="mt-3 text-3xl leading-[1.05] font-extrabold sm:text-4xl">
                Productos novedosos <em className="text-[#7ce3d3] not-italic">a precio de fábrica.</em>
              </h1>
              <p className="mt-2 text-sm leading-6 text-white/80">
                Esto no es un marketplace abierto: es <strong className="text-white">mi tienda personal JH</strong>. Todo lo que ves lo vendo yo, con fotos reales y precios en soles y bolivianos (TC {rate.toFixed(2)}).
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                <button
                  onClick={() => document.getElementById("catalogo")?.scrollIntoView({ behavior: "smooth" })}
                  className="rounded-full bg-[#13c1ac] px-5 py-2.5 text-sm font-bold text-[#0b2b27] transition hover:bg-[#7ce3d3]"
                >
                  Ver mis productos
                </button>
                <button
                  onClick={() => openChat()}
                  className="rounded-full border border-white/30 px-5 py-2.5 text-sm font-bold text-white transition hover:bg-white hover:text-black"
                >
                  Chatear conmigo
                </button>
              </div>
              <div className="mt-5 flex gap-5 text-xs text-white/70">
                <span className="flex items-center gap-1.5"><Star className="h-4 w-4 fill-[#ffbf3f] text-[#ffbf3f]" /> 4.9 · 312 reseñas</span>
                <span className="flex items-center gap-1.5"><Truck className="h-4 w-4" /> Envío PE + BO</span>
                <span className="hidden items-center gap-1.5 sm:flex"><Eye className="h-4 w-4" /> Fotos reales</span>
              </div>
            </div>
          </div>

          <div className="grid gap-3">
            <div className="flex items-center gap-4 rounded-3xl bg-white p-4 shadow-sm">
              <img src={SELLER.avatar} alt="" className="h-14 w-14 rounded-2xl object-cover" />
              <div className="min-w-0 flex-1">
                <p className="flex items-center gap-1 font-bold">{SELLER.name} <BadgeCheck className="h-4 w-4 text-[#13c1ac]" /></p>
                <p className="text-xs text-gray-500">{SELLER.owner} · {SELLER.location}</p>
                <div className="mt-1 flex items-center gap-1 text-xs">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className={`h-3.5 w-3.5 ${i < 5 ? "fill-[#ffbf3f] text-[#ffbf3f]" : "text-gray-300"}`} />
                  ))}
                  <span className="ml-1 font-bold">{SELLER.rating}</span>
                </div>
              </div>
              <button onClick={() => openChat()} className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-[#1d2126] text-white transition hover:bg-[#13c1ac] hover:text-[#0b2b27]">
                <MessageCircle className="h-5 w-5" />
              </button>
            </div>
            <div className="grid grid-cols-3 gap-3">
              {[
                { k: `${SELLER.sales}`, v: "ventas" },
                { k: `${SELLER.followers}`, v: "seguidores" },
                { k: "1 h", v: "responde" },
              ].map((s) => (
                <div key={s.v} className="rounded-2xl bg-white p-3 text-center shadow-sm">
                  <p className="text-lg font-extrabold">{s.k}</p>
                  <p className="text-[11px] font-semibold tracking-wide text-gray-500 uppercase">{s.v}</p>
                </div>
              ))}
            </div>
            <div className="flex items-center gap-2 rounded-2xl bg-[#e6faf6] p-3 text-xs font-medium text-[#0b4a43]">
              <Handshake className="h-4 w-4 shrink-0" />
              Trato directo conmigo: sin intermediarios ni comisiones escondidas.
            </div>
          </div>
        </section>

        {/* Catálogo + filtros */}
        <section id="catalogo" className="mt-8 grid gap-6 lg:grid-cols-[270px_1fr]">
          {/* Sidebar */}
          <aside className="hidden lg:block">
            <div className="sticky top-36 space-y-4">
              <div className="rounded-3xl bg-white p-5 shadow-sm">
                <div className="flex items-center justify-between">
                  <h2 className="flex items-center gap-2 font-bold"><SlidersHorizontal className="h-4 w-4" /> Filtros</h2>
                  <button
                    onClick={() => {
                      setQuery("");
                      setCategory("Todos");
                      setConditions([]);
                      setMaxPrice(700);
                      setCountry("ALL");
                      setShowFavs(false);
                      setHideSold(true);
                    }}
                    className="text-xs font-bold text-[#0c9d8c] hover:underline"
                  >
                    Limpiar
                  </button>
                </div>

                <div className="mt-4">
                  <p className="text-xs font-bold tracking-wide text-gray-500 uppercase">Estado</p>
                  <div className="mt-2 space-y-2">
                    {(["Nuevo", "Como nuevo", "Buen estado"] as Condition[]).map((c) => (
                      <label key={c} className="flex cursor-pointer items-center gap-2.5 text-sm">
                        <input
                          type="checkbox"
                          checked={conditions.includes(c)}
                          onChange={() => toggleCondition(c)}
                          className="h-4 w-4 rounded accent-[#13c1ac]"
                        />
                        {c}
                      </label>
                    ))}
                  </div>
                </div>

                <div className="mt-5 border-t border-black/5 pt-4">
                  <p className="text-xs font-bold tracking-wide text-gray-500 uppercase">Precio máximo</p>
                  <input
                    type="range"
                    min={50}
                    max={700}
                    step={10}
                    value={maxPrice}
                    onChange={(e) => setMaxPrice(Number(e.target.value))}
                    className="mt-3 w-full"
                  />
                  <div className="mt-1 flex items-center justify-between text-sm font-bold">
                    <span>{formatPen(maxPrice)}</span>
                    <span className="text-xs font-semibold text-gray-500">{formatBob(bobOf(maxPrice))}</span>
                  </div>
                </div>

                <div className="mt-5 border-t border-black/5 pt-4">
                  <p className="text-xs font-bold tracking-wide text-gray-500 uppercase">Ubicación</p>
                  <div className="mt-2 grid grid-cols-3 gap-1.5">
                    {[
                      { v: "ALL" as const, l: "Todas" },
                      { v: "PE" as const, l: "🇵🇪 Perú" },
                      { v: "BO" as const, l: "🇧🇴 Bolivia" },
                    ].map((o) => (
                      <button
                        key={o.v}
                        onClick={() => setCountry(o.v)}
                        className={`rounded-full px-2 py-1.5 text-xs font-bold transition ${country === o.v ? "bg-[#1d2126] text-white" : "bg-[#f2f4f5] hover:bg-[#e6eaec]"}`}
                      >
                        {o.l}
                      </button>
                    ))}
                  </div>
                </div>

                <label className="mt-5 flex cursor-pointer items-center justify-between border-t border-black/5 pt-4 text-sm font-medium">
                  Ocultar vendidos
                  <button
                    onClick={() => setHideSold(!hideSold)}
                    className={`relative h-6 w-11 rounded-full transition ${hideSold ? "bg-[#13c1ac]" : "bg-gray-300"}`}
                    aria-label="Ocultar vendidos"
                  >
                    <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${hideSold ? "left-[22px]" : "left-0.5"}`} />
                  </button>
                </label>
              </div>

              <div className="rounded-3xl bg-[#1d2126] p-5 text-white">
                <p className="flex items-center gap-2 text-sm font-bold"><Package className="h-4 w-4 text-[#7ce3d3]" /> ¿Cómo comprar?</p>
                <ol className="mt-3 space-y-2.5 text-[13px] leading-5 text-white/80">
                  <li><strong className="text-white">1.</strong> Elige y añádelo a la cesta.</li>
                  <li><strong className="text-white">2.</strong> Chatea conmigo para coordinar.</li>
                  <li><strong className="text-white">3.</strong> Paga por Yape / QR y lo envío.</li>
                </ol>
              </div>
            </div>
          </aside>

          {/* Lista */}
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <p className="text-sm text-gray-600">
                <strong className="text-black">{filtered.length}</strong> {filtered.length === 1 ? "producto mío" : "productos míos"}
                {showFavs ? " en favoritos" : ""}
              </p>
              <div className="ml-auto flex items-center gap-2">
                <button onClick={() => setFiltersOpen(true)} className="flex items-center gap-1.5 rounded-full bg-white px-4 py-2 text-[13px] font-bold shadow-sm lg:hidden">
                  <SlidersHorizontal className="h-4 w-4" /> Filtros
                </button>
                <label className="flex items-center gap-1.5 rounded-full bg-white px-3 py-2 text-[13px] font-semibold shadow-sm">
                  <span className="hidden text-gray-500 sm:inline">Orden:</span>
                  <select value={sort} onChange={(e) => setSort(e.target.value as typeof sort)} className="bg-transparent font-bold outline-none">
                    <option value="relevancia">Destacados</option>
                    <option value="menor">Menor precio</option>
                    <option value="mayor">Mayor precio</option>
                    <option value="vistos">Más vistos</option>
                  </select>
                </label>
              </div>
            </div>

            {filtered.length === 0 ? (
              <div className="mt-6 rounded-3xl bg-white p-10 text-center shadow-sm">
                <p className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-[#f2f4f5]"><Search className="h-6 w-6 text-gray-400" /></p>
                <h3 className="mt-4 font-serif text-2xl">No encontré nada con esos filtros</h3>
                <p className="mx-auto mt-2 max-w-sm text-sm text-gray-500">Prueba con otra palabra o quita algún filtro. Recuerda: todo lo que ves lo vendo yo, no hay anuncios de otros.</p>
                <button
                  onClick={() => {
                    setQuery("");
                    setCategory("Todos");
                    setConditions([]);
                    setMaxPrice(700);
                    setShowFavs(false);
                  }}
                  className="mt-5 rounded-full bg-[#1d2126] px-6 py-2.5 text-sm font-bold text-white"
                >
                  Ver todo de nuevo
                </button>
              </div>
            ) : (
              <div className="mt-4 grid grid-cols-2 gap-3 md:grid-cols-3 md:gap-5 xl:grid-cols-3">
                {filtered.map((p, i) => {
                  const fav = favorites.includes(p.id);
                  return (
                    <article
                      key={p.id}
                      className="group animate-rise overflow-hidden rounded-2xl bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-xl md:rounded-3xl"
                      style={{ animationDelay: `${Math.min(i, 8) * 60}ms` }}
                    >
                      <div className="relative">
                        <button onClick={() => setSelectedId(p.id)} className="block w-full" aria-label={`Ver ${p.title}`}>
                          <img src={p.image} alt={p.title} loading="lazy" className="aspect-square w-full object-cover transition duration-500 group-hover:scale-105" />
                        </button>
                        <span className={`absolute left-2.5 top-2.5 rounded-full px-2.5 py-1 text-[10px] font-extrabold tracking-wide uppercase ${p.condition === "Nuevo" ? "bg-[#13c1ac] text-[#0b2b27]" : p.condition === "Como nuevo" ? "bg-[#ffbf3f] text-[#4a2f00]" : "bg-white/95 text-gray-700"}`}>
                          {p.condition}
                        </span>
                        <button
                          onClick={() => toggleFav(p.id)}
                          className={`absolute right-2.5 top-2.5 grid h-9 w-9 place-items-center rounded-full shadow transition ${fav ? "bg-[#e0445e] text-white" : "bg-white/95 text-gray-700 hover:text-[#e0445e]"}`}
                          aria-label="Guardar en favoritos"
                        >
                          <Heart className={`h-4.5 w-4.5 h-5 w-5 ${fav ? "fill-current" : ""}`} />
                        </button>
                        {(p.requiresLocation || p.logoEnabled) && !p.sold && (
                          <span className="absolute bottom-2.5 left-2.5 flex flex-col gap-1">
                            {p.logoEnabled && (
                              <span className="rounded-full bg-[#ffbf3f] px-2.5 py-1 text-[10px] font-extrabold uppercase text-black">
                                🏷️ Logo · mín. {p.logoMinQty ?? 100} und
                              </span>
                            )}
                            {p.requiresLocation && (
                              <span className="rounded-full bg-black/90 px-2.5 py-1 text-[10px] font-bold uppercase text-white backdrop-blur">
                                📍 Pide ubicación
                              </span>
                            )}
                          </span>
                        )}
                        {p.featured && !p.sold && !p.logoEnabled && !p.requiresLocation && (
                          <span className="absolute bottom-2.5 left-2.5 rounded-full bg-[#1d2126]/90 px-2.5 py-1 text-[10px] font-bold tracking-wide text-white uppercase backdrop-blur">
                            ★ Destacado mío
                          </span>
                        )}
                        {p.sold && (
                          <span className="absolute inset-0 grid place-items-center bg-black/45 text-sm font-extrabold tracking-[0.2em] text-white uppercase">
                            Vendido
                          </span>
                        )}
                        {p.reserved && !p.sold && (
                          <span className="absolute inset-x-0 bottom-0 bg-[#ffbf3f] py-1 text-center text-[11px] font-extrabold tracking-wide uppercase">
                            Reservado · pregúntame
                          </span>
                        )}
                      </div>
                      <div className="p-3 md:p-4">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <p className="text-[17px] font-extrabold tracking-tight md:text-lg">{formatPen(p.pricePen)}</p>
                            <p className="text-xs font-semibold text-gray-500">{formatBob(bobOf(p.pricePen))}</p>
                          </div>
                          <span className="shrink-0 rounded-full bg-[#f2f4f5] px-2 py-1 text-[10px] font-bold text-gray-600">{p.category}</span>
                        </div>
                        <button onClick={() => setSelectedId(p.id)} className="clamp-2 mt-1.5 min-h-10 text-left text-[13px] leading-5 text-gray-800 hover:underline md:text-sm">
                          {p.title}
                        </button>
                        {p.logoEnabled && p.logoOptions && (
                          <p className="mt-1 text-[11px] font-bold text-[#6b4a00]">+ logo desde {formatPen(Math.min(...p.logoOptions.map((o) => o.extraPen)))} c/u · ver 3 opciones</p>
                        )}
                        <p className="mt-1.5 flex items-center gap-1 text-[11px] text-gray-500 md:text-xs">
                          <MapPin className="h-3.5 w-3.5 shrink-0" /> {p.location} · {p.publishedAt}
                          {p.shipping && <span className="ml-1 inline-flex items-center gap-0.5 font-semibold text-[#0c9d8c]"><Truck className="h-3.5 w-3.5" /> Envío</span>}
                        </p>
                        <div className="mt-3 flex gap-1.5">
                          <button
                            onClick={() => !p.sold && addToCart(p.id)}
                            disabled={p.sold}
                            className={`flex-1 rounded-full py-2 text-xs font-bold transition md:text-[13px] ${p.sold ? "cursor-not-allowed bg-gray-100 text-gray-400" : "bg-[#1d2126] text-white hover:bg-[#13c1ac] hover:text-[#0b2b27]"}`}
                          >
                            {p.sold ? "Vendido" : "Añadir"}
                          </button>
                          <a
                            href={p.sold ? undefined : waProductLink(p)}
                            target="_blank"
                            rel="noreferrer"
                            onClick={(e) => {
                              if (p.sold) e.preventDefault();
                            }}
                            className={`grid h-9 w-9 shrink-0 place-items-center rounded-full text-white transition ${p.sold ? "pointer-events-none bg-gray-200" : "bg-[#25d366] hover:bg-[#1eb856]"}`}
                            aria-label={`Pedir ${p.title} por WhatsApp`}
                            title="Pedir por WhatsApp"
                          >
                            <WhatsAppIcon className="h-4 w-4" />
                          </a>
                          <button
                            onClick={() => openChat(p.id)}
                            className="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-black/10 transition hover:border-[#13c1ac] hover:text-[#0c9d8c]"
                            aria-label="Preguntar por chat"
                          >
                            <MessageCircle className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                    </article>
                  );
                })}
              </div>
            )}

            {/* Confianza */}
            <div className="mt-8 grid gap-3 sm:grid-cols-3">
              {[
                { icon: ShieldCheck, t: "Trato solo conmigo", d: "Nada de terceros. Yo respondo, empaco y envío." },
                { icon: CreditCard, t: "Pago seguro a mi nombre", d: "Yape, Plin, BCP y QR Bolivia. Nada por fuera." },
                { icon: Truck, t: "Envío con seguimiento", d: "Foto del paquete + número de guía siempre." },
              ].map((c) => (
                <div key={c.t} className="rounded-3xl bg-white p-5 shadow-sm">
                  <c.icon className="h-6 w-6 text-[#0c9d8c]" />
                  <p className="mt-2 font-bold">{c.t}</p>
                  <p className="mt-1 text-[13px] leading-5 text-gray-500">{c.d}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Footer vendedor */}
        <section className="mt-10 overflow-hidden rounded-3xl bg-[#1d2126] p-6 text-white sm:p-10">
          <div className="grid gap-8 md:grid-cols-[1fr_320px] md:items-center">
            <div>
              <p className="text-[11px] font-bold tracking-[0.2em] text-[#7ce3d3] uppercase">Sobre esta tienda</p>
              <h2 className="mt-2 font-serif text-3xl leading-tight sm:text-4xl">No es Wallapop abierto.<br />Es mi tienda y punto.</h2>
              <p className="mt-3 max-w-xl text-sm leading-6 text-white/70">
                Aquí <strong className="text-white">no puedes publicar anuncios</strong> porque no es un marketplace de muchos vendedores. Soy yo vendiendo mis textiles y prendas seleccionadas, con garantía personal en cada entrega.
              </p>
              <div className="mt-5 flex flex-wrap gap-2 text-xs">
                {["Fotos reales", "Stock verificado", "Devolución 48 h en Cusco", "Factura / boleta si la pides"].map((t) => (
                  <span key={t} className="rounded-full border border-white/15 px-3 py-1.5 font-semibold text-white/80">{t}</span>
                ))}
              </div>
            </div>
            <div className="rounded-3xl bg-white p-5 text-black">
              <div className="flex items-center gap-3">
                <img src={SELLER.avatar} alt="" className="h-12 w-12 rounded-2xl object-cover" />
                <div>
                  <p className="flex items-center gap-1 text-sm font-extrabold">{SELLER.name} <BadgeCheck className="h-4 w-4 text-[#13c1ac]" /></p>
                  <p className="text-xs text-gray-500">{SELLER.since} · {SELLER.location}</p>
                </div>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-2 text-center">
                <div className="rounded-2xl bg-[#f2f4f5] p-3"><p className="font-extrabold">98%</p><p className="text-[11px] text-gray-500">recomienda</p></div>
                <div className="rounded-2xl bg-[#f2f4f5] p-3"><p className="font-extrabold">~1 h</p><p className="text-[11px] text-gray-500">respondo</p></div>
              </div>
              <button onClick={() => openChat()} className="mt-4 w-full rounded-full bg-[#13c1ac] py-3 text-sm font-bold text-[#0b2b27] transition hover:bg-[#0c9d8c] hover:text-white">
                Hablar conmigo
              </button>
            </div>
          </div>
        </section>

        <footer className="flex flex-col gap-4 py-8 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-3">
            <img src={LOGO_ICON_URL} alt="JH Importaciones" className="h-11 w-11 rounded-xl bg-black object-contain p-0.5 ring-1 ring-black/10" />
            <div>
              <p className="text-[15px] font-extrabold text-black">JH IMPORTACIONES — mi tienda personal</p>
              <p className="text-xs text-gray-500">Cusco · Lima · La Paz — S/ PEN · Bs BOB · TC {rate.toFixed(2)}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="mr-1 text-[11px] font-bold tracking-[0.12em] text-gray-500 uppercase">Sígueme</span>
            <a href={TIKTOK_URL} target="_blank" rel="noreferrer" aria-label="TikTok" className="grid h-10 w-10 place-items-center rounded-full bg-black text-white transition hover:scale-105 hover:bg-[#fe2c55]">
              <TikTokIcon className="h-4.5 w-4.5 h-5 w-5" />
            </a>
            <a href={FACEBOOK_URL} target="_blank" rel="noreferrer" aria-label="Facebook" className="grid h-10 w-10 place-items-center rounded-full bg-[#1877f2] text-white transition hover:scale-105">
              <FacebookIcon className="h-5 w-5" />
            </a>
            <a href={WHATSAPP_GENERAL} target="_blank" rel="noreferrer" aria-label="WhatsApp" className="grid h-10 w-10 place-items-center rounded-full bg-[#25d366] text-white transition hover:scale-105">
              <WhatsAppIcon className="h-5 w-5" />
            </a>
          </div>
        </footer>
          </>
        )}
      </main>

      {/* Nav móvil */}
      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-black/10 bg-white px-2 py-2 md:hidden">
        <div className="grid grid-cols-5">
          {[
            { k: "inicio" as const, icon: Home, l: "Inicio" },
            { k: "buscar" as const, icon: Search, l: "Buscar" },
            { k: "favs" as const, icon: Heart, l: "Favs" },
            { k: "cesta" as const, icon: ShoppingBag, l: "Cesta" },
            { k: "chats" as const, icon: MessageCircle, l: "Chats" },
          ].map((t) => (
            <button
              key={t.k}
              onClick={() => {
                setMobileTab(t.k);
                if (t.k === "inicio") {
                  setCategory("Todos");
                  setShowFavs(false);
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }
                if (t.k === "buscar") searchRef.current?.focus() ?? window.scrollTo({ top: 0, behavior: "smooth" });
                if (t.k === "favs") setShowFavs(true);
                if (t.k === "cesta") setCartOpen(true);
                if (t.k === "chats") openChat();
              }}
              className={`flex flex-col items-center gap-0.5 rounded-xl py-1.5 text-[10px] font-bold ${mobileTab === t.k ? "text-[#0c9d8c]" : "text-gray-500"}`}
            >
              <t.icon className="h-5 w-5" />
              {t.l}
              {t.k === "favs" && favorites.length > 0 && <span className="h-1 w-1 rounded-full bg-[#e0445e]" />}
              {t.k === "cesta" && cartCount > 0 && <span className="h-1 w-1 rounded-full bg-[#1d2126]" />}
            </button>
          ))}
        </div>
      </nav>

      {/* Drawer filtros móvil */}
      {filtersOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <button className="absolute inset-0 bg-black/50" onClick={() => setFiltersOpen(false)} aria-label="Cerrar filtros" />
          <div className="absolute bottom-0 left-0 right-0 max-h-[85vh] overflow-y-auto rounded-t-3xl bg-white p-6">
            <div className="flex items-center justify-between">
              <h3 className="font-bold">Filtros de mi tienda</h3>
              <button onClick={() => setFiltersOpen(false)} className="grid h-9 w-9 place-items-center rounded-full bg-black/5" aria-label="Cerrar"><X className="h-5 w-5" /></button>
            </div>
            <p className="mt-4 text-xs font-bold tracking-wide text-gray-500 uppercase">Estado</p>
            <div className="mt-2 flex flex-wrap gap-2">
              {(["Nuevo", "Como nuevo", "Buen estado"] as Condition[]).map((c) => (
                <button
                  key={c}
                  onClick={() => toggleCondition(c)}
                  className={`rounded-full px-4 py-2 text-sm font-bold ${conditions.includes(c) ? "bg-[#1d2126] text-white" : "bg-[#f2f4f5]"}`}
                >
                  {c}
                </button>
              ))}
            </div>
            <p className="mt-5 text-xs font-bold tracking-wide text-gray-500 uppercase">Precio máximo: {formatPen(maxPrice)}</p>
            <input type="range" min={50} max={700} step={10} value={maxPrice} onChange={(e) => setMaxPrice(Number(e.target.value))} className="mt-2 w-full" />
            <p className="mt-5 text-xs font-bold tracking-wide text-gray-500 uppercase">Ubicación</p>
            <div className="mt-2 grid grid-cols-3 gap-2">
              {[
                { v: "ALL" as const, l: "Todas" },
                { v: "PE" as const, l: "🇵🇪 Perú" },
                { v: "BO" as const, l: "🇧🇴 Bolivia" },
              ].map((o) => (
                <button key={o.v} onClick={() => setCountry(o.v)} className={`rounded-full py-2 text-sm font-bold ${country === o.v ? "bg-[#1d2126] text-white" : "bg-[#f2f4f5]"}`}>
                  {o.l}
                </button>
              ))}
            </div>
            <button onClick={() => setFiltersOpen(false)} className="mt-6 w-full rounded-full bg-[#13c1ac] py-3.5 text-sm font-bold text-[#0b2b27]">
              Ver {filtered.length} productos
            </button>
          </div>
        </div>
      )}

      {/* Detalle producto */}
      {selected && (
        <div className="fixed inset-0 z-50 flex items-end justify-center md:items-center md:p-6">
          <button className="absolute inset-0 bg-black/60" onClick={() => setSelectedId(null)} aria-label="Cerrar detalle" />
          <div className="animate-pop relative max-h-[92vh] w-full max-w-4xl overflow-y-auto rounded-t-3xl bg-white md:rounded-3xl">
            <button onClick={() => setSelectedId(null)} className="absolute right-4 top-4 z-10 grid h-10 w-10 place-items-center rounded-full bg-white shadow" aria-label="Cerrar">
              <X className="h-5 w-5" />
            </button>
            <div className="grid md:grid-cols-2">
              <div className="relative bg-[#f2f4f5]">
                <img src={selected.image} alt={selected.title} className="aspect-square w-full object-cover md:aspect-auto md:h-full md:min-h-[520px]" />
                <span className="absolute left-4 top-4 rounded-full bg-white px-3 py-1 text-[11px] font-extrabold uppercase">{selected.condition}</span>
              </div>
              <div className="p-5 sm:p-7">
                <p className="flex items-center gap-2 text-xs font-semibold text-gray-500">
                  {selected.category} · {selected.publishedAt} · <span className="flex items-center gap-1"><Eye className="h-3.5 w-3.5" /> {selected.views}</span>
                </p>
                <h2 className="mt-2 font-serif text-2xl leading-tight sm:text-3xl">{selected.title}</h2>
                {(() => {
                  const li = detailLogo;
                  const extra = logoExtraOf(selected, li);
                  const upen = selected.pricePen + extra;
                  return (
                    <>
                      <div className="mt-3 flex items-end gap-3">
                        <p className="text-3xl font-extrabold tracking-tight">{formatPen(upen)}</p>
                        <p className="pb-1 text-lg font-bold text-gray-500">{formatBob(bobOf(upen))}</p>
                      </div>
                      {extra > 0 && (
                        <p className="mt-1 text-xs font-bold text-[#0c9d8c]">
                          Base {formatPen(selected.pricePen)} + logo {formatPen(extra)} = {formatPen(upen)} c/u
                        </p>
                      )}
                    </>
                  );
                })()}
                <p className="mt-1 text-xs text-gray-500">Precio JH en ambas monedas · TC {rate.toFixed(2)} · sin comisiones</p>
                {selected.requiresLocation && (
                  <p className="mt-2 flex items-center gap-1.5 rounded-2xl bg-black p-2.5 text-xs font-bold text-white">
                    <MapPin className="h-4 w-4 shrink-0 text-[#7ce3d3]" /> Este producto pide tu ubicación: país, ciudad y dirección al comprar.
                  </p>
                )}
                {selected.logoEnabled && (
                  <p className="mt-2 flex items-center gap-1.5 rounded-2xl bg-[#fff4d6] p-2.5 text-xs font-bold text-[#6b4a00]">
                    🏷️ Personalizable con logo · pedido mínimo {selected.logoMinQty ?? 100} und
                  </p>
                )}

                <p className="mt-4 text-sm leading-6 text-gray-700">{selected.description}</p>

                <dl className="mt-4 grid grid-cols-2 gap-2 text-[13px]">
                  {[
                    ["Material", selected.material],
                    ["Medida", selected.size],
                    ["Color", selected.color],
                    ["Ubicación", `${selected.location} ${selected.country === "PE" ? "🇵🇪" : "🇧🇴"}`],
                  ].map(([k, v]) => (
                    <div key={k} className="rounded-2xl bg-[#f7f8f9] p-3">
                      <dt className="text-[11px] font-bold tracking-wide text-gray-500 uppercase">{k}</dt>
                      <dd className="mt-0.5 font-semibold">{v}</dd>
                    </div>
                  ))}
                </dl>

                <div className={`mt-3 flex items-center gap-2 rounded-2xl p-3 text-[13px] font-medium ${selected.shipping ? "bg-[#e6faf6] text-[#0b4a43]" : "bg-[#fff4d6] text-[#6b4a00]"}`}>
                  <Truck className="h-4 w-4 shrink-0" />
                  {selected.shipping ? "Hago envío a Perú y Bolivia con seguimiento." : "Solo entrega en persona. Escríbeme y coordinamos."}
                </div>

                <div className="mt-3 rounded-3xl border-2 border-black bg-[#f7f8f9] p-4">
                  <p className="flex items-center gap-1.5 text-sm font-extrabold">
                    <MapPin className="h-4 w-4" /> 📍 Elige tu envío antes de la cesta — suma al total
                  </p>
                  <div className="mt-3 grid gap-2">
                    <label className="block text-xs font-bold uppercase text-gray-500">
                      País · suma envío
                      <div className="mt-1 grid gap-1.5">
                        {ship.countries.map((o) => (
                          <button
                            key={o.id}
                            type="button"
                            onClick={() => setDetailCountry(o.name)}
                            className={`flex items-center justify-between rounded-2xl border px-3 py-2 text-sm transition ${detailCountry === o.name ? "border-black bg-black text-white" : "border-black/10 bg-white hover:border-black"}`}
                          >
                            <span className="font-bold">{o.name}</span>
                            <span className={`text-xs font-extrabold ${detailCountry === o.name ? "text-[#7ce3d3]" : "text-[#0c9d8c]"}`}>+{formatPen(o.pricePen)} · {formatBob(bobOf(o.pricePen))}</span>
                          </button>
                        ))}
                      </div>
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <label className="block text-xs font-bold uppercase text-gray-500">
                        Ciudad · suma
                        <select value={detailCity} onChange={(e) => setDetailCity(e.target.value)} className="mt-1 w-full rounded-2xl border border-black/10 bg-white px-3 py-2.5 text-sm font-bold outline-none">
                          {ship.cities.map((o) => (
                            <option key={o.id} value={o.name}>
                              {o.name} · +S/ {o.pricePen}
                            </option>
                          ))}
                        </select>
                      </label>
                      <label className="block text-xs font-bold uppercase text-gray-500">
                        A domicilio · suma
                        <select value={detailDom} onChange={(e) => setDetailDom(e.target.value)} className="mt-1 w-full rounded-2xl border border-black/10 bg-white px-3 py-2.5 text-sm font-bold outline-none">
                          {ship.doms.map((o) => (
                            <option key={o.id} value={o.name}>
                              {o.name} · +S/ {o.pricePen}
                            </option>
                          ))}
                        </select>
                      </label>
                    </div>
                    <input value={detailAddress} onChange={(e) => setDetailAddress(e.target.value)} placeholder="Dirección exacta: calle, número, referencia *" className="w-full rounded-2xl border border-black/10 bg-white px-3 py-2.5 text-sm outline-none focus:border-[#13c1ac]" />
                    {(() => {
                      const sp = shipTotalPen(detailCountry, detailCity, detailDom);
                      return (
                        <p className="flex items-center justify-between rounded-2xl bg-black p-3 text-xs font-bold text-white">
                          <span>🚚 Envío: {detailCountry} + {detailCity} + {detailDom}</span>
                          <span className="text-sm font-extrabold text-[#7ce3d3]">+{formatPen(sp)} · {formatBob(bobOf(sp))}</span>
                        </p>
                      );
                    })()}
                  </div>
                </div>

                <div className="mt-4 flex items-center gap-3 rounded-2xl border border-black/10 p-3">
                  <img src={SELLER.avatar} alt="" className="h-11 w-11 rounded-full object-cover" />
                  <div className="min-w-0 flex-1">
                    <p className="flex items-center gap-1 text-sm font-bold">{SELLER.name} <BadgeCheck className="h-4 w-4 text-[#13c1ac]" /></p>
                    <p className="flex items-center gap-1 text-xs text-gray-500"><Clock className="h-3 w-3" /> {SELLER.response} · {SELLER.sales} ventas</p>
                  </div>
                  <button onClick={() => { setSelectedId(null); openChat(selected.id); }} className="rounded-full bg-[#f2f4f5] px-4 py-2 text-xs font-bold hover:bg-[#e6eaec]">
                    Chat
                  </button>
                </div>

                {selected.logoEnabled && selected.logoOptions && selected.logoOptions.length > 0 && (
                  <div className="mt-4 overflow-hidden rounded-2xl border border-black/10">
                    <button
                      onClick={() => setDetailLogo(detailLogo == null ? 0 : null)}
                      className="flex w-full items-center justify-between bg-[#f7f8f9] px-4 py-3 text-left"
                    >
                      <span className="text-sm font-extrabold">🏷️ Agregar logo personalizado {detailLogo != null ? "· activado" : ""}</span>
                      <ChevronRight className={`h-4 w-4 transition ${detailLogo != null ? "rotate-90" : ""}`} />
                    </button>
                    {detailLogo != null || true ? (
                      <div className="space-y-2 p-3">
                        <button
                          onClick={() => {
                            setDetailLogo(null);
                            setDetailQty(1);
                          }}
                          className={`w-full rounded-2xl border p-3 text-left text-sm ${detailLogo == null ? "border-black bg-black text-white" : "border-black/10 hover:border-black"}`}
                        >
                          <span className="font-bold">Sin logo</span>
                          <span className="block text-xs opacity-70">Precio base · sin mínimo</span>
                        </button>
                        {selected.logoOptions.map((op, i) => {
                          const active = detailLogo === i;
                          const upen = selected.pricePen + op.extraPen;
                          return (
                            <button
                              key={i}
                              onClick={() => {
                                setDetailLogo(i);
                                const min = selected.logoMinQty ?? 100;
                                setDetailQty((q) => Math.max(q, min));
                              }}
                              className={`w-full rounded-2xl border p-3 text-left text-sm transition ${active ? "border-[#13c1ac] bg-[#e6faf6]" : "border-black/10 hover:border-black"}`}
                            >
                              <span className="flex items-center justify-between gap-2">
                                <span className="font-bold">{i + 1}. {op.name}</span>
                                <span className="shrink-0 rounded-full bg-black px-2 py-0.5 text-[11px] font-bold text-white">+{formatPen(op.extraPen)}</span>
                              </span>
                              <span className="mt-1 block text-xs text-gray-600">
                                Total c/u: {formatPen(upen)} · {formatBob(bobOf(upen))} · mín. {selected.logoMinQty ?? 100} und
                              </span>
                            </button>
                          );
                        })}
                        {detailLogo != null && (
                          <p className="rounded-2xl bg-[#fff4d6] p-2.5 text-xs font-bold text-[#6b4a00]">
                            Con logo: mínimo {selected.logoMinQty ?? 100} unidades. Tu total se recalcula solo.
                          </p>
                        )}
                      </div>
                    ) : null}
                  </div>
                )}

                <div className="mt-3 flex items-center justify-between rounded-2xl bg-[#f7f8f9] p-3">
                  <span className="text-sm font-bold">Cantidad {detailLogo != null ? `(mín. ${selected.logoMinQty ?? 100})` : ""}</span>
                  <span className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        const min = detailLogo != null ? (selected.logoMinQty ?? 100) : 1;
                        setDetailQty((q) => Math.max(min, q - 1));
                      }}
                      className="grid h-8 w-8 place-items-center rounded-full bg-white shadow"
                      aria-label="Quitar uno"
                    >
                      <Minus className="h-4 w-4" />
                    </button>
                    <span className="min-w-10 text-center text-lg font-extrabold">{detailQty}</span>
                    <button
                      onClick={() => {
                        const max = Math.max(selected.stock, detailLogo != null ? (selected.logoMinQty ?? 100) : selected.stock);
                        setDetailQty((q) => Math.min(max, q + 1));
                      }}
                      className="grid h-8 w-8 place-items-center rounded-full bg-white shadow"
                      aria-label="Agregar uno"
                    >
                      <Plus className="h-4 w-4" />
                    </button>
                  </span>
                </div>
                {(() => {
                  const extra = logoExtraOf(selected, detailLogo);
                  const upen = selected.pricePen + extra;
                  const sp = shipTotalPen(detailCountry, detailCity, detailDom);
                  const grand = upen * detailQty + sp;
                  return (
                    <div className="mt-2 rounded-2xl bg-black p-3 text-white">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold uppercase tracking-wide text-white/60">Producto {detailQty} und</span>
                        <span className="text-sm font-bold">{formatPen(upen * detailQty)} · {formatBob(bobOf(upen * detailQty))}</span>
                      </div>
                      <div className="mt-1 flex items-center justify-between border-t border-white/10 pt-2">
                        <span className="text-xs font-bold uppercase tracking-wide text-white/60">🚚 Envío {detailCountry}/{detailCity}</span>
                        <span className="text-sm font-bold text-[#7ce3d3]">+{formatPen(sp)} · {formatBob(bobOf(sp))}</span>
                      </div>
                      <div className="mt-2 flex items-center justify-between border-t border-white/10 pt-2">
                        <span className="text-xs font-extrabold uppercase tracking-wide">Total a pagar</span>
                        <span className="text-right">
                          <span className="block text-xl font-extrabold">{formatPen(grand)}</span>
                          <span className="block text-xs font-bold text-white/60">{formatBob(bobOf(grand))}</span>
                        </span>
                      </div>
                    </div>
                  );
                })()}

                <div className="mt-4 grid gap-2">
                  <div className="rounded-2xl border border-black/10 bg-[#f7f8f9] p-3">
                    <p className="text-xs font-extrabold uppercase tracking-wide text-gray-600">Tipo de pago aceptado</p>
                    {(() => {
                      const opts = visiblePayOptions(selected, cardEnabled);
                      return (
                        <>
                          <div className="mt-2 flex flex-wrap gap-1.5">
                            {opts.map((m) => {
                              const active = detailPay === m;
                              return (
                                <button
                                  key={m}
                                  type="button"
                                  onClick={() => setDetailPay(m)}
                                  className={`flex items-center gap-1.5 rounded-full px-3.5 py-2 text-[13px] font-bold transition ${active ? "bg-black text-white shadow" : "bg-white text-gray-700 ring-1 ring-black/10 hover:ring-black"}`}
                                >
                                  {m === "Tarjeta" ? <CreditCard className="h-4 w-4" /> : <Wallet className="h-4 w-4" />}
                                  {m}
                                </button>
                              );
                            })}
                          </div>
                          <p className="mt-2 text-[11px] font-semibold text-gray-500">
                            Elegido: <span className="font-extrabold text-black">{detailPay}</span> · {detailPay === "Coordinar por WhatsApp" ? "Consulta el medio de pago disponible." : `Disponible para este producto${opts.length === 1 ? "" : " y otras opciones"}.`}
                          </p>
                        </>
                      );
                    })()}
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => {
                        if (selected.sold) return;
                        if (!detailAddress.trim() && selected.requiresLocation) {
                          showToast("Escribe tu dirección exacta para el envío");
                          return;
                        }
                        const payToUse = detailPay === "Tarjeta" && !cardEnabled ? visiblePayOptions(selected, false)[0] : detailPay;
                        addToCart(selected.id, detailQty, detailLogo, { country: detailCountry, city: detailCity, dom: detailDom, address: detailAddress }, payToUse);
                        setSelectedId(null);
                        setPayMethod(payToUse === "Tarjeta" && cardEnabled ? "card" : "whatsapp");
                        setCheckoutOpen(true);
                      }}
                      disabled={selected.sold}
                      className="flex items-center justify-center gap-1.5 rounded-full bg-[#1d2126] py-3.5 text-sm font-bold text-white transition hover:bg-[#13c1ac] hover:text-[#0b2b27] disabled:bg-gray-200 disabled:text-gray-400"
                    >
                      {(detailPay === "Tarjeta" && cardEnabled) ? <CreditCard className="h-4 w-4" /> : <Wallet className="h-4 w-4" />} {selected.sold ? "Vendido" : detailPay === "Coordinar por WhatsApp" ? "Consultar por WhatsApp" : `Pagar con ${detailPay}`}
                    </button>
                    {selected.requiresLocation && !buyerOk ? (
                      <button
                        onClick={() => {
                          if (selected.sold) return;
                          addToCart(selected.id, detailQty, detailLogo, { country: detailCountry, city: detailCity, dom: detailDom, address: detailAddress }, detailPay);
                          setSelectedId(null);
                          setPayMethod("whatsapp");
                          setCheckoutOpen(true);
                          showToast("Agregado · completa tu ubicación para enviar por WhatsApp");
                        }}
                        disabled={selected.sold}
                        className="flex items-center justify-center gap-1.5 rounded-full bg-[#25d366] py-3.5 text-sm font-bold text-white transition hover:bg-[#1eb856] disabled:bg-gray-200 disabled:text-gray-400"
                      >
                        <WhatsAppIcon className="h-4 w-4" /> WhatsApp
                      </button>
                    ) : (
                      <a
                        href={waProductLink(selected, detailLogo, detailQty, detailPay)}
                        target="_blank"
                        rel="noreferrer"
                        onClick={(e) => {
                          if (selected.sold) e.preventDefault();
                        }}
                        className={`flex items-center justify-center gap-1.5 rounded-full py-3.5 text-sm font-bold text-white transition ${selected.sold ? "pointer-events-none bg-gray-200 text-gray-400" : "bg-[#25d366] hover:bg-[#1eb856]"}`}
                      >
                        <WhatsAppIcon className="h-4 w-4" /> WhatsApp
                      </a>
                    )}
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => {
                        if (!detailAddress.trim() && selected.requiresLocation) {
                          showToast("Escribe tu dirección exacta para el envío");
                          return;
                        }
                        addToCart(selected.id, detailQty, detailLogo, { country: detailCountry, city: detailCity, dom: detailDom, address: detailAddress }, detailPay);
                      }}
                      disabled={selected.sold}
                      className="rounded-full border-2 border-[#1d2126] py-2.5 text-sm font-bold transition hover:bg-[#1d2126] hover:text-white disabled:opacity-40"
                    >
                      A la cesta + envío
                    </button>
                    <button
                      onClick={() => toggleFav(selected.id)}
                      className="rounded-full bg-[#f2f4f5] py-2.5 text-sm font-bold text-gray-700 transition hover:bg-[#ffe9ea] hover:text-[#e0445e]"
                    >
                      {favorites.includes(selected.id) ? "♥ Favorito" : "♡ Favorito"}
                    </button>
                  </div>
                    <p className="flex items-center justify-center gap-1.5 text-[11px] text-gray-500">
                      <Lock className="h-3 w-3" /> Pago con {detailPay} · o pídelo directo a mi WhatsApp {WHATSAPP_NUMBER}
                    </p>
                </div>

                {related.length > 0 && (
                  <div className="mt-6">
                    <p className="text-sm font-bold">Más míos en {selected.category}</p>
                    <div className="mt-2 grid grid-cols-4 gap-2">
                      {related.map((r) => (
                        <button key={r.id} onClick={() => setSelectedId(r.id)} className="overflow-hidden rounded-xl bg-[#f2f4f5] text-left">
                          <img src={r.image} alt="" className="aspect-square w-full object-cover" />
                          <p className="truncate p-1.5 text-[11px] font-bold">{formatPen(r.pricePen)}</p>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Cesta */}
      {cartOpen && (
        <div className="fixed inset-0 z-50">
          <button className="absolute inset-0 bg-black/50" onClick={() => setCartOpen(false)} aria-label="Cerrar cesta" />
          <aside className="absolute right-0 top-0 flex h-full w-full max-w-md flex-col bg-white shadow-2xl" style={{ animation: "slide-in-right .35s ease-out" }}>
            <div className="flex items-center justify-between border-b border-black/5 p-5">
              <div>
                <p className="text-[11px] font-bold tracking-[0.15em] text-[#0c9d8c] uppercase">Mi cesta</p>
                <h2 className="font-serif text-2xl">Tu selección ({cartCount})</h2>
              </div>
              <button onClick={() => setCartOpen(false)} className="grid h-10 w-10 place-items-center rounded-full bg-black/5" aria-label="Cerrar"><X className="h-5 w-5" /></button>
            </div>
            <div className="thin-scroll flex-1 overflow-y-auto p-5">
              {cartDetailed.length === 0 ? (
                <div className="mt-10 text-center">
                  <p className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-[#f2f4f5]"><ShoppingBag className="h-6 w-6 text-gray-400" /></p>
                  <p className="mt-3 font-bold">Tu cesta está vacía</p>
                  <p className="mx-auto mt-1 max-w-60 text-sm text-gray-500">Explora mi tienda y añade lo que te guste. Todo lo vendo yo.</p>
                  <button onClick={() => setCartOpen(false)} className="mt-4 rounded-full bg-[#1d2126] px-6 py-2.5 text-sm font-bold text-white">Seguir explorando</button>
                </div>
              ) : (
                <ul className="space-y-4">
                  {cartDetailed.map((l) => (
                    <li key={`${l.id}__${l.logoIndex ?? "base"}__${l.shipCountry}__${l.shipCity}__${l.shipDom}__${l.payType}`} className="flex gap-3 rounded-2xl border border-black/5 p-3">
                      <img src={l.product.image} alt="" className="h-20 w-20 shrink-0 rounded-xl object-cover" />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-bold">{l.product.title}</p>
                        <p className="mt-0.5 flex flex-wrap gap-1">
                          <span className="inline-flex items-center gap-1 rounded-full bg-[#e6faf6] px-2 py-0.5 text-[11px] font-bold text-[#0b4a43]">
                            {l.payType === "Tarjeta" ? <CreditCard className="h-3 w-3" /> : <Wallet className="h-3 w-3" />} {l.payType}
                          </span>
                          {l.logoName ? (
                            <span className="inline-flex items-center gap-1 rounded-full bg-[#fff4d6] px-2 py-0.5 text-[11px] font-bold text-[#6b4a00]">
                              🏷️ {l.logoName} · +{formatPen(l.extra)} c/u
                            </span>
                          ) : null}
                        </p>
                        <p className="mt-1 rounded-2xl bg-[#f7f8f9] p-2 text-[11px] leading-4 text-gray-700">
                          🚚 {l.shipCountry} (+{formatPen(shipCountryPrice(l.shipCountry))}) · {l.shipCity} (+{formatPen(shipCityPrice(l.shipCity))}) · {l.shipDom} (+{formatPen(shipDomPrice(l.shipDom))})
                          {l.shipAddress ? <span className="block truncate">📍 {l.shipAddress}</span> : null}
                        </p>
                        <p className="mt-1 text-xs text-gray-500">
                          Prod {formatPen(l.unitPen * l.qty)} + envío {formatPen(l.shipPen)} = <strong className="text-black">{formatPen(l.linePen)}</strong> · {formatBob(l.lineBob)}
                        </p>
                        <div className="mt-2 flex items-center justify-between">
                          <div className="flex items-center gap-2 rounded-full bg-[#f2f4f5] px-1.5 py-1">
                            <button onClick={() => setQty(l.id, l.qty - 1, l.logoIndex, l.shipCountry, l.shipCity, l.shipDom, l.payType)} className="grid h-6 w-6 place-items-center rounded-full bg-white shadow-sm" aria-label="Quitar uno"><Minus className="h-3.5 w-3.5" /></button>
                            <span className="min-w-5 text-center text-sm font-bold">{l.qty}</span>
                            <button onClick={() => setQty(l.id, Math.min(l.qty + 1, Math.max(l.product.stock, l.logoIndex != null ? (l.product.logoMinQty ?? 100) : l.product.stock)), l.logoIndex, l.shipCountry, l.shipCity, l.shipDom, l.payType)} className="grid h-6 w-6 place-items-center rounded-full bg-white shadow-sm" aria-label="Añadir uno"><Plus className="h-3.5 w-3.5" /></button>
                          </div>
                          <button onClick={() => removeLine(l.id, l.logoIndex, l.shipCountry, l.shipCity, l.shipDom, l.payType)} className="grid h-8 w-8 place-items-center rounded-full text-gray-400 hover:bg-red-50 hover:text-red-500" aria-label="Eliminar"><Trash2 className="h-4 w-4" /></button>
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>
            {cartDetailed.length > 0 && (
              <div className="border-t border-black/10 p-5">
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between text-gray-600"><span>Productos ({cartCount})</span><span className="font-bold text-black">{formatPen(subPen)}</span></div>
                  <div className="flex justify-between text-gray-600"><span>🚚 Envíos (país+ciudad+domicilio)</span><span className="font-bold text-black">+{formatPen(shipPenTotal)} · {formatBob(bobOf(shipPenTotal))}</span></div>
                </div>
                <div className="mt-2 flex items-end justify-between border-t border-dashed border-black/10 pt-2">
                  <span className="font-extrabold">Total a pagarme</span>
                  <span className="text-right">
                    <span className="block text-2xl font-extrabold">{formatPen(totalPen)}</span>
                    <span className="block text-sm font-bold text-gray-500">{formatBob(totalBob)}</span>
                  </span>
                </div>
                <div className="mt-4 grid gap-2">
                  {cardEnabled && (
                    <button
                      onClick={() => openCheckout("card")}
                      className="flex items-center justify-center gap-2 rounded-full bg-[#1d2126] py-3.5 text-sm font-bold text-white transition hover:bg-[#13c1ac] hover:text-[#0b2b27]"
                    >
                      <CreditCard className="h-4 w-4" /> Pagar con tarjeta
                    </button>
                  )}
                  <button
                    onClick={() => openCheckout("whatsapp")}
                    className="flex items-center justify-center gap-2 rounded-full bg-[#25d366] py-3.5 text-sm font-bold text-white transition hover:bg-[#1eb856]"
                  >
                    <WhatsAppIcon className="h-4 w-4" /> Enviar pedido por WhatsApp
                  </button>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => handleDownloadPdf("PRESUPUESTO")}
                      className="flex items-center justify-center gap-1.5 rounded-full border-2 border-[#1d2126] py-2.5 text-xs font-bold transition hover:bg-[#1d2126] hover:text-white"
                    >
                      <FileText className="h-4 w-4" /> PDF Presupuesto
                    </button>
                    <button
                      onClick={() => handleSharePdf("PRESUPUESTO")}
                      className="flex items-center justify-center gap-1.5 rounded-full bg-black py-2.5 text-xs font-bold text-white transition hover:bg-[#13c1ac] hover:text-[#0b2b27]"
                    >
                      <Share2 className="h-4 w-4" /> PDF a WhatsApp
                    </button>
                  </div>
                </div>
                <p className="mt-2 text-center text-[11px] text-gray-500">{cardEnabled ? "Elige tarjeta, WhatsApp o genera tu presupuesto en PDF. Sin intermediarios." : "Envía tu pedido por WhatsApp o genera tu presupuesto en PDF. Sin intermediarios."}</p>
              </div>
            )}
          </aside>
        </div>
      )}

      {/* Chat */}
      {chatOpen && (
        <div className="fixed inset-0 z-50">
          <button className="absolute inset-0 bg-black/50" onClick={() => setChatOpen(false)} aria-label="Cerrar chat" />
          <aside className="absolute right-0 top-0 flex h-full w-full max-w-md flex-col bg-white shadow-2xl" style={{ animation: "slide-in-right .35s ease-out" }}>
            <div className="flex items-center gap-3 border-b border-black/5 bg-[#1d2126] p-4 text-white">
              <img src={SELLER.avatar} alt="" className="h-11 w-11 rounded-full object-cover" />
              <div className="min-w-0 flex-1">
                <p className="flex items-center gap-1 text-sm font-bold">{SELLER.name} <BadgeCheck className="h-4 w-4 text-[#7ce3d3]" /></p>
                <p className="text-xs text-white/60">En línea · {SELLER.response}</p>
              </div>
              <button onClick={() => setChatOpen(false)} className="grid h-9 w-9 place-items-center rounded-full bg-white/10" aria-label="Cerrar chat"><X className="h-5 w-5" /></button>
            </div>
            <button onClick={() => setSelectedId(chatProduct.id)} className="flex items-center gap-3 border-b border-black/5 bg-[#f7f8f9] p-3 text-left">
              <img src={chatProduct.image} alt="" className="h-12 w-12 rounded-xl object-cover" />
              <span className="min-w-0 flex-1">
                <span className="block truncate text-[13px] font-bold">{chatProduct.title}</span>
                <span className="text-xs font-bold">{formatPen(chatProduct.pricePen)} · <span className="font-semibold text-gray-500">{formatBob(bobOf(chatProduct.pricePen))}</span></span>
              </span>
              <ChevronRight className="h-4 w-4 text-gray-400" />
            </button>
            <div className="thin-scroll flex-1 space-y-2.5 overflow-y-auto bg-[#eef2f3] p-4">
              {messages.map((m, i) => (
                <div key={i} className={`animate-chat flex ${m.from === "me" ? "justify-end" : "justify-start"}`}>
                  <div className={`max-w-[80%] rounded-2xl px-3.5 py-2.5 text-[13px] leading-5 shadow-sm ${m.from === "me" ? "rounded-br-md bg-[#13c1ac] font-medium text-[#0b2b27]" : "rounded-bl-md bg-white"}`}>
                    {m.text}
                    <span className={`mt-1 block text-right text-[10px] ${m.from === "me" ? "text-[#0b2b27]/60" : "text-gray-400"}`}>{m.time}</span>
                  </div>
                </div>
              ))}
            </div>
            <div className="border-t border-black/5 p-3">
              <div className="no-scrollbar flex gap-1.5 overflow-x-auto pb-2">
                {["¿Sigue disponible?", "¿Haces envíos a Bolivia?", "¿Aceptas oferta?", "¿Qué métodos de pago aceptas?"].map((q) => (
                  <button key={q} onClick={() => sendMessage(q)} className="shrink-0 rounded-full border border-[#13c1ac]/40 bg-[#e6faf6] px-3 py-1.5 text-xs font-bold text-[#0b4a43]">
                    {q}
                  </button>
                ))}
              </div>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  sendMessage(draft);
                }}
                className="flex items-center gap-2"
              >
                <input
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  placeholder="Escríbeme…"
                  className="flex-1 rounded-full border border-black/10 bg-[#f7f8f9] px-4 py-2.5 text-sm outline-none focus:border-[#13c1ac]"
                />
                <button type="submit" className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-[#13c1ac] text-[#0b2b27] transition hover:bg-[#0c9d8c] hover:text-white" aria-label="Enviar">
                  <Send className="h-4 w-4" />
                </button>
              </form>
            </div>
          </aside>
        </div>
      )}

      {/* Checkout: tarjeta o WhatsApp */}
      {checkoutOpen && (
        <div className="fixed inset-0 z-[55] flex items-end justify-center sm:items-center sm:p-4">
          <button className="absolute inset-0 bg-black/60" onClick={() => setCheckoutOpen(false)} aria-label="Cerrar pago" />
          <div className="animate-pop relative max-h-[94vh] w-full max-w-lg overflow-y-auto rounded-t-3xl bg-white sm:rounded-3xl">
            <div className="sticky top-0 flex items-center justify-between border-b border-black/5 bg-white/95 p-5 backdrop-blur">
              <div>
                <p className="text-[11px] font-bold tracking-[0.15em] text-[#0c9d8c] uppercase">JH Importaciones · presupuesto</p>
                <h3 className="font-serif text-2xl">Confirmar pedido</h3>
              </div>
              <button onClick={() => setCheckoutOpen(false)} className="grid h-9 w-9 place-items-center rounded-full bg-black/5" aria-label="Cerrar">
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="p-5 sm:p-6">
                <div className="rounded-3xl border border-black/10 bg-[#f7f8f9] p-4">
                  <p className="flex items-center gap-1.5 text-sm font-extrabold">
                    <MapPin className="h-4 w-4" /> Tus datos + envíos ya elegidos en cada producto
                  </p>
                  <p className="mt-0.5 text-xs text-gray-500">
                    País, ciudad y domicilio ya suman al total en cada producto. Solo confirma tu nombre.
                  </p>
                  <div className="mt-3 grid gap-2">
                    <input value={buyer.name} onChange={(e) => setBuyer({ ...buyer, name: e.target.value })} placeholder="Tu nombre *" className="w-full rounded-2xl border border-black/10 bg-white px-4 py-2.5 text-sm outline-none focus:border-[#13c1ac]" />
                    <div className="space-y-1.5">
                      {cartDetailed.map((l) => (
                        <p key={`${l.id}__${l.logoIndex ?? "base"}__${l.shipCountry}__${l.shipCity}__${l.payType}`} className="rounded-2xl bg-white p-2 text-xs">
                          🚚 <strong>{l.product.title}</strong> · {l.shipCountry} (+{formatPen(shipCountryPrice(l.shipCountry))}) · {l.shipCity} (+{formatPen(shipCityPrice(l.shipCity))}) · {l.shipDom} (+{formatPen(shipDomPrice(l.shipDom))}) · 💳 {l.payType}
                          {l.shipAddress ? ` · 📍 ${l.shipAddress}` : ""}
                        </p>
                      ))}
                    </div>
                    {!locationOk && <p className="text-xs font-bold text-red-600">Escribe tu nombre y la dirección exacta en el producto (si la pide) para continuar.</p>}
                  </div>
                </div>

                {cardEnabled ? (
                  <div className="mt-3 grid grid-cols-2 gap-2 rounded-2xl bg-[#f2f4f5] p-1.5">
                    <button
                      onClick={() => setPayMethod("card")}
                      className={`flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-sm font-bold transition ${payMethod === "card" ? "bg-white shadow" : "text-gray-500"}`}
                    >
                      <CreditCard className="h-4 w-4" /> Tarjeta
                    </button>
                    <button
                      onClick={() => setPayMethod("whatsapp")}
                      className={`flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-sm font-bold transition ${payMethod === "whatsapp" ? "bg-white shadow" : "text-gray-500"}`}
                    >
                      <WhatsAppIcon className="h-4 w-4" /> WhatsApp
                    </button>
                  </div>
                ) : (
                  <div className="mt-3 rounded-2xl bg-[#f2f4f5] p-3 text-center text-xs font-bold text-gray-600">
                    Pago con tarjeta desactivado · Paga por WhatsApp / Yape / Plin / transferencia
                  </div>
                )}

                {payMethod === "card" && cardEnabled ? (
                  <div className="mt-5">
                    <p className="text-sm font-bold">Tarjeta mediante una pasarela externa</p>
                    <p className="mt-2 rounded-2xl bg-[#f2f4f5] p-4 text-sm">
                      Total del pedido: <strong>{formatPen(totalPen)} / {formatBob(totalBob)}</strong>
                    </p>
                    <a
                      href={cardLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={(event) => {
                        if (!locationOk) {
                          event.preventDefault();
                          showToast("Completa tu nombre y la direccion antes de continuar");
                        }
                      }}
                      className="mt-4 flex items-center justify-center gap-2 rounded-full bg-[#13c1ac] p-4 text-sm font-bold text-[#0b2b27] transition hover:bg-[#0c9d8c] hover:text-white"
                    >
                      <CreditCard className="h-5 w-5" /> Ir al enlace de pago
                    </a>
                    <p className="mt-3 text-xs leading-5 text-gray-600">
                      Verifica el importe en la pasarela antes de pagar. Esta pagina no cobra ni solicita datos de tarjeta;
                      solo la pasarela externa puede confirmar el pago. Si el enlace tiene un importe fijo, coordinalo
                      por WhatsApp antes de abrirlo.
                    </p>
                    <button
                      onClick={() => setPayMethod("whatsapp")}
                      className="mt-3 w-full rounded-full border border-black/15 py-3 text-xs font-bold hover:bg-[#f2f4f5]"
                    >
                      Coordinar por WhatsApp en su lugar
                    </button>
                  </div>
                ) : (
                  <div className="mt-5">
                    <p className="text-sm font-bold">Te mando mi pedido al chat de WhatsApp</p>
                    <p className="mt-1 text-[13px] leading-5 text-gray-600">
                      Al pulsar el botón se abrirá mi WhatsApp <strong>{WHATSAPP_NUMBER}</strong> con tu pedido, ubicación y total en S/ y Bs ya escritos.
                    </p>
                    <div className="mt-3 max-h-52 overflow-y-auto rounded-2xl border border-black/10 bg-[#f7f8f9] p-4 text-[13px]">
                      {cartDetailed.map((l) => (
                        <div key={`${l.id}__${l.logoIndex ?? "base"}__${l.payType}`} className="flex items-center gap-2.5 border-b border-black/5 py-2 last:border-0">
                          <img src={l.product.image} alt="" className="h-10 w-10 rounded-lg object-cover" />
                          <div className="min-w-0 flex-1">
                            <p className="truncate font-bold">
                              {l.qty}x {l.product.title}
                              {l.logoName ? <span className="text-[#6b4a00]"> · {l.logoName}</span> : null}
                            </p>
                            <p className="text-xs text-gray-500">{formatPen(l.unitPen * l.qty)} · {formatBob(l.unitBob * l.qty)} · 💳 {l.payType}</p>
                          </div>
                        </div>
                      ))}
                      <div className="flex justify-between pt-2 font-extrabold">
                        <span>Total</span>
                        <span>{formatPen(totalPen)} · {formatBob(totalBob)}</span>
                      </div>
                      <p className="mt-1 text-xs text-gray-500">📍 {buyer.name ? `${buyer.name} · ` : ""}{buyerLine}</p>
                    </div>
                    {!locationOk && (
                      <p className="mt-2 rounded-2xl bg-red-50 p-2.5 text-xs font-bold text-red-600">
                        Completa tu ubicación arriba (país, ciudad y dirección) para enviar por WhatsApp.
                      </p>
                    )}
                    <div className="mt-3 rounded-3xl border-2 border-dashed border-[#13c1ac] bg-[#e6faf6] p-4">
                      <p className="flex items-center gap-1.5 text-sm font-extrabold text-[#0b4a43]">
                        <FileText className="h-4 w-4" /> Presupuesto en PDF ({quoteCode})
                      </p>
                      <p className="mt-1 text-xs leading-5 text-[#0b4a43]">
                        Genera el PDF con tu pedido, totales en S/ y Bs, envío y datos. En celular se comparte directo a WhatsApp; en PC se descarga y se abre el chat.
                      </p>
                      <div className="mt-3 grid grid-cols-2 gap-2">
                        <button
                          onClick={() => handleDownloadPdf("PRESUPUESTO")}
                          className="flex items-center justify-center gap-1.5 rounded-full bg-white py-3 text-xs font-bold text-black shadow-sm transition hover:bg-black hover:text-white"
                        >
                          <Download className="h-4 w-4" /> Descargar PDF
                        </button>
                        <button
                          onClick={() => handleSharePdf("PRESUPUESTO")}
                          className="flex items-center justify-center gap-1.5 rounded-full bg-[#1d2126] py-3 text-xs font-bold text-white transition hover:bg-[#13c1ac] hover:text-[#0b2b27]"
                        >
                          <Share2 className="h-4 w-4" /> PDF a WhatsApp
                        </button>
                      </div>
                    </div>
                    {locationOk ? (
                      <div className="mt-3 grid gap-2">
                        <a href={waLinkFixed} target="_blank" rel="noreferrer" className="flex items-center justify-center gap-2 rounded-full bg-[#25d366] py-4 text-sm font-bold text-white transition hover:bg-[#1eb856]">
                          <WhatsAppIcon className="h-5 w-5" /> Enviar a WhatsApp {WHATSAPP_NUMBER} <ChevronRight className="h-4 w-4" />
                        </a>
                        <button
                          onClick={copyWaMsg}
                          className="flex items-center justify-center gap-1.5 rounded-full bg-[#f2f4f5] py-2.5 text-xs font-bold text-gray-700 transition hover:bg-black hover:text-white"
                        >
                          <Copy className="h-4 w-4" /> Copiar texto (si WhatsApp falla)
                        </button>
                        <p className="text-center text-[11px] text-gray-500">Si el botón falla: 1) Descarga el PDF · 2) Copia el texto · 3) Pégalo en tu chat de WhatsApp.</p>
                      </div>
                    ) : (
                      <button disabled className="mt-4 flex w-full cursor-not-allowed items-center justify-center gap-2 rounded-full bg-gray-200 py-4 text-sm font-bold text-gray-500">
                        <WhatsAppIcon className="h-5 w-5" /> Completa tu ubicación
                      </button>
                    )}
                    <a href={WHATSAPP_GENERAL} target="_blank" rel="noreferrer" className="mt-2 block text-center text-xs font-bold text-[#0c9d8c] hover:underline">
                      O escríbeme directo con tu plantilla de TikTok
                    </a>
                  </div>
                )}
              </div>
          </div>
        </div>
      )}

      {/* Flotante WhatsApp */}
      <a
        href={WHATSAPP_GENERAL}
        target="_blank"
        rel="noreferrer"
        aria-label="Hablar por WhatsApp"
        className="group fixed bottom-24 right-4 z-30 flex items-center gap-2 rounded-full bg-[#25d366] p-3.5 text-white shadow-[0_10px_30px_rgba(37,211,102,.45)] transition hover:scale-105 hover:bg-[#1eb856] md:bottom-6 md:right-6"
      >
        <span className="absolute -right-0.5 -top-0.5 flex h-3.5 w-3.5">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-white opacity-60" />
          <span className="relative inline-flex h-3.5 w-3.5 rounded-full border-2 border-white bg-[#25d366]" />
        </span>
        <WhatsAppIcon className="h-6 w-6" />
        <span className="hidden max-w-0 overflow-hidden text-sm font-bold transition-all group-hover:max-w-40 md:group-hover:pr-1">¡Pídeme por WhatsApp!</span>
      </a>

      {/* Botón ver tienda icono */}
      <button
        onClick={() => document.getElementById("catalogo")?.scrollIntoView({ behavior: "smooth" })}
        className="fixed bottom-24 left-4 z-30 grid h-12 w-12 place-items-center rounded-full bg-[#1d2126] text-white shadow-xl transition hover:bg-[#13c1ac] hover:text-[#0b2b27] md:hidden"
        aria-label="Ver catálogo"
      >
        <LayoutGrid className="h-5 w-5" />
      </button>

      {/* Toast */}
      {toast && (
        <div className="fixed bottom-24 left-1/2 z-[60] -translate-x-1/2 rounded-full bg-[#1d2126] px-5 py-2.5 text-sm font-bold text-white shadow-xl md:bottom-8" style={{ animation: "toast-up .25s ease-out" }}>
          {toast}
        </div>
      )}
    </div>
  );
}
