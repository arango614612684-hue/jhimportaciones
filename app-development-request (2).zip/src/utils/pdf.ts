import { jsPDF } from "jspdf";

export type PdfLine = {
  qty: number;
  title: string;
  logoName: string | null;
  extraPen: number;
  unitPen: number;
  unitBob: number;
  shipCountry: string;
  shipCity: string;
  shipDom: string;
  shipAddress: string;
  shipPen: number;
  shipBob: number;
  linePen: number;
  lineBob: number;
  payType?: string;
};

export type PdfClient = {
  name: string;
  country: string;
  city: string;
  address: string;
};

export type PdfDocInput = {
  kind: "PRESUPUESTO" | "PEDIDO";
  code: string;
  date: string;
  rate: number;
  client: PdfClient;
  lines: PdfLine[];
  subPen: number;
  shipPen: number;
  totalPen: number;
  totalBob: number;
  payMethod: string;
  whatsapp: string;
};

function clean(s: string, max = 60) {
  const t = (s || "").replace(/\s+/g, " ").trim();
  if (t.length <= max) return t;
  return t.slice(0, max - 1) + "…";
}

export function buildPdfDoc(input: PdfDocInput) {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const W = 210;
  const M = 14;
  let y = 0;

  // Header negro
  doc.setFillColor(10, 10, 10);
  doc.rect(0, 0, W, 38, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(17);
  doc.text("JH IMPORTACIONES", M, 14);
  doc.setFontSize(9);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(180, 255, 240);
  doc.text("PRODUCTOS NOVEDOSOS A PRECIO DE FABRICA", M, 20);
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(13);
  doc.text(input.kind, W - M, 14, { align: "right" });
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.text(`${input.code}  ·  ${input.date}`, W - M, 20, { align: "right" });
  doc.setFontSize(8.5);
  doc.setTextColor(200, 200, 200);
  doc.text(`TC PEN/BOB referencial: 1 S/ = Bs ${input.rate.toFixed(2)}  ·  WhatsApp ${input.whatsapp}`, W - M, 26, { align: "right" });
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(8.5);
  doc.text("TikTok: @importaciones.bolivia   ·   Facebook: JH Importaciones", M, 26);
  doc.setFillColor(19, 193, 172);
  doc.rect(M, 31, 44, 4, "F");
  y = 46;

  // Cliente
  doc.setTextColor(20, 20, 20);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.text("Datos del cliente / envio", M, y);
  y += 6;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  const c = input.client;
  doc.text(`Cliente: ${clean(c.name || "—", 55)}`, M, y);
  y += 5;
  doc.text(`Pais: ${clean(c.country || "-", 30)}    Ciudad: ${clean(c.city || "-", 30)}`, M, y);
  y += 5;
  doc.text(`Direccion: ${clean(c.address || "-", 80)}`, M, y);
  y += 5;
  doc.text(`Pago: ${clean(input.payMethod, 70)}`, M, y);
  y += 8;

  // Tabla header
  doc.setFillColor(20, 20, 22);
  doc.rect(M, y - 4.5, W - M * 2, 8, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8.5);
  doc.text("CANT", M + 1, y + 1);
  doc.text("PRODUCTO / LOGO / ENVIO", M + 16, y + 1);
  doc.text("P.UNIT S/", M + 118, y + 1);
  doc.text("SUBTOTAL", W - M - 1, y + 1, { align: "right" });
  y += 7;
  doc.setTextColor(20, 20, 20);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);

  const pageBottom = 270;

  input.lines.forEach((l, idx) => {
    // calcular alto bloque
    const title = clean(l.title, 52);
    const logo = l.logoName ? `Logo: ${clean(l.logoName, 40)} (+S/ ${l.extraPen})` : null;
    const ship = `${clean(l.shipCountry, 16)} / ${clean(l.shipCity, 16)} / ${clean(l.shipDom, 20)} (+S/ ${l.shipPen})`;
    const addr = l.shipAddress ? `Dir: ${clean(l.shipAddress, 58)}` : null;
    const pay = l.payType ? `Pago: ${clean(l.payType, 40)}` : null;
    const rows = [title, ...(logo ? [logo] : []), ship, ...(addr ? [addr] : []), ...(pay ? [pay] : [])];
    const blockH = rows.length * 4.5 + 3;

    if (y + blockH > pageBottom) {
      doc.addPage();
      y = 18;
    }
    if (idx % 2 === 0) {
      doc.setFillColor(245, 247, 248);
      doc.rect(M, y - 4, W - M * 2, blockH, "F");
    }
    doc.setFont("helvetica", "bold");
    doc.text(String(l.qty), M + 1, y);
    doc.setFont("helvetica", "normal");
    let ly = y;
    rows.forEach((r, ri) => {
      doc.setFont("helvetica", ri === 0 ? "bold" : "normal");
      doc.setFontSize(ri === 0 ? 9 : 8);
      doc.text(r, M + 16, ly);
      ly += 4.5;
    });
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8.5);
    doc.text(`S/ ${l.unitPen}`, M + 118, y);
    doc.setFont("helvetica", "bold");
    doc.text(`S/ ${l.linePen}`, W - M - 1, y, { align: "right" });
    doc.setFont("helvetica", "normal");
    doc.setFontSize(7.5);
    doc.setTextColor(90, 90, 90);
    doc.text(`Bs ${l.lineBob}`, W - M - 1, y + 4, { align: "right" });
    doc.setTextColor(20, 20, 20);
    y += blockH + 1.5;
  });

  if (y + 45 > pageBottom) {
    doc.addPage();
    y = 18;
  }
  y += 2;
  doc.setDrawColor(220, 220, 220);
  doc.line(M, y, W - M, y);
  y += 6;
  doc.setFontSize(9.5);
  doc.text(`Subtotal productos:  S/ ${input.subPen}`, W - M, y, { align: "right" });
  y += 6;
  doc.text(`Envios (pais+ciudad+domicilio):  +S/ ${input.shipPen}`, W - M, y, { align: "right" });
  y += 8;
  doc.setFillColor(10, 10, 10);
  doc.rect(M, y - 6, W - M * 2, 14, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(13);
  doc.text(`TOTAL: S/ ${input.totalPen}`, M + 4, y + 3.5);
  doc.setFontSize(10);
  doc.text(`Bs ${input.totalBob}`, W - M - 4, y + 3.5, { align: "right" });
  y += 14;

  doc.setTextColor(80, 80, 80);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  const note =
    input.kind === "PRESUPUESTO"
      ? "Presupuesto valido por 48 horas. Precios en Bs calculados con un TC referencial; confirme el importe antes de pagar. Responda por WhatsApp."
      : "Gracias por su compra. Guarde este comprobante y envielo por WhatsApp para coordinar pago y envio.";
  const split = doc.splitTextToSize(note, W - M * 2);
  doc.text(split, M, y);
  y += split.length * 4 + 4;
  doc.setFontSize(8);
  doc.text(`Generado: ${input.date}  ·  ${input.code}  ·  JH Importaciones · wa.me/${input.whatsapp}`, M, y);

  return doc;
}

export function downloadPdf(input: PdfDocInput) {
  const doc = buildPdfDoc(input);
  doc.save(`${input.kind}-${input.code}.pdf`);
  return doc;
}

export async function sharePdfToWhatsApp(input: PdfDocInput, waNumber: string, extraText: string) {
  const doc = buildPdfDoc(input);
  const blob = doc.output("blob");
  const fileName = `${input.kind}-${input.code}.pdf`;
  const file = new File([blob], fileName, { type: "application/pdf" });

  // 1) Intento compartir nativo (celular) con archivo a WhatsApp
  const nav = navigator as unknown as { share?: (d: { files?: File[]; title?: string; text?: string }) => Promise<void>; canShare?: (d: { files: File[] }) => boolean };
  if (nav.canShare && nav.canShare({ files: [file] }) && nav.share) {
    try {
      await nav.share({ files: [file], title: fileName, text: extraText });
      return { shared: true as const, method: "native-share" as const };
    } catch {
      // usuario canceló o falló -> seguimos a descarga + wa.me
    }
  }
  // 2) Descarga + abrir WhatsApp con texto corto (evita URL gigante que da error)
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);

  const waUrl = `https://wa.me/${waNumber}?text=${encodeURIComponent(extraText)}`;
  window.open(waUrl, "_blank", "noopener,noreferrer");
  return { shared: false as const, method: "download+whatsapp" as const };
}
