# JH Importaciones: archivos e instalacion en GitHub y hosting

## 1. Que archivos necesitas

**Para guardar el proyecto en GitHub**, sube la carpeta del proyecto que contiene:

- `src/` (tienda y generador de PDF)
- `public/` (logos `public/images/jh-icon.jpg`, `public/images/jh-logo.jpg` y `.htaccess`)
- `index.html`, `package.json`, `tsconfig.json`, `vite.config.ts`
- `netlify.toml`, `README.md`, esta guia y `.github/workflows/archivos-para-hosting.yml`
- `.gitignore` (evita subir archivos temporales)

**Para instalar la web en un hosting**, usa unicamente la salida de la compilacion:

- `dist/index.html`
- `dist/images/jh-icon.jpg`
- `dist/images/jh-logo.jpg`
- `dist/.htaccess` (si usas un hosting Apache/cPanel)

`dist/` se crea automaticamente con `npm run build`. No subas `src/` ni `node_modules/` a `public_html`. Tampoco abras el archivo `index.html` desde el disco como `file://`; pruebalo con `npm run preview` o en tu hosting.

## 2. Compilar en tu PC (Windows / PowerShell)

Abre PowerShell en tu proyecto (ejemplo de la carpeta donde trabajas):

```powershell
cd "C:\Users\usuario\Downloads\app-development-request"
npm install
npm run build
```

El resultado estara en `dist/`. Si ves `"vite" no se reconoce`, verifica que estes junto a `package.json` y repite `npm install`. Si quieres ver el resultado local: `npm run preview` y abre la URL que aparezca en la terminal.

## 3. Subir el codigo a GitHub

1. Crea una cuenta en <https://github.com/> y, si no tienes Git en Windows, instala Git desde <https://git-scm.com/download/win>.
2. En <https://github.com/new> crea un repositorio, por ejemplo `jh-importaciones`. Elige **Private** si no quieres mostrar el codigo. No marques "Add a README" porque este proyecto ya tiene uno.
3. En PowerShell, en la carpeta del proyecto, usa estos comandos reemplazando `TU_USUARIO`:

```powershell
git init
git branch -M main
git add .
git commit -m "Subir JH Importaciones"
git remote add origin https://github.com/TU_USUARIO/jh-importaciones.git
git push -u origin main
```

Si Git te pide `user.name` o `user.email`, configuralos con `git config --global user.name "Tu Nombre"` y `git config --global user.email "tu-correo@ejemplo.com"`, y repite desde `git add .`. Si ya hay un repositorio Git o un remoto `origin`, no repitas `git init`/`git remote add origin`; consulta primero `git remote -v`.

**Cada cambio posterior**: guarda tus cambios, ejecuta `git add .`, `git commit -m "Actualizar tienda"` y `git push`. GitHub reconstruira los archivos de la web en la pestaña Actions.

## 4. Descargar un ZIP listo para tu hosting desde GitHub

El proyecto ya trae el workflow `.github/workflows/archivos-para-hosting.yml`. Tras subir la rama `main`:

1. Abre tu repositorio en GitHub > **Actions** > **Crear archivos para hosting**.
2. Abre la ejecucion mas reciente (o usa **Run workflow** para reconstruir manualmente).
3. Cuando todo salga verde, baja hasta **Artifacts** y pulsa `jh-importaciones-web`.
4. Se descargara un ZIP. Descomprimelo: dentro deben estar `index.html`, `images/` y `.htaccess`. Ese ZIP es el sitio compilado, NO el boton "Download ZIP" de la pagina principal del repositorio (ese ultimo descarga codigo fuente).

El workflow instala dependencias con Node 22 y ejecuta `npm run build`. El ZIP es para subir a tu hosting, no es una web publicada automaticamente en GitHub.

## 5. Instalar en tu hosting actual (cPanel / Hostinger / DonWeb)

1. Entra al administrador de archivos de tu hosting.
2. Si quieres que la tienda sea la pagina principal, ve a `public_html/`. Si YA tienes una pagina y no quieres sustituirla, crea `public_html/tienda/` o un subdominio `tienda.tudominio.com` y usa la carpeta asignada al subdominio.
3. Sube **el contenido** de `dist/` (o descomprime el ZIP de Actions alli): `index.html`, carpeta `images/` y `.htaccess`. El archivo `index.html` debe quedar directamente en la carpeta publica elegida, no dentro de una carpeta extra llamada `dist`.
4. Si no ves `.htaccess`, activa "Show hidden files" en el administrador. En un hosting que no sea Apache, puedes omitirlo.
5. Activa el certificado SSL/HTTPS y abre `https://tudominio.com/` o `https://tudominio.com/tienda/`.

No borres el `index.html` de tu sitio anterior a menos que quieras reemplazarlo.

## 6. Publicar automaticamente desde GitHub con Netlify (recomendado)

1. Abre <https://app.netlify.com/start> e inicia sesion.
2. Elige **Import an existing project** > **GitHub** y autoriza el acceso al repositorio `jh-importaciones`.
3. Selecciona la rama `main`. El archivo `netlify.toml` ya define `npm run build`, publicacion `dist` y Node 22. Si Netlify te pide estos datos a mano, usa exactamente esos valores.
4. Pulsa Deploy/Publish. Netlify instalara dependencias y te dara una URL `*.netlify.app`.
5. Si quieres usar tu dominio, en Netlify > Domain management agrega tu dominio o subdominio y sigue las indicaciones DNS de Netlify. No apuntes el dominio a Netlify hasta que el sitio funcione en la URL de prueba.

Con GitHub conectado, los `git push` a `main` publican de nuevo automaticamente. Si ya tienes hosting, no necesitas Netlify: puedes usar el ZIP del paso 4 y subirlo manualmente.

**GitHub Pages no es el hosting apropiado para esta tienda.** Los [terminos oficiales de GitHub Pages](https://docs.github.com/en/site-policy/github-terms/github-terms-for-additional-products-and-features#pages) no permiten usar el hosting gratuito para una tienda online o una web principalmente dedicada a transacciones comerciales. Usa GitHub para el codigo y Netlify o tu hosting para la web publica.

## 7. Comprobaciones importantes antes de vender

- El favicon y logo pequeno usan `images/jh-icon.jpg`; el banner usa `images/jh-logo.jpg`. Comprueba que ambas rutas cargan.
- TikTok, Facebook y WhatsApp apuntan a las cuentas que proporcionaste; prueba sus enlaces desde tu telefono.
- **No introduzcas tarjetas en esta web.** El formulario que simulaba cobros fue retirado. La opcion de tarjeta permanece oculta salvo que haya un enlace HTTPS de una pasarela real y la actives. La pagina NO confirma el pago ni envia el importe al enlace fijo automaticamente: verifica importe y estado del pago en tu pasarela.
- **Administracion no es un CMS compartido:** productos, tarifas, PIN y enlace de pago se guardan en `localStorage` de cada navegador. Un cambio desde tu telefono NO se publica automaticamente para todos los clientes ni se incorpora al ZIP. Para administrar desde varios dispositivos y sincronizar inventario/pagos se necesita un backend con login real y base de datos. Un PIN embebido en una web estatica NO ofrece seguridad de produccion, incluso si el repositorio es privado.
- El tipo de cambio es referencial: la web intenta obtener una tasa de mercado de un servicio externo y puede fallar o no coincidir exactamente con Wise. Confirma importes antes de cobrar.
- El PDF es un presupuesto local. WhatsApp no adjunta siempre el PDF automaticamente: en computadora descargas el PDF y lo adjuntas al mensaje manualmente.

Si en tu hosting ves pantalla en blanco, verifica que subiste el `index.html` de `dist/` y la carpeta `images/` al mismo nivel. Si las imagenes de productos externos no cargan, necesitan conexion y disponibilidad del proveedor de imagenes.
